import puppeteer from "puppeteer-core";
import { mkdirSync } from "fs";
const ROOT = "/workspace/ascii_air/delivery/shots";
mkdirSync(ROOT + "/beauty", { recursive: true });
mkdirSync(ROOT + "/heroes", { recursive: true });
const KEY = "ascii-air-m1-v1";
const b = await puppeteer.launch({
  executablePath: "/usr/bin/google-chrome-stable",
  headless: "new",
  args: ["--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader","--no-sandbox","--disable-dev-shm-usage","--window-size=1920,1080"],
  protocolTimeout: 180000,
});
const page = await b.newPage();
const errors = [];
page.on("pageerror", (e) => { errors.push(String(e)); console.log("PAGEERROR", e.message); });
await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });
await page.evaluateOnNewDocument((key) => {
  try { localStorage.setItem(key, JSON.stringify({ settings: { quality: "medium", _autoQ: true } })); } catch {}
}, KEY);
await page.goto("http://127.0.0.1:8765/?v=" + Date.now() + "&r29b=1", { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForFunction(() => window.ASCII_AIR && window.ASCII_AIR.ready, { timeout: 90000 });
const hideSrc = `() => { ["hud","hud-stats","hud-compass","hud-mission","hud-minimap","hud-flight","hud-photo","hud-aux","hud-msg","hud-fs","hud-hint","mobile-layer","overlay","title-screen"].forEach((id)=>{const e=document.getElementById(id);if(e)e.style.display="none";}); }`;

async function beauty(name, pose, direct = false) {
  const info = await page.evaluate((pose, hideSrc, direct) => {
    eval(hideSrc)();
    const A = window.ASCII_AIR;
    A.startFreeFlight(); A.setWeather("clear"); A.setTime(11);
    const hCam = A.island.heightAt(pose.x, pose.z);
    const hLook = A.island.heightAt(pose.lx, pose.lz);
    if (direct) {
      A.camera.position.set(pose.x, pose.y, pose.z);
      A.camera.lookAt(pose.lx, pose.ly, pose.lz);
      if (A.clearLook) A.clearLook();
      // also set override so the render loop does not snap back
      if (A.lookFrom) {
        // temporarily bypass by writing after lookFrom using very high y? use lookFrom then overwrite
        A.lookFrom(pose.x, pose.y, pose.z, pose.lx, pose.ly, pose.lz);
      }
    } else {
      A.lookFrom(pose.x, pose.y, pose.z, pose.lx, pose.ly, pose.lz);
    }
    if (direct) {
      // force exact pose after lookFrom clamp
      A.lookFrom(pose.x, 400, pose.z, pose.lx, pose.ly, pose.lz); // dummy
    }
    if (A.island?.flora?.refresh) A.island.flora.refresh(A.camera);
    A.setPaused(true); A.render();
    const p = A.camera.position, t = A.getPerf?.() || {};
    return { hCam, hLook, cam: { x: +p.x.toFixed(1), y: +p.y.toFixed(1), z: +p.z.toFixed(1) }, calls: t.calls, tris: t.triangles };
  }, pose, hideSrc, direct);
  // If direct, set camOverride via a second evaluate that writes the internal pose
  if (direct) {
    await page.evaluate((pose, hideSrc) => {
      eval(hideSrc)();
      const A = window.ASCII_AIR;
      A.startFreeFlight(); A.setWeather("clear"); A.setTime(11);
      // lookFrom clamps y up; we inject the exact override by calling lookFrom
      // with a y already above terrain+8 when over water, y is used as-is.
      A.lookFrom(pose.x, pose.y, pose.z, pose.lx, pose.ly, pose.lz);
      // Force the camera in case clamp moved it, by teleporting a dummy? Use flyCam if any.
      const c = A.camera;
      c.position.set(pose.x, pose.y, pose.z);
      c.lookAt(pose.lx, pose.ly, pose.lz);
      c.updateMatrixWorld(true);
      if (A.island?.flora?.refresh) A.island.flora.refresh(c);
      A.setPaused(true); A.render();
    }, pose, hideSrc);
  }
  await page.screenshot({ path: `${ROOT}/beauty/${name}.png`, type: "png" });
  console.log("BEAUTY", name, JSON.stringify(info));
}

const hero = await page.evaluate((hideSrc) => {
  eval(hideSrc)();
  const A = window.ASCII_AIR;
  A.setTime(11); A.setWeather("clear"); A.heroShot();
  if (A.planeMesh) A.planeMesh.visible = true;
  if (A.island?.flora?.refresh) A.island.flora.refresh(A.camera);
  A.setPaused(true); A.render();
  return A.getPerf?.() || {};
}, hideSrc);
await page.screenshot({ path: `${ROOT}/heroes/hero_day.png`, type: "png" });
console.log("HERO", JSON.stringify(hero));

await beauty("01_keep", { x: 300, y: 295, z: -470, lx: 440, ly: 300, lz: -280 });
await beauty("01_keep_above", { x: 260, y: 420, z: -500, lx: 440, ly: 330, lz: -280 });
await beauty("01_keep_close", { x: 390, y: 318, z: -355, lx: 430, ly: 325, lz: -295 });
await beauty("01_keep_rock", { x: 400, y: 300, z: -380, lx: 435, ly: 310, lz: -300 });
await beauty("09_harbor", { x: 180, y: 8, z: -1172, lx: 180, ly: 8, lz: -1228 }, true);
await beauty("09_hA", { x: 140, y: 8, z: -1170, lx: 200, ly: 9, lz: -1228 }, true);
await beauty("09_hB", { x: 210, y: 9, z: -1166, lx: 155, ly: 8, lz: -1226 }, true);
await beauty("09_hC", { x: 155, y: 7, z: -1188, lx: 200, ly: 7, lz: -1220 }, true);
await beauty("03_village", { x: 40, y: 28, z: -1160, lx: 200, ly: 16, lz: -1000 });
await beauty("03_village_close", { x: 190, y: 9, z: -1065, lx: 230, ly: 6, lz: -1010 });
await beauty("14_house_close", { x: 210, y: 8, z: -1048, lx: 235, ly: 6, lz: -1010 });
await beauty("13_fields", { x: 280, y: 48, z: -980, lx: 230, ly: 24, lz: -880 });
await beauty("08_market", { x: 140, y: 22, z: -1040, lx: 180, ly: 10, lz: -980 });
await beauty("04_lighthouse", { x: -40, y: 42, z: -1320, lx: -170, ly: 30, lz: -1190 });
await beauty("12_cape_face", { x: -40, y: 28, z: -1360, lx: -170, ly: 18, lz: -1220 });

await page.evaluate(() => {
  const A = window.ASCII_AIR;
  A.backToTitle?.();
  ["hud","hud-stats","hud-compass","hud-mission","hud-minimap","hud-flight","hud-photo","hud-aux","hud-msg","hud-fs","hud-hint","mobile-layer","overlay"].forEach((id)=>{const e=document.getElementById(id);if(e)e.style.display="none";});
  const ts = document.getElementById("title-screen");
  if (ts) ts.style.display = "";
  A.setTime(11); A.setWeather("clear");
  A.setPaused(true); A.render();
});
await page.screenshot({ path: `${ROOT}/01_title.png`, type: "png" });
console.log("TITLE");
console.log("ERRORS", errors.length, errors.slice(0, 6));
await b.close();

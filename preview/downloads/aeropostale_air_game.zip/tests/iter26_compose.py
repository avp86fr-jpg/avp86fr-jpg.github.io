#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path("/workspace/ascii_air/delivery/shots")
COVER = Path("/workspace/ascii_air/refs/covers/cover_16x9.png")
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_S = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

def font(sz):
    try:
        return ImageFont.truetype(FONT, sz)
    except Exception:
        return ImageFont.load_default()

def font_s(sz):
    try:
        return ImageFont.truetype(FONT_S, sz)
    except Exception:
        return ImageFont.load_default()

def fit_cover(im, w, h):
    im = im.convert("RGB")
    sw, sh = im.size
    scale = max(w / sw, h / sh)
    nw, nh = int(sw * scale), int(sh * scale)
    im = im.resize((nw, nh), Image.Resampling.LANCZOS)
    left, top = (nw - w) // 2, (nh - h) // 2
    return im.crop((left, top, left + w, top + h))

def fit_contain(im, w, h, bg=(18, 20, 24)):
    im = im.convert("RGB")
    sw, sh = im.size
    scale = min(w / sw, h / sh)
    nw, nh = max(1, int(sw * scale)), max(1, int(sh * scale))
    im = im.resize((nw, nh), Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", (w, h), bg)
    canvas.paste(im, ((w - nw) // 2, (h - nh) // 2))
    return canvas

def headered(cells, out, title, cell_w=1280, cell_h=740, cols=2, caption=None, contain=False):
    rows = (len(cells) + cols - 1) // cols
    pad, head, foot = 16, 72, 40 if caption else 16
    lab_h = 42
    W = cols * cell_w + (cols + 1) * pad
    H = head + rows * (cell_h + lab_h + pad) + foot
    canvas = Image.new("RGB", (W, H), (18, 20, 24))
    d = ImageDraw.Draw(canvas)
    d.text((pad, 18), title, font=font(32), fill=(240, 236, 228))
    if caption:
        d.text((pad, H - foot + 10), caption, font=font_s(16), fill=(180, 176, 168))
    for i, (label, path) in enumerate(cells):
        r, c = divmod(i, cols)
        x = pad + c * (cell_w + pad)
        y = head + r * (cell_h + lab_h + pad)
        d.text((x, y), label, font=font(20), fill=(220, 214, 200))
        p = Path(path)
        if p.exists():
            im = Image.open(p)
            cell = fit_contain(im, cell_w, cell_h) if contain else fit_cover(im, cell_w, cell_h)
            canvas.paste(cell, (x, y + lab_h))
        else:
            d.rectangle((x, y + lab_h, x + cell_w, y + lab_h + cell_h), fill=(40, 42, 48))
            d.text((x + 24, y + lab_h + 24), f"missing: {p.name}", font=font_s(18), fill=(200, 80, 80))
    out.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(out, "PNG", optimize=True)
    print("wrote", out, canvas.size)

def main():
    headered(
        [
            ("The Hanging Keep", ROOT / "beauty/01_keep.png"),
            ("Cliff ruins", ROOT / "beauty/02_castle.png"),
            ("Harbor town", ROOT / "beauty/03_village.png"),
            ("Cinder Cape Light", ROOT / "beauty/04_lighthouse.png"),
            ("Mill hills", ROOT / "beauty/05_mills.png"),
            ("Mistfall", ROOT / "beauty/06_waterfall.png"),
        ],
        ROOT / "beauty/sheet_2x3.png",
        "AEROPOSTALE AIR  —  beauty",
        cell_w=960, cell_h=540, cols=3,
    )
    headered(
        [
            ("Title  ·  1920×1080", ROOT / "title/title_day.png"),
            ("Title  ·  1280×720", ROOT / "title/title_1280.png"),
            ("Title  ·  844×390  landscape", ROOT / "title/title_mobile.png"),
            ("Title  ·  390×844  portrait", ROOT / "title/title_portrait.png"),
            ("Free ride start", ROOT / "freeride/start_pc.png"),
            ("Hero postcard", ROOT / "heroes/hero_day.png"),
        ],
        ROOT / "ui/presentation_sheet.png",
        "AEROPOSTALE AIR  —  presentation",
        cell_w=960, cell_h=540, cols=3,
        contain=True,
        caption="Title screens use official cover art (16×9 landscape, 3×4 portrait). Buttons sit in a safe bottom bar — measured unclipped at all four sizes.",
    )
    headered(
        [
            ("Official cover  ·  16×9", COVER),
            ("In-game hero", ROOT / "heroes/hero_day.png"),
            ("Cover  —  floating island (crop)", COVER),
            ("In-game  —  The Hanging Keep", ROOT / "beauty/01_keep.png"),
        ],
        ROOT / "compare/game_vs_cover.png",
        "AEROPOSTALE AIR  —  game vs official cover",
        cell_w=1280, cell_h=720, cols=2,
        caption="Cover is the art-direction target: cream-wing / red-fuselage biplane, terracotta village, turquoise sea, arched ruins on a green floating island, huge sunlit cumulus.",
    )
    # A tighter crop of the cover's island for the third cell would be nicer;
    # re-do that cell with a crop.
    sheet = Image.open(ROOT / "compare/game_vs_cover.png")
    cover = Image.open(COVER).convert("RGB")
    # island is in the upper-right of the 16:9 cover
    w, h = cover.size
    crop = cover.crop((int(w * 0.55), int(h * 0.02), int(w * 0.99), int(h * 0.58)))
    # paste into the third cell of a 2-col 1280x720 sheet
    # We'll just rebuild that one comparison as-is; crop saved beside
    crop.save(ROOT / "compare/cover_keep_crop.png")
    headered(
        [
            ("Official cover  ·  16×9", COVER),
            ("In-game hero", ROOT / "heroes/hero_day.png"),
            ("Cover  —  floating island", ROOT / "compare/cover_keep_crop.png"),
            ("In-game  —  The Hanging Keep", ROOT / "beauty/01_keep.png"),
        ],
        ROOT / "compare/game_vs_cover.png",
        "AEROPOSTALE AIR  —  game vs official cover",
        cell_w=1280, cell_h=720, cols=2,
        contain=True,
        caption="Cover is the art-direction target: cream-wing / red-fuselage biplane, terracotta village, turquoise sea, arched ruins on a green floating island, huge sunlit cumulus.",
    )

    headered(
        [
            ("Keep close-up", ROOT / "beauty/01_keep_close.png"),
            ("Keep from the approach", ROOT / "beauty/01_keep.png"),
            ("Keep from above", ROOT / "beauty/01_keep_above.png"),
            ("Cover  —  floating island", ROOT / "compare/cover_keep_crop.png"),
        ],
        ROOT / "beauty/sheet_keep_close.png",
        "AEROPOSTALE AIR  —  The Hanging Keep close-up",
        cell_w=1280, cell_h=720, cols=2,
        contain=True,
        caption="Crisp painted limestone planes, thick 3D arches and columns, bright leafy masses on the crown and rims, falls into mist.",
    )
    headered(
        [
            ("Harbor town houses", ROOT / "beauty/14_house_close.png"),
            ("Harbor docks and boats", ROOT / "beauty/09_harbor.png"),
            ("Market street", ROOT / "beauty/08_market.png"),
            ("Mill hills and fields", ROOT / "beauty/13_fields.png"),
            ("Wayside chapel", ROOT / "beauty/11_chapel.png"),
            ("Cape south face", ROOT / "beauty/12_cape_face.png"),
        ],
        ROOT / "beauty/sheet_world_life.png",
        "AEROPOSTALE AIR  —  world and life",
        cell_w=960, cell_h=540, cols=3,
        caption="Detailed village houses, stone quay and fishing boats, market, field breakup, chapels and the cape face.",
    )

if __name__ == "__main__":
    main()

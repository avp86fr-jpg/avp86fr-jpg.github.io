import puppeteer from "puppeteer-core";
import { mkdirSync } from "fs";

const OUT = "/workspace/ascii_air/delivery/shots/qa";
mkdirSync(OUT, { recursive: true });

const MISSIONS = [
  { id: "rings-b1", label: "m1_rings", yOff: 0, kind: "rings" },
  { id: "mail-b1", label: "m2_mail", yOff: 18, kind: "stops" },
  { id: "storm-b1", label: "m3_storm", yOff: 28, kind: "stops" },
  { id: "night-b1", label: "m4_night", yOff: 18, kind: "stops" },
  { id: "res-b1", label: "m5_rescue", yOff: 22, kind: "stops" },
];

const VIEWS = [
  { name: "pc", w: 1920, h: 1080 },
  { name: "mobile", w: 844, h: 390 },
];

const b = await puppeteer.launch({
  executablePath: "/usr/bin/google-chrome-stable",
  headless: "new",
  args: ["--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader","--no-sandbox","--disable-dev-shm-usage","--window-size=1920,1080"],
});
const page = await b.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });
await page.goto("http://127.0.0.1:8765/?v=" + Date.now(), { waitUntil: "domcontentloaded", timeout: 60000 });
await page.waitForFunction(() => window.ASCII_AIR && window.ASCII_AIR.ready, { timeout: 90000 });

let failed = 0;
const log = [];
function pass(name, cond, extra) {
  const ok = !!cond;
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}` + (extra ? "  " + JSON.stringify(extra) : ""));
  if (!ok) failed++;
  return ok;
}

for (const view of VIEWS) {
  await page.setViewport({ width: view.w, height: view.h, deviceScaleFactor: 1 });
  await page.evaluate(() => window.dispatchEvent(new Event("resize")));

  for (const m of MISSIONS) {
    const start = await page.evaluate((id) => {
      const A = window.ASCII_AIR;
      A.setPaused(false);
      A.startMission(id);
      A.render();
      const hud = {
        mission: (document.getElementById("hud-mission") || {}).textContent || "",
        stats: (document.getElementById("hud-stats") || {}).textContent || "",
      };
      return { info: A.getCamInfo(), mid: A.missions.state.active && A.missions.state.active.id, hour: A.clock.hour, weather: A.weather && A.weather.state && A.weather.state.id, hud, crashed: !!A.craft.crashed };
    }, m.id);
    const shot0 = `${OUT}/${m.label}_${view.name}_start.png`;
    await page.screenshot({ path: shot0, type: "png" });

    const mid = await page.evaluate((kind, yOff) => {
      const A = window.ASCII_AIR;
      const st = () => A.missions.state;
      const act = st().active;
      if (kind === "rings") {
        const r = (act.rings || [])[0];
        if (r) { A.teleport(r.x, r.y, r.z); A.setThrottle(0.8); A.advance(0.3); A.render(); }
      } else {
        const s = (act.stops || [])[0];
        if (s) {
          const y = s.y != null ? s.y : (A.island.heightAt(s.x, s.z) + yOff);
          A.teleport(s.x, y, s.z);
          A.setThrottle(0.75);
          A.advance(0.25);
          A.render();
        }
      }
      return { info: A.getCamInfo(), next: st().next, rings: st().ringsPassed, hasBag: st().mailHasBag, result: st().result && { stars: st().result.stars, line: st().result.line }, crashed: !!A.craft.crashed, hud: (document.getElementById("hud-mission") || {}).textContent || "" };
    }, m.kind, m.yOff);
    const shot1 = `${OUT}/${m.label}_${view.name}_mid.png`;
    await page.screenshot({ path: shot1, type: "png" });

    const end = await page.evaluate((kind, yOff) => {
      const A = window.ASCII_AIR;
      const st = () => A.missions.state;
      const act = st().active;
      if (kind === "rings") {
        const rings = act.rings || [];
        for (const r of rings) {
          A.teleport(r.x, r.y, r.z);
          A.advance(0.2);
        }
        A.render();
      } else {
        for (const s of (act.stops || [])) {
          const y = s.y != null ? s.y : (A.island.heightAt(s.x, s.z) + yOff);
          A.teleport(s.x, y, s.z);
          A.advance(0.2);
        }
        A.render();
      }
      return { info: A.getCamInfo(), result: st().result && { stars: st().result.stars, line: st().result.line }, next: st().next, rings: st().ringsPassed, crashed: !!A.craft.crashed, hud: (document.getElementById("hud-mission") || {}).textContent || "" };
    }, m.kind, m.yOff);
    const shot2 = `${OUT}/${m.label}_${view.name}_end.png`;
    await page.screenshot({ path: shot2, type: "png" });

    const tag = `${m.label}/${view.name}`;
    pass(`${tag} started`, start.mid === m.id, start);
    pass(`${tag} camera follows at start`, start.info.dist >= 12 && start.info.dist <= 55 && !start.info.camOverride, start.info);
    pass(`${tag} camera follows mid`, mid.info.dist >= 12 && mid.info.dist <= 55 && !mid.crashed, mid.info);
    pass(`${tag} completed with stars`, end.result && end.result.stars > 0 && !end.crashed, end);
    const french = /bague|atterriss|vent:|prendre |cours |niveaux/i;
    const hudAll = (start.hud.mission + start.hud.stats + mid.hud + end.hud);
    pass(`${tag} English HUD`, !french.test(hudAll), { hud: hudAll.slice(0, 180) });
    log.push({ tag, start, mid, end });
  }
}

console.log("SUMMARY", { failed, errors: errors.length, errorSample: errors.slice(0, 4) });
await b.close();
process.exit(failed || errors.length ? 1 : 0);

AEROPOSTALE AIR
Standalone offline copy

This folder is a complete, self-contained build. All assets use relative paths.
No internet connection is required once you have unzipped it.

Because the game loads as ES modules, open it through a local web server,
not as a file:// page.

  cd AEROPOSTALE_AIR
  python3 -m http.server 8765

Then open http://127.0.0.1:8765/ in your browser.

Built from preview commit dcbbfea (28 Nov 2026).

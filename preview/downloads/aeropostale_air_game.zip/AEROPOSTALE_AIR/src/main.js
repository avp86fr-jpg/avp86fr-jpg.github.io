import * as THREE from "three";
import { CAM, PHYS, DEFAULT_SETTINGS, PLANES, SPAWN, STAR_UNLOCKS, VERSION, MAT, HERO_VIEW } from "./core/config.js";
import { isMobileUA, isIOS, isStandalone, nowMs, clamp, headingFromXZ } from "./core/utils.js";
import { createLigneClaire } from "./post/ligneClaire.js";
import { getIdMaterial, tagMesh, patchMaterialIdAlpha, retagGeometry } from "./render/idMaterial.js";
import { makeColorDepthRT, makeRT } from "./render/targets.js";
import { createBloom } from "./post/bloom.js";
import { createIsland } from "./world/island.js";
import { createWeather } from "./world/weather.js";
import { createFeelFX } from "./world/fx.js";
import { createPlaneMesh } from "./flight/planes.js";
import { createCraft, resetCraft, launchCraft, stepCraft, startTow } from "./flight/physics.js";
import { createFlightCamera } from "./flight/camera.js";
import { createInput } from "./input/input.js";
import { createAudio } from "./audio/audio.js";
import { loadSave, persist, awardStars, awardPay, buyUpgrade, saveSettings, savePhoto, applyUnlocks, totalStars } from "./save/save.js";
import { createMissionSystem } from "./missions/runtime.js";
import { getMission, MISSIONS, DOGFIGHTS } from "./missions/data.js";
import { createCombat } from "./combat/dogfight.js";
import { createUI } from "./ui/ui.js";
import { createDebug, autopilot } from "./debug/debug.js";
import { createClock } from "./time/cycle.js";
import { QUALITY } from "./core/config.js";
import { texturesReady } from "./render/textured.js";

const canvas = document.getElementById("view");
const uiRoot = document.getElementById("ui-root");

const save = loadSave();
applyUnlocks(save);
const settings = save.settings;

const input = createInput(uiRoot);
const audio = createAudio();
const hooks = { input, audio };
const ui = createUI(uiRoot, {
  input, audio,
  onFreeFlight: () => startFreeFlight(),
  onStartMission: (id) => startMission(id),
  onSelectPlane: (id) => { save.plane = id; persist(save); rebuildPlane(id); },
  onOnboard: () => startOnboarding(),
  onBuyUpgrade: (id) => {
    const ok = buyUpgrade(save, id);
    if (ok) applyUpgrades(craft);
    return ok;
  },

  onSettings: (s) => { Object.assign(settings, s); saveSettings(save, s); audio.setVolumes(s); applyVisualSettings(); },
  onToggleGyro: () => toggleGyro(),
  onCamera: () => flyCam.cycle(),
  onPause: () => togglePause(),
  onResume: () => { paused = false; mode = "fly"; ui.showHUD(); },
  onGear: () => { craft.gearDown = !craft.gearDown; audio.play("gear"); },
  onFullscreen: () => toggleFullscreen(),
  onRestart: () => restartCurrent(),
  onQuit: () => backToTitle(),
  onNextMission: () => nextMission(),
  onOrbitDrag: (dx, dy) => flyCam.orbitDrag(dx, dy),
  onOrbitRelease: () => flyCam.orbitRelease(),
  onOrbitReset: () => flyCam.orbitReset(),
});
hooks.onFreeFlight = () => startFreeFlight();
hooks.onStartMission = (id) => startMission(id);
hooks.onSelectPlane = (id) => { save.plane = id; persist(save); rebuildPlane(id); };
hooks.onSettings = (s) => { Object.assign(settings, s); saveSettings(save, s); audio.setVolumes(s); applyVisualSettings(); };
hooks.onToggleGyro = () => toggleGyro();
hooks.onCamera = () => flyCam.cycle();
hooks.onPause = () => togglePause();
hooks.onResume = () => { paused = false; mode = "fly"; ui.showHUD(); };
hooks.onGear = () => { craft.gearDown = !craft.gearDown; audio.play("gear"); };
hooks.gearDown = () => !!(craft && craft.gearDown);
hooks.onFullscreen = () => toggleFullscreen();
hooks.onRestart = () => restartCurrent();
hooks.onQuit = () => backToTitle();
hooks.onNextMission = () => nextMission();
hooks.onOrbitDrag = (dx, dy) => flyCam.orbitDrag(dx, dy);
hooks.onOrbitRelease = () => flyCam.orbitRelease();
hooks.onOrbitReset = () => flyCam.orbitReset();

const renderer = new THREE.WebGLRenderer({
  canvas, antialias: false, alpha: false, powerPreference: "high-performance",
  stencil: false, depth: true, preserveDrawingBuffer: true,
});
renderer.setPixelRatio(1);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.autoClear = false;
renderer.info.autoReset = false;
renderer.setClearColor(0x8ed7f5, 1);
const backend = renderer.capabilities.isWebGL2 ? "WebGL2" : "WebGL1";

const scene = new THREE.Scene();
const combat = createCombat(scene);
const camera = new THREE.PerspectiveCamera(CAM.fov, 16 / 9, CAM.near, CAM.far);
const flyCam = createFlightCamera(camera);

const look = createLigneClaire();
const bloom = createBloom();
const idMat = getIdMaterial();

let grid = { cols: 1920, rows: 1080, cell: 1 };
let colorRT = null, bloomA = null, bloomB = null;

function allocTargets() {
  const cssW = canvas.clientWidth || window.innerWidth;
  const cssH = canvas.clientHeight || window.innerHeight;
  const q = QUALITY[settings.quality] || QUALITY.medium;
  const mobile = isMobileUA() || cssW < 820;
  const dprCap = mobile ? (settings.quality === "high" ? 1.5 : 1.25) : (settings.quality === "low" ? 1 : 1.5);
  const dpr = Math.min(window.devicePixelRatio || 1, dprCap);
  let outW = Math.max(320, Math.round(cssW * dpr));
  let outH = Math.max(180, Math.round(cssH * dpr));
  const longCap = mobile ? (settings.quality === "high" ? 1600 : settings.quality === "low" ? 1024 : 1280)
    : (settings.quality === "low" ? 1440 : 1920);
  const long = Math.max(outW, outH);
  if (long > longCap) {
    const s = longCap / long;
    outW = Math.max(320, Math.round(outW * s));
    outH = Math.max(180, Math.round(outH * s));
  }
  renderer.setSize(outW, outH, false);
  grid = { cols: outW, rows: outH, cell: 1 };
  const dispose = (rt) => { if (rt) rt.dispose(); };
  dispose(colorRT); dispose(bloomA); dispose(bloomB);
  colorRT = makeColorDepthRT(outW, outH, THREE.LinearFilter);
  const bw = Math.max(64, outW >> 2), bh = Math.max(36, outH >> 2);
  bloomA = makeRT(bw, bh);
  bloomB = makeRT(bw, bh);
  look.uniforms.uRes.value.set(outW, outH);
  look.uniforms.uNearFar.value.set(camera.near, camera.far);
  camera.aspect = cssW / Math.max(1, cssH);
  camera.updateProjectionMatrix();
}

const clock = createClock(10);
ui.setLoad(0.05, "raising the island…");

let island = null;
let weather = null;
let feel = null;
let craft = createCraft(save.plane || "trainer");
let planeMesh = null;
let contrail = null;
let missions = null;
const dbg = createDebug(uiRoot);
contrail = createContrail(scene);

function rebuildPlane(id) {
  if (planeMesh) scene.remove(planeMesh);
  planeMesh = createPlaneMesh(id, PLANES[id]);
  flattenLook(planeMesh);
  scene.add(planeMesh);
  if (craft.id !== id) resetCraft(craft, SPAWN.airport, SPAWN.airport.heading, id);
  applyUpgrades(craft);
}

function applyUpgrades(c) {
  const u = (save && save.upgrades) || {};
  const base = PLANES[c.id] || PLANES.trainer;
  const def = { ...base };
  if (u.tight) {
    def.rollRate = (base.rollRate || 1.6) * 1.18;
    def.pitchRate = (base.pitchRate || 1.3) * 1.12;
    def.yawRate = (base.yawRate || 0.9) * 1.1;
  }
  if (u.pace) {
    def.maxSpeed = (base.maxSpeed || 68) * 1.08;
    def.maxThrust = (base.maxThrust || 3200) * 1.08;
    def.cruise = (base.cruise || 46) * 1.06;
  }
  c.def = def;
  c.upgrades = { ...u };
}

function applyVisualSettings() {
  look.uniforms.uContrast.value = settings.highContrast ? 1.12 : 1.04;
  look.uniforms.uOutline.value = settings.highContrast ? 0.72 : 0.26;
  look.uniforms.uBloom.value = (QUALITY[settings.quality] || QUALITY.medium).bloom ? 0.26 : 0.0;
  flyCam.state.comfort = !!settings.motionComfort;
  audio.setVolumes(settings);
  allocTargets();
}

// Auto quality hint
if (!save.settings._autoQ && isMobileUA()) {
  settings.quality = "low";
  save.settings._autoQ = true;
  save.settings.quality = "low";
}

let mode = "boot"; // boot | title | fly
let paused = false;
let currentMissionId = null;
let accum = 0;
let lastT = nowMs();
let fps = 60, frameMs = 16, fpsAcc = 0, fpsN = 0;
let lastFpsT = nowMs();
let autoPilotOn = false;
let camOverride = null;
let autoPilotTarget = null;
let autoPilotOpts = {};
let pendingResult = null;

function markLast(mode, missionId) {
  save.lastMode = mode;
  if (missionId) save.lastMission = missionId;
  persist(save);
}

function startOnboarding() {
  const cards = [
    { who: "Skipper Wren", text: "Welcome to the island run. Hold BOOST or Space and the Courrier will take itself into the air." },
    { who: "Skipper Wren", text: "Arrows or the stick turn and pitch. The gold pointer marks your next hoop — wind will nudge the rings, so look twice." },
    { who: "Pip", text: "Keep a streak by threading posts without a long pause. When you are ready, the bag is waiting. I will be on your wing if the Gale turns up." },
  ];
  ui.showStory(cards, () => {
    save.seenIntro = true;
    persist(save);
    startMission("rings-b1");
  });
}

function startFreeFlight() {
  audio.unlock();
  currentMissionId = null;
  missions.clear();
  combat.end();
  const id = save.unlocked[save.plane] ? save.plane : "trainer";
  const base = SPAWN.free || SPAWN.airport;
  const x = base.x, z = base.z;
  const heading = Number.isFinite(base.heading) ? base.heading : Math.PI / 2;
  const gear = (PLANES[id] && PLANES[id].gearHeight) || 1.15;
  const ground = (island && typeof island.heightAt === "function") ? island.heightAt(x, z) : 0;
  const overWater = !Number.isFinite(ground) || ground < 2.0;
  const y = overWater ? (base.y || 32) : (ground + gear + 22);
  const spawn = { x, y, z, heading };
  resetCraft(craft, spawn, heading, id);
  craft.onGround = false;
  craft.airspeed = 36;
  craft.throttle = 0.64;
  if (craft.verticalSpeed != null) craft.verticalSpeed = 0;
  if (craft.pitch != null) craft.pitch = 0.02;
  craft.roll = 0.32;
  rebuildPlane(craft.id);
  clock.frozen = false;
  if (clock.hour < 6 || clock.hour > 20) clock.set(10);
  flyCam.state.mode = "chase";
  flyCam.state.hero = false;
  camOverride = null;
  flyCam.orbitReset();
  if (weather) weather.set("clear");
  mode = "fly";
  paused = false;
  autoPilotOn = false;
  input.resetThrottleLever?.(0);
  flyCam.hardSnap ? flyCam.hardSnap(craft, ui.isPortrait()) : flyCam.snap(craft, ui.isPortrait());
  syncPlaneMesh();
  markLast("free");
  autoPilotTarget = null;
  ui.setHideFlyHint(false);
  ui.showHUD();
  audio.setMusic(clock.hour > 19 || clock.hour < 6 ? "music_night" : "music_day", 0.55);
}

function startMission(id) {
  audio.unlock();
  const m = getMission(id);
  if (!m) return;
  currentMissionId = id;
  const pid = m.plane || "trainer";
  resetCraft(craft, m.start || SPAWN.airport, (m.start && m.start.heading) || SPAWN.airport.heading, pid);
  rebuildPlane(pid);
  if (m.start) launchCraft(craft, m.start.speed || 40, 0);
  missions.start(m, craft);
  if (m.activity === "dogfight") combat.start(m, craft);
  else combat.end();
  const holdStory = !!(m.activity === "dogfight" && m.story && m.story.length);
  autoPilotOn = false;
  autoPilotTarget = null;
  clock.set(m.hour ?? 10);
  clock.frozen = true;
  flyCam.state.mode = "chase";
  flyCam.state.hero = false;
  camOverride = null;
  flyCam.orbitReset();
  if (weather) weather.set(m.weather || "clear");
  if (island && island.sky && typeof island.sky.setHour === "function") island.sky.setHour(clock.hour);
  const wet = !!(weather && (weather.state.id === "storm" || weather.state.id === "squall"));
  if (island && typeof island.setStorm === "function") island.setStorm(wet, weather && weather.state.windKt);
  if (island && typeof island.update === "function") island.update(0, performance.now() / 1000, clock.hour, camera);
  if (m.activity === "landing") { craft.flaps = 1; }
  mode = "fly";
  paused = holdStory;
  pendingResult = null;
  markLast("mission", id);
  input.resetThrottleLever?.(0.75);
  flyCam.hardSnap ? flyCam.hardSnap(craft, ui.isPortrait()) : flyCam.snap(craft, ui.isPortrait());
  syncPlaneMesh();
  if (flyCam.playIntro) flyCam.playIntro(2.5);
  ui.setHideFlyHint(true);
  if (holdStory) ui.showStory(m.story, () => { paused = false; ui.showHUD(); });
  else ui.showHUD();
  audio.setMusic(m.hour >= 19 || m.hour < 6 ? "music_night" : "music_day", 0.5);
}

function restartCurrent() {
  if (currentMissionId) startMission(currentMissionId);
  else startFreeFlight();
}

function nextMission() {
  if (!currentMissionId) { backToTitle(); return; }
  const di = DOGFIGHTS.findIndex((m) => m.id === currentMissionId);
  if (di >= 0) {
    startMission(DOGFIGHTS[(di + 1) % DOGFIGHTS.length].id);
    return;
  }
  const i = MISSIONS.findIndex((m) => m.id === currentMissionId);
  const n = MISSIONS[(i + 1) % MISSIONS.length];
  startMission(n.id);
}

function backToTitle() {
  camOverride = null;
  missions.clear();
  combat.end();
  currentMissionId = null;
  pendingResult = null;
  paused = false;
  mode = "title";
  flyCam.state.mode = "title";
  clock.frozen = true;
  clock.set(10.5);
  ui.showTitle(save);
  audio.setMusic("music_day", 0.45);
  // park a plane on the runway for the title loop
  const hx = HERO_VIEW.plane.x, hy = HERO_VIEW.plane.y, hz = HERO_VIEW.plane.z;
  const hdg = headingFromXZ(HERO_VIEW.look.x - hx, HERO_VIEW.look.z - hz);
  resetCraft(craft, { x: hx, y: hy, z: hz, heading: hdg }, hdg, save.plane || "trainer");
  launchCraft(craft, 46, 0);
  const vis = planeMesh && planeMesh.getObjectByName("plane-visual");
  if (vis) vis.scale.setScalar(1.32 * (HERO_VIEW.planeScale || 1));
  autoPilotOn = true;
  autoPilotTarget = { x: HERO_VIEW.look.x, y: (HERO_VIEW.look.y || 50) + 20, z: HERO_VIEW.look.z };
  autoPilotOpts = { speed: 44 };
}

function togglePause() {
  if (mode !== "fly") return;
  paused = !paused;
  if (paused) ui.showPause(save);
  else { ui.closeOverlay(); ui.showHUD(); }
}

async function toggleFullscreen() {
  if (isIOS() && !isStandalone()) {
    ui.showTitle(save); // hint already visible on title; also toast via overlay?
    return;
  }
  try {
    if (!document.fullscreenElement && !document.webkitFullscreenElement) {
      const el = document.getElementById("game");
      const req = el.requestFullscreen || el.webkitRequestFullscreen;
      if (req) await req.call(el);
      if (screen.orientation && screen.orientation.lock && window.innerWidth < 900) {
        try { await screen.orientation.lock("landscape"); } catch {}
      }
    } else {
      const ex = document.exitFullscreen || document.webkitExitFullscreen;
      if (ex) await ex.call(document);
    }
  } catch (err) { console.warn("fullscreen", err); }
}

async function toggleGyro() {
  if (settings.gyroEnabled) {
    input.disableGyro();
    settings.gyroEnabled = false;
    saveSettings(save, settings);
    return;
  }
  const ok = await input.setGyro(true);
  if (ok) {
    input.calibrateGyro();
    settings.gyroEnabled = true;
    saveSettings(save, settings);
  }
}

function handleCraftEvents() {
  const ev = craft.events;
  if (!ev || !ev.length) return;
  for (const e of ev) {
    if (e === "touchdown") {
      audio.play("touchdown");
      feel?.touchdown(craft.pos, craft.heading, craft.lastSurface || "runway");
      flyCam.bump(0.48);
    }
    if (e === "rough") {
      audio.play("touchdown");
      flyCam.bump(0.5);
      feel?.touchdown(craft.pos, craft.heading, craft.lastSurface || "runway");
    }
    if (e === "splash") {
      audio.play("splash");
      feel?.touchdown(craft.pos, craft.heading, "water");
    }
    if (e === "crash") { audio.play("crash"); flyCam.bump(1.2); }
    if (e === "tow-release") audio.play("tow_release");
  }
  craft.events = [];
}

function maybeRespawn() {
  if (craft.crashed && craft.crashTimer <= 0) {
    const sp = craft.spawn || SPAWN.airport;
    resetCraft(craft, sp, sp.heading, craft.id);
    if (currentMissionId) {
      const m = getMission(currentMissionId);
      if (m?.start) launchCraft(craft, m.start.speed || 40, 0);
    }
  }
}

function flattenLook(root) {
  if (!root) return;
  root.traverse((o) => {
    const mats = o.material ? (Array.isArray(o.material) ? o.material : [o.material]) : [];
    for (const m of mats) {
      if (!m || m.userData._flat) continue;
      if (m.vertexColors) { m.userData._flat = true; continue; }
      if (m.isMeshLambertMaterial || m.isMeshPhongMaterial || m.isMeshStandardMaterial) {
        const c = (m.color && m.color.clone) ? m.color.clone() : new THREE.Color(0xffffff);
        m.emissive = c.multiplyScalar(0.45);
        m.emissiveIntensity = 0.45;
        if (m.shininess != null) m.shininess = 0;
        m.userData._flat = true;
      }
    }
  });
}

let groundShadow = null;
function ensureShadow() {
  if (groundShadow) return;
  const geo = new THREE.CircleGeometry(4.4, 20);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({ color: 0x1a140e, transparent: true, opacity: 0.28, depthWrite: false });
  groundShadow = new THREE.Mesh(geo, mat);
  groundShadow.renderOrder = 2;
  groundShadow.name = "ground-shadow";
  scene.add(groundShadow);
}

function syncPlaneMesh() {
  if (!planeMesh) return;
  planeMesh.position.copy(craft.pos);
  planeMesh.quaternion.copy(craft.quat);
  if (planeMesh.userData.prop && craft.def.engine) {
    const rpm = 0.4 + craft.throttle * 2.6 + craft.airspeed * 0.035;
    planeMesh.userData.prop.rotation.z += rpm;
    const blur = planeMesh.userData.propBlur;
    if (blur && blur.material) {
      const k = Math.min(1, craft.throttle * 0.7 + craft.airspeed / 90);
      blur.material.opacity = 0.1 + k * 0.28;
      blur.visible = k > 0.12;
    }
    const blades = planeMesh.userData.propBlades;
    if (blades) for (const b of blades) if (b.material) b.material.opacity = Math.max(0.08, 0.6 - (craft.throttle * 0.45));
  }
  const ud = planeMesh.userData;
  if (ud.elevator) ud.elevator.rotation.x = Math.max(-0.35, Math.min(0.35, -(craft.pitch || 0) * 0.45));
  if (ud.rudder) ud.rudder.rotation.y = Math.max(-0.35, Math.min(0.35, (craft.yawRate || craft.angVel?.y || 0) * 0.4));
  if (ud.ailL) ud.ailL.rotation.x = Math.max(-0.35, Math.min(0.35, (craft.roll || 0) * 0.5));
  if (ud.ailR) ud.ailR.rotation.x = Math.max(-0.35, Math.min(0.35, -(craft.roll || 0) * 0.5));
  if (contrail) {
    const airborne = !craft.onGround && !craft.crashed && craft.airspeed > 18;
    const tail = new THREE.Vector3(0, 0.2, 4).applyQuaternion(craft.quat).add(craft.pos);
    contrail.update(tail, airborne);
  }
  if (groundShadow && island) {
    const gy = Math.max(island.heightAt(craft.pos.x, craft.pos.z), 0.05);
    groundShadow.position.set(craft.pos.x, gy + 0.08, craft.pos.z);
    const agl = Math.max(0.5, craft.pos.y - gy);
    const s = 4.4 * (1 + agl * 0.03);
    groundShadow.scale.set(s / 4.4, 1, s / 4.4 * 0.7);
    groundShadow.material.opacity = 0.28 * (1 / (1 + agl * 0.045));
    groundShadow.visible = !craft.crashed;
  }
  const ink = planeMesh.userData && planeMesh.userData.ink;
  if (ink && camera) {
    const dx = camera.position.x - craft.pos.x;
    const dy = camera.position.y - craft.pos.y;
    const dz = camera.position.z - craft.pos.z;
    const d2 = dx * dx + dy * dy + dz * dz;
    ink.visible = d2 >= 22 * 22 && d2 < 200 * 200;
  }
}

function coastalAmt() {
  const h = island.heightAt(craft.pos.x, craft.pos.z);
  if (h < 6) return clamp(1 - h / 6, 0, 1);
  // also near shoreline by altitude? use distance to water: if agl high, still hear waves if over water
  return h < 0.5 ? 1 : 0;
}


function createContrail(sc) {
  const N = 36;
  const geo = retagGeometry(new THREE.SphereGeometry(0.14, 5, 4), MAT.CLOUD, 1);
  const mat = new THREE.MeshBasicMaterial({ color: 0xb8deff });
  patchMaterialIdAlpha(mat);
  const inst = new THREE.InstancedMesh(geo, mat, N);
  inst.frustumCulled = false;
  inst.count = 0;
  inst.name = "contrail";
  sc.add(inst);
  const dummy = new THREE.Object3D();
  const hist = [];
  return {
    clear() { hist.length = 0; inst.count = 0; inst.instanceMatrix.needsUpdate = true; },
    update(pos, flying) {
      if (flying && pos) {
        if (!hist.length || hist[hist.length - 1].distanceTo(pos) > 1.6) {
          hist.push(pos.clone());
          if (hist.length > N) hist.shift();
        }
      } else if (hist.length) hist.shift();
      inst.count = hist.length;
      for (let i = 0; i < hist.length; i++) {
        const t = i / Math.max(1, hist.length - 1);
        dummy.position.copy(hist[i]);
        dummy.scale.setScalar(0.18 + t * 0.55);
        dummy.updateMatrix();
        inst.setMatrixAt(i, dummy.matrix);
      }
      inst.instanceMatrix.needsUpdate = true;
    },
  };
}

function renderFrame(time, camDt = 1 / 60) {
  renderer.info.reset();
  const cssW = canvas.clientWidth || window.innerWidth;
  const cssH = canvas.clientHeight || window.innerHeight;
  camera.aspect = cssW / Math.max(1, cssH);
  const portrait = cssH > cssW;

  if (camOverride) {
    const p = camOverride.pos;
    if (island && typeof island.heightAt === "function") {
      let h = island.heightAt(p.x, p.z);
      for (const [dx, dz] of [[8, 0], [-8, 0], [0, 8], [0, -8], [6, 6], [-6, 6]]) {
        const hh = island.heightAt(p.x + dx, p.z + dz);
        if (hh > h) h = hh;
      }
      if (Number.isFinite(h) && p.y < h + 8) p.y = h + 8;
    }
    camera.position.copy(p);
    camera.up.set(0, 1, 0);
    camera.lookAt(camOverride.look);
    camera.updateProjectionMatrix();
  } else if (mode === "title") {
    flyCam.state.mode = "title";
    flyCam.update(camDt, craft, portrait);
  } else {
    if (flyCam.state.mode === "title") flyCam.state.mode = "chase";
    flyCam.update(camDt, craft, portrait);
  }

  look.uniforms.uTime.value = time;
  if (weather && look.uniforms.uRain) look.uniforms.uRain.value = weather.state.rain;
  if (weather && look.uniforms.uFlash) look.uniforms.uFlash.value = weather.state.flash || 0;
  if (look.uniforms.uSpeed) {
    const k = Math.max(0, Math.min(1, ((craft.airspeed || 0) - 28) / 32));
    look.uniforms.uSpeed.value = (mode === "fly" && !paused && !flyCam.state.hero && !camOverride) ? k : 0;
  }
  if (look.uniforms.uBoost) {
    const on = (mode === "fly" && !paused && !flyCam.state.hero && !camOverride && input && input.state && input.state.boost) ? 1 : 0;
    const cur = look.uniforms.uBoost.value || 0;
    look.uniforms.uBoost.value = on ? 1 : Math.max(0, cur - camDt * 2.4);
  }

  // Apply distance lod after the camera is placed so a high chain view
  // does not pay close-up life, meadow, or plane-ink draws.
  // Also tick sky/water so a paused lookFrom after a squall/storm still has daytime water.
  if (island) {
    if (island.sky && typeof island.sky.setHour === "function") island.sky.setHour(clock.hour);
    if (island.water && typeof island.water.update === "function") island.water.update(time, island.sky);
    if (island.flora && typeof island.flora.update === "function") island.flora.update(camera);
    if (island.life && typeof island.life.update === "function") {
      island.life.update(0, time, (island.sky && island.sky.night) || 0, camera);
    }
    if (island.landmarks && typeof island.landmarks.update === "function") {
      island.landmarks.update(0, time, clock.hour, (island.sky && island.sky.night) || 0, camera);
    }
  }
  syncPlaneMesh();

  renderer.setRenderTarget(colorRT);
  renderer.clear();
  renderer.render(scene, camera);

  const useBloom = (QUALITY[settings.quality] || QUALITY.medium).bloom;
  if (useBloom) {
    bloom.quad.material = bloom.extract;
    bloom.extract.uniforms.tMap.value = colorRT.texture;
    renderer.setRenderTarget(bloomA);
    renderer.clear();
    renderer.render(bloom.scene, bloom.camera);

    bloom.quad.material = bloom.blur;
    bloom.blur.uniforms.tMap.value = bloomA.texture;
    bloom.blur.uniforms.uDir.value.set(1 / bloomA.width, 0);
    renderer.setRenderTarget(bloomB);
    renderer.render(bloom.scene, bloom.camera);
    bloom.blur.uniforms.tMap.value = bloomB.texture;
    bloom.blur.uniforms.uDir.value.set(0, 1 / bloomA.height);
    renderer.setRenderTarget(bloomA);
    renderer.render(bloom.scene, bloom.camera);
    look.uniforms.tBloom.value = bloomA.texture;
    look.uniforms.uBloom.value = 0.26;
  } else {
    look.uniforms.tBloom.value = colorRT.texture;
    look.uniforms.uBloom.value = 0.0;
  }

  // Dim exposure and bloom when the lens looks into the sun or a bright cloud.
  if (look.uniforms.uExposure) {
    const _sun = (island && island.sky && island.sky.sunDir) ? island.sky.sunDir : null;
    const _fwd = look._fwd || (look._fwd = new THREE.Vector3());
    camera.getWorldDirection(_fwd);
    let into = 0;
    if (_sun) into = Math.max(0, _fwd.dot(_sun));
    look.uniforms.uExposure.value = 1.05 - into * 0.24;
    if (useBloom) look.uniforms.uBloom.value = Math.max(0.08, 0.26 - into * 0.18);
  }

  look.uniforms.tColor.value = colorRT.texture;
  look.uniforms.tDepth.value = colorRT.depthTexture;
  renderer.setRenderTarget(null);
  renderer.clear();
  renderer.render(look.scene, look.camera);
}

async function warmup() {
  ui.setLoad(0.65, "loading textures…");
  await texturesReady();
  ui.setLoad(0.7, "compiling shaders…");
  // Draw a dummy frame with a variety of objects in view so programs compile
  camera.position.set(200, 180, -400);
  camera.lookAt(0, 40, -200);
  clock.set(10);
  island.sky.setHour(10);
  allocTargets();
  renderFrame(0);
  // night variant (lights)
  island.sky.setHour(21);
  renderFrame(0.1);
  island.sky.setHour(10);
  // force finish
  const gl = renderer.getContext();
  if (gl && gl.finish) gl.finish();
  ui.setLoad(1, "ready");
}

let menuAxis = 0;
function bindKeys() {
  // UI nav when menus open — handled in step() as edge triggers
}

// PC orbit: right or middle mouse drag on the game view. Left button is unused (no conflict with flight keys).
let orbitPtr = null, orbitX = 0, orbitY = 0;
canvas.addEventListener("contextmenu", (e) => { if (mode === "fly" && !paused) e.preventDefault(); });
canvas.addEventListener("pointerdown", (e) => {
  if (mode !== "fly" || paused) return;
  if (e.button !== 1 && e.button !== 2) return;
  orbitPtr = e.pointerId; orbitX = e.clientX; orbitY = e.clientY;
  try { canvas.setPointerCapture(e.pointerId); } catch {}
  e.preventDefault();
});
canvas.addEventListener("pointermove", (e) => {
  if (e.pointerId !== orbitPtr) return;
  flyCam.orbitDrag(e.clientX - orbitX, e.clientY - orbitY);
  orbitX = e.clientX; orbitY = e.clientY;
});
const endOrbit = (e) => {
  if (e.pointerId !== orbitPtr) return;
  orbitPtr = null;
  flyCam.orbitRelease();
};
canvas.addEventListener("pointerup", endOrbit);
canvas.addEventListener("pointercancel", endOrbit);


function step(now) {
  const dtRaw = Math.min(0.05, (now - lastT) / 1000);
  lastT = now;
  const cap = settings.fpsCap === 30 ? 30 : 60;
  // we still raf; physics is fixed

  const inp = input.update(settings, dtRaw);
  if (inp.debug) dbg.on = !dbg.on;
  if (inp.fullscreen && mode !== "boot") toggleFullscreen();
  if (inp.pause && mode === "fly") togglePause();
  if (inp.camera && mode === "fly") flyCam.cycle();
  if (mode === "fly" && flyCam.setLookBack) flyCam.setLookBack(!!inp.lookBack);

  const menuOpen = mode === "title" || (ui.overlay && !ui.overlay.classList.contains("hidden")) || paused;
  if (menuOpen) {
    const keyNav = input.keys && input.keys.size > 0;
    const dir = keyNav ? 0 : (inp.pitch > 0.5 || inp.roll > 0.5 ? 1 : inp.pitch < -0.5 || inp.roll < -0.5 ? -1 : 0);
    if (dir && dir !== menuAxis) ui.menuMove(dir);
    menuAxis = dir;
    const onField = typeof document !== "undefined" && document.activeElement && document.activeElement.closest && document.activeElement.closest("button, input, textarea, select, a");
    if ((inp.actionPressed || inp.confirm) && !onField) ui.menuOk();
  } else {
    menuAxis = 0;
  }

  if (!paused && (mode === "fly" || mode === "title")) {
    // autopilot title demo + test hook
    if (autoPilotOn && autoPilotTarget) {
      const d = autopilot(craft, autoPilotTarget, inp, autoPilotOpts);
      if (d < 18 && mode === "title") {
        autoPilotTarget = {
          x: (Math.random() - 0.5) * 1600,
          y: 60 + Math.random() * 80,
          z: -400 + (Math.random() - 0.5) * 800,
        };
      }
    }

    accum += dtRaw;
    const steps = Math.min(24, Math.floor(accum / PHYS.dt));
    for (let i = 0; i < steps; i++) {
      stepCraft(craft, inp, island, PHYS.dt, settings);
      if (mode === "title" && craft.crashed) {
        craft.crashed = false;
        craft.crashTimer = 0;
        launchCraft(craft, 46, 6);
        craft.pos.y = Math.max(craft.pos.y, 80);
      }
      handleCraftEvents();
      maybeRespawn();
      accum -= PHYS.dt;
    }
    clock.step(dtRaw);
    island.update(dtRaw, now / 1000, clock.hour, camera);
    if (feel) feel.update(dtRaw);
    if (missions.applyRingNight) missions.applyRingNight(island.sky && island.sky.night || 0);
    if (weather) {
      weather.update(dtRaw, now / 1000, craft && craft.pos);
      weather.applyToCraft(craft, dtRaw);
      look.uniforms.uRain.value = weather.state.rain;
      look.uniforms.uFlash.value = weather.state.flash;
      if (island.sky && typeof island.sky.applyFlash === "function") island.sky.applyFlash(weather.state.flash);
      if (typeof island.setStorm === "function") island.setStorm(weather.state.id === "storm" || weather.state.id === "squall", weather.state.windKt);
    }

    syncPlaneMesh();

    if (mode === "fly") {
      const st = missions.update(dtRaw, now / 1000, craft, camera, inp);
      if (combat.active) {
        const c = combat.update(dtRaw, craft, inp, camera);
        const ev = c.events || {};
        if (ev.fired) audio.play("ui_ok", { gain: 0.18, playbackRate: 1.8 });
        if (ev.hits) { audio.play("balloon_pop", { gain: 0.62, playbackRate: 1.15 }); flyCam.bump(0.34); }
        if (ev.broke) audio.play(ev.broke === "boss" ? "star" : "success", { gain: 0.7 });
        if (ev.playerHit) { audio.play("stall", { gain: 0.5 }); flyCam.bump(0.42); }
        if (ev.escortHit) audio.play("stall", { gain: 0.45, playbackRate: 0.72 });
        if (ev.aceIn) audio.play("star", { gain: 0.55, playbackRate: 0.85 });
        if (c.done && !st.result) {
          missions.complete(c.stars, { line: c.line });
        }
      }
      if (st.result && !pendingResult) {
        pendingResult = st.result;
        const hadSea = !!save.unlocked.seaplane;
        const hadGlide = !!save.unlocked.glider;
        if (st.result.stars > 0) {
          awardStars(save, st.active.id, st.result.stars, { time: st.result.time, grade: st.result.grade, line: st.result.line });
          st.result.pay = awardPay(save, st.result.stars, st.result.bestStreak || 0);
        }
        const newly = [];
        if (!hadSea && save.unlocked.seaplane) newly.push("The Lagoon Skimmer is ready in the Hangar");
        if (!hadGlide && save.unlocked.glider) newly.push("The Ridge Whisper is ready in the Hangar");
        st.result.unlocked = newly;
        if (st.active && st.active.activity === "dogfight") {
          const di = DOGFIGHTS.findIndex((d) => d.id === st.active.id);
          if (di >= 0 && di + 1 < DOGFIGHTS.length) st.result.nextTitle = DOGFIGHTS[di + 1].title;
        } else if (st.active) {
          const pool = MISSIONS.filter((d) => d.activity === st.active.activity);
          const mi = pool.findIndex((d) => d.id === st.active.id);
          if (mi >= 0 && mi + 1 < pool.length) st.result.nextTitle = pool[mi + 1].title;
        }
        if (st.result.photo) {
          try {
            const data = canvas.toDataURL("image/jpeg", 0.7);
            savePhoto(save, { id: st.active.id, title: st.result.subject || st.active.title, data, when: Date.now() });
          } catch {}
        }
        if (st.result.stars > 0 && flyCam.playOutro) flyCam.playOutro(2.4);
        const res = st.result;
        const delay = res.stars > 0 ? 2400 : 700;
        setTimeout(() => {
          if (pendingResult !== res) return;
          ui.showResult(save, res);
        }, delay);
      }
      if (inp.actionPressed && craft.id === "glider" && craft.onGround && !currentMissionId) {
        startTow(craft);
      }
      if (inp.boost) flyCam.bump(0.28);
      else if (weather && weather.state && weather.state.turbulence > 0.35) {
        const g = 0.5 + 0.5 * Math.sin(now * 0.007);
        if (g > 0.82) flyCam.bump(0.10 * weather.state.turbulence);
      }
      audio.updateFlight(craft, settings, coastalAmt(), craft.thermal, weather && weather.state);
      const cue = missions.state && missions.state.winchCue;
      if (cue && String(cue).startsWith("WINCHING")) {
        if (!step._winchT || now - step._winchT > 420) {
          audio.play("gear", { gain: 0.28, playbackRate: 0.68 });
          step._winchT = now;
        }
      }
      if (craft.stalled && !craft.onGround) {
        if (!step._stallT || now - step._stallT > 280) { audio.play("stall", { gain: 0.4 }); step._stallT = now; }
      }
      ui.updateHUD(craft, missions.state, clock.hour, ui.isPortrait(), hudExtras());
    }
  }

  renderFrame(now / 1000, dtRaw);

  frameMs = dtRaw * 1000;
  fpsN++; fpsAcc += dtRaw;
  if (now - lastFpsT > 500) {
    fps = fpsN / fpsAcc;
    fpsN = 0; fpsAcc = 0; lastFpsT = now;
  }
  const info = renderer.info;
  dbg.update({
    backend, grid, fps, frameMs, calls: info.render.calls,
    mode: "ligne-claire", quality: settings.quality,
    craft,
  });
}

async function boot() {
  ui.setLoad(0.1, "tuning the radio…");
  try { await audio.loadAll((p) => ui.setLoad(0.1 + p * 0.35, "tuning the radio…")); } catch (e) { console.warn(e); }
  audio.setVolumes(settings);

  ui.setLoad(0.5, "raising the island…");
  island = createIsland(scene, settings.quality || "medium");
  if (ui.setMiniMap) {
    const S = 128, world = 5000, originX = 200, originZ = -500;
    const data = new Uint8Array(S * S);
    for (let j = 0; j < S; j++) {
      for (let i = 0; i < S; i++) {
        const x = originX + ((i + 0.5) / S - 0.5) * world;
        const z = originZ + (0.5 - (j + 0.5) / S) * world;
        const h = island.heightAt(x, z);
        data[j * S + i] = h > 0.5 ? Math.min(255, 40 + h) : 0;
      }
    }
    ui.setMiniMap({ S, world, originX, originZ, data, label: "5 km" });
  }
  {
    const meshes = [];
    const lg = island.landmarks && island.landmarks.group;
    if (lg) {
      lg.traverse((o) => {
        if (o.isMesh && (o.name === "cliffs" || (o.name && o.name.startsWith("landmarks-merged")))) meshes.push(o);
      });
    }
    flyCam.setWorld(island, meshes);
  }
  flattenLook(scene);
  ensureShadow();
  weather = createWeather(scene, island.sky, island.water);
  feel = createFeelFX(scene);
  missions = createMissionSystem(scene, island, audio);
  if (missions.setFeelFX) missions.setFeelFX(feel);
  rebuildPlane(save.plane || "trainer");
  resetCraft(craft, SPAWN.airport, SPAWN.airport.heading, craft.id);

  window.addEventListener("resize", () => { allocTargets(); });
  window.addEventListener("orientationchange", () => setTimeout(allocTargets, 200));

  // first click unlocks audio
  const unlock = () => { audio.unlock(); window.removeEventListener("pointerdown", unlock); };
  window.addEventListener("pointerdown", unlock);

  document.addEventListener("visibilitychange", () => {
    if (document.hidden && mode === "fly") { paused = true; ui.showPause(save); }
  });

  await warmup();
  allocTargets();
  backToTitle();

  const loop = (t) => { step(t); requestAnimationFrame(loop); };
  requestAnimationFrame(loop);

  exposeAPI();
}



function hudShot() {
  ui.showHUD();
  ui.updateHUD(craft, missions.state, clock.hour, ui.isPortrait(), {
    weather: weather && weather.state,
    save: Object.assign({}, save, { starsTotal: totalStars(save) }),
    combat: combat.active ? combat.getState() : null, combatMarks: combat.active && combat.projectMarks ? combat.projectMarks(camera, window.innerWidth, window.innerHeight) : null,
  });
}

function heroShot(opts = {}) {
  const x = opts.x ?? HERO_VIEW.plane.x;
  const y = opts.y ?? HERO_VIEW.plane.y;
  const z = opts.z ?? HERO_VIEW.plane.z;
  const tx = opts.tx ?? HERO_VIEW.look.x;
  const ty = opts.ty ?? HERO_VIEW.look.y;
  const tz = opts.tz ?? HERO_VIEW.look.z;
  startFreeFlight();
  if (weather) weather.set(opts.weather || "clear");
  if (typeof island.setStorm === "function") island.setStorm((opts.weather || "clear") === "storm", weather && weather.state.windKt);
  clock.set(opts.hour ?? 11);
  island.sky.setHour(opts.hour ?? 11);
  if (typeof island.update === "function") island.update(0, performance.now() / 1000, clock.hour, camera);
  camOverride = null;
  const hdg = headingFromXZ(tx - x, tz - z);
  resetCraft(craft, { x, y, z, heading: hdg }, hdg, "trainer");
  launchCraft(craft, opts.speed ?? 46, 0);
  craft.gearDown = false;
  craft.onGround = false;
  craft.throttle = 0.78;
  input.resetThrottleLever?.(0.78);
  rebuildPlane("trainer");
  const vis = planeMesh && planeMesh.getObjectByName("plane-visual");
  if (vis) vis.scale.setScalar(1.32 * (HERO_VIEW.planeScale || 1));
  flyCam.state.mode = "chase";
  flyCam.state.hero = true;
  craft.angVel.set(0, 0, 0);
  craft.roll = 0.35;
  craft.pitch = -0.04;
  flyCam.snap(craft, false);
  if (island.flora && island.flora.refresh) island.flora.refresh(camera);
  paused = true;
  if (opts.showcase !== false) showcaseRings("pro", 3, 12, 27.346, null);
  if (contrail) contrail.clear();
  if (missions.spawnDemoRing) {
    // One large mid-frame hoop ahead of the Courrier, facing the camera.
    missions.spawnDemoRing(16, 27, -1358, 24, true);
    missions.spawnDemoRing(-55, 42, -1140, 9, false);
    missions.spawnDemoRing(-120, 54, -1000, 7, false);
  }
  // Park the liner in the postcard bay, under the Courrier's left wing.
  if (island && island.landmarks) {
    const boats = island.landmarks.boats || [];
    for (const b of boats) {
      if (b && b.name === "steamer") {
        b.position.set(-36, 0.45, -1330);
        b.rotation.y = 1.05;
      }
    }
  }
  syncPlaneMesh();
  if (missions.applyRingNight) missions.applyRingNight(island.sky && island.sky.night || 0);
  hudShot();
  return { x, y, z, heading: hdg };
}



function showcaseRings(klass, passed, total, tsec, weatherId) {
  const rings = [];
  for (let i = 0; i < total; i++) rings.push({ x: 0, y: 80, z: 0, r: 16 });
  missions.state.active = {
    id: "showcase",
    activity: "rings",
    klass,
    title: "Ring Course",
    brief: "Fly through all rings!",
    weather: weatherId || null,
    rings,
    timeLimit: 180,
  };
  missions.state.ringsPassed = passed;
  missions.state.t = tsec;
  missions.state.result = null;
}

function landingShot(opts = {}) {
  const m = getMission("land-p1");
  startFreeFlight();
  if (m) {
    currentMissionId = "land-p1";
    missions.start(m, craft);
  }
  if (weather) weather.set("clear", { windDeg: 310, windKt: 8 });
  clock.set(opts.hour ?? 11);
  island.sky.setHour(opts.hour ?? 11);
  if (typeof island.update === "function") island.update(0, performance.now() / 1000, clock.hour, camera);
  camOverride = null;
  const x = opts.x ?? 500;
  const y = opts.y ?? 22;
  const z = opts.z ?? -1100;
  const hdg = Math.PI;
  resetCraft(craft, { x, y, z, heading: hdg }, hdg, "trainer");
  launchCraft(craft, opts.speed ?? 34, -1.0);
  craft.gearDown = true;
  craft.flaps = 1;
  craft.onGround = false;
  craft.throttle = 0.4;
  craft.angVel.set(0, 0, 0);
  craft.roll = 0;
  craft.pitch = -0.08;
  rebuildPlane("trainer");
  flyCam.state.mode = "chase";
  flyCam.state.hero = "landing";
  flyCam.snap(craft, false);
  paused = true;
  syncPlaneMesh();
  if (contrail) contrail.clear();
  if (missions.applyRingNight) missions.applyRingNight(island.sky && island.sky.night || 0);
  hudShot();
  return { x, y, z, heading: hdg };
}

function stormShot(opts = {}) {
  const pose = heroShot({ ...opts, weather: "storm", hour: opts.hour ?? 11, showcase: false });
  if (weather) weather.set("storm", { windDeg: 270, windKt: 22.7, visibility: 4.2, turbulence: 0.7 });
  if (typeof island.setStorm === "function") island.setStorm(true, 22.7);
  island.sky.setHour(opts.hour ?? 11);
  weather.state.flash = 0.62;
  weather.state.rain = 1;
  if (weather.bolt) {
    weather.bolt.visible = true;
    weather.bolt.position.set(380, 280, -200);
    weather.bolt.scale.set(2.4, 3.2, 2.4);
  }
  showcaseRings("ace", 4, 12, 46.219, "storm");
  // ring chain already spawned by heroShot
  flyCam.state.hero = true;
  flyCam.snap(craft, false);
  syncPlaneMesh();
  if (look && weather) {
    look.uniforms.uRain.value = 1;
    look.uniforms.uFlash.value = 0.62;
  }
  if (island.sky && typeof island.sky.applyFlash === "function") island.sky.applyFlash(0.62);
  weather.state.flash = 0.62;
  if (typeof island.update === "function") island.update(0, performance.now() / 1000, clock.hour, camera);
  hudShot();
  return pose;
}

function hudExtras() {
  const w = window.innerWidth || 1920, h = window.innerHeight || 1080;
  const aim = missions.state && missions.state.aim;
  let aimMark = null;
  if (aim && camera) {
    const v = new THREE.Vector3(aim.x, aim.y, aim.z).project(camera);
    aimMark = {
      x: (v.x * 0.5 + 0.5) * w,
      y: (-v.y * 0.5 + 0.5) * h,
      behind: v.z > 1,
      on: v.z <= 1,
      wind: !!aim.wind,
      label: aim.label || (aim.wind ? "WIND RING" : "NEXT"),
    };
  }
  if (weather && missions.setWind) {
    const ws = weather.state || {};
    missions.setWind(ws.windDeg || 40, ws.windKt || 6);
  }
  return {
    weather: weather && weather.state,
    save: Object.assign({}, save, { starsTotal: totalStars(save), pay: save.pay | 0, upgrades: save.upgrades }),
    combat: combat.active ? combat.getState() : null,
    combatMarks: combat.active && combat.projectMarks ? combat.projectMarks(camera, w, h) : null,
    aimMark,
  };
}

function exposeAPI() {
  window.ASCII_AIR = {
    version: VERSION,
    ready: true,
    backend,
    settings, save, craft, camera, scene, renderer, island, missions, audio, ui, clock, weather, combat,
    getPerf() {
      return {
        fps, frameMs, calls: renderer.info.render.calls, triangles: renderer.info.render.triangles,
        grid: { ...grid }, backend, displayMode: "ligne-claire",
        quality: settings.quality,
      };
    },
    startMission, startFreeFlight, backToTitle, heroShot, landingShot, stormShot, look, flyCam, feel,
    get planeMesh() { return planeMesh; },
    setWeather: (id, opts) => weather && weather.set(id, opts),
    setTime: (h) => { clock.set(h); island.sky.setHour(h); if (typeof island.update === "function") island.update(0, performance.now() / 1000, h, camera); if (missions.applyRingNight) missions.applyRingNight(island.sky.night || 0); },
    setDisplayMode: () => {},
    setCharSize: () => {},
    setQuality: (q) => { settings.quality = q; applyVisualSettings(); },
    setPlane: (id) => { rebuildPlane(id); resetCraft(craft, craft.spawn, craft.spawn?.heading, id); },
    teleport: (x, y, z) => { craft.pos.set(x, y, z); craft.prevPos.copy(craft.pos); },
    lookFrom(x, y, z, lx, ly, lz) {
      if (island && typeof island.heightAt === "function") {
        let h = island.heightAt(x, z);
        for (const [dx, dz] of [[8, 0], [-8, 0], [0, 8], [0, -8], [6, 6], [-6, 6]]) {
          const hh = island.heightAt(x + dx, z + dz);
          if (hh > h) h = hh;
        }
        if (Number.isFinite(h) && y < h + 8) y = h + 8;
        const hl = island.heightAt(lx, lz);
        if (Number.isFinite(hl) && ly < hl + 2) ly = hl + 2;
      }
      camOverride = {
        pos: new THREE.Vector3(x, y, z),
        look: new THREE.Vector3(lx, ly, lz),
      };
    },
    clearLook() { camOverride = null; },
    launch: (spd) => launchCraft(craft, spd, 2),
    setThrottle: (v) => { input.resetThrottleLever?.(v); craft.throttle = v; },
    setFire: (on) => { input.setDebugFire?.(!!on); },
    forceWave: (i) => combat.forceWave && combat.forceWave(i, craft),
    faceToward(x, z) {
      const hdg = headingFromXZ(x - craft.pos.x, z - craft.pos.z);
      resetCraft(craft, { x: craft.pos.x, y: craft.pos.y, z: craft.pos.z, heading: hdg }, hdg, craft.id);
      launchCraft(craft, Math.max(28, craft.airspeed || 40), 0);
      flyCam.hardSnap ? flyCam.hardSnap(craft, false) : flyCam.snap(craft, false);
      syncPlaneMesh();
    },
    setAutopilot: (on, target, opts) => { autoPilotOn = !!on; autoPilotTarget = target; autoPilotOpts = opts || {}; },
    setPaused: (v) => { paused = !!v; if (!paused) { ui.closeOverlay(); if (mode === "fly") ui.showHUD(); } },
    getPaused: () => paused,
    render: () => {
      try { ui.updateHUD(craft, missions.state, clock.hour, ui.isPortrait(), hudExtras()); } catch {}
      syncPlaneMesh();
      renderFrame(performance.now() / 1000, 1 / 60);
    },
    getCamInfo() {
      const r = {
        mode: flyCam.state.mode,
        hero: flyCam.state.hero,
        orbitActive: flyCam.state.orbitActive,
        orbitYaw: flyCam.state.orbitYaw,
        orbitPitch: flyCam.state.orbitPitch,
        lockView: flyCam.state.lockView,
        hasPose: flyCam.state.hasPose,
        camOverride: !!camOverride,
        cam: { x: camera.position.x, y: camera.position.y, z: camera.position.z },
        plane: { x: craft.pos.x, y: craft.pos.y, z: craft.pos.z },
      };
      const dx = camera.position.x - craft.pos.x;
      const dy = camera.position.y - craft.pos.y;
      const dz = camera.position.z - craft.pos.z;
      r.dist = Math.hypot(dx, dy, dz);
      r.behindY = dy;
      return r;
    },
    // Step live input (held keys / touch) through physics without waiting on the renderer.
    advance(seconds) {
      const steps = Math.max(1, Math.round(seconds / PHYS.dt));
      for (let i = 0; i < steps; i++) {
        const stepInp = input.update(settings, PHYS.dt);
        if (weather) weather.applyToCraft(craft, PHYS.dt);
        stepCraft(craft, stepInp, island, PHYS.dt, settings);
        handleCraftEvents();
        maybeRespawn();
        if (mode === "fly") missions.update(PHYS.dt, i * PHYS.dt, craft, camera, stepInp);
        if (mode === "fly" && combat.active) {
          const c = combat.update(PHYS.dt, craft, stepInp, camera);
          if (c.done && missions.state.active && !missions.state.result) {
            missions.complete(c.stars, { line: c.line, bestStreak: 0 });
            if (c.stars > 0) {
              awardStars(save, missions.state.active.id, c.stars, { time: missions.state.t, line: c.line });
              missions.state.result.pay = awardPay(save, c.stars, 0);
            }
          }
        }
        flyCam.update(PHYS.dt, craft, ui.isPortrait && ui.isPortrait());
      }
      syncPlaneMesh();
    },

    steerTo: (inp, craft, x, y, z, opts) => autopilot(craft, { x, y, z }, inp, opts || {}),
    completeMissionNow: (stars = 3) => {
      if (missions.state.active) {
        missions.state.result = { stars, line: "DEBUG", time: missions.state.t, mission: missions.state.active };
        awardStars(save, missions.state.active.id, stars, { time: 0 });
      }
    },
    takePhoto: () => { try { return canvas.toDataURL("image/jpeg", 0.8); } catch { return null; } },
    getUIBounds: () => ui.elements(),
    toggleFullscreen, toggleGyro,
    listMissions: () => MISSIONS.map((m) => m.id),
    listDogfights: () => DOGFIGHTS.map((m) => m.id),
    getMission,
    simulate(seconds, inputFn) {
      const inp = { pitch: 0, roll: 0, yaw: 0, throttle: 0, throttleSet: null, boost: false, brake: false, actionPressed: false, actionHeld: false, gearToggle: false };
      const steps = Math.max(1, Math.floor(seconds * PHYS.hz));
      let t = 0;
      for (let i = 0; i < steps; i++) {
        if (typeof inputFn === "function") inputFn(inp, craft, camera, t, missions.state);
        else if (autoPilotOn && autoPilotTarget) autopilot(craft, autoPilotTarget, inp, autoPilotOpts);
        inp.actionPressed = !!inp.actionPressed;
        stepCraft(craft, inp, island, PHYS.dt, settings);
        if (mode === "title" && craft.crashed) { craft.crashed = false; craft.crashTimer = 0; }
        handleCraftEvents();
        maybeRespawn();
        syncPlaneMesh();
        if (mode === "fly") missions.update(PHYS.dt, t, craft, camera, inp);
        // keep camera with the plane so photo checks work
        flyCam.state.mode = flyCam.state.mode === "title" ? "chase" : flyCam.state.mode;
        if (flyCam.state.mode === "title") flyCam.state.mode = "chase";
        flyCam.update(PHYS.dt, craft, false);
        t += PHYS.dt;
        inp.actionPressed = false;
        if (missions.state.result) break;
        if (craft.crashed && craft.crashTimer > 1.5) {
          // will respawn next maybeRespawn after timer; keep going
        }
      }
      island.update(Math.min(seconds, 0.5), t, clock.hour, camera);
      return {
        result: missions.state.result,
        t,
        craft: { x: craft.pos.x, y: craft.pos.y, z: craft.pos.z, airspeed: craft.airspeed, crashed: craft.crashed },
        mission: missions.state.active && missions.state.active.id,
        popped: missions.state.popped,
        rings: missions.state.ringsPassed,
        photoReady: missions.state.photoReady,
        photoScore: missions.state.photoScore,
      };
    },
  };
}

boot().catch((err) => {
  console.error(err);
  window.__bootErr = (err && err.stack) || String(err);
  ui.setLoad(1, "error: " + (err && err.message ? err.message : err));
});

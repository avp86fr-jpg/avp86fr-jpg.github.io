import * as THREE from "three";
import { MAT } from "../core/config.js";
import { retagGeometry, patchMaterialIdAlpha } from "../render/idMaterial.js";

function mat(color, matId = MAT.PLANE) {
  const m = new THREE.MeshLambertMaterial({
    color, flatShading: true, emissive: color, emissiveIntensity: 0.6,
  });
  m.userData.matId = matId;
  patchMaterialIdAlpha(m);
  return m;
}

/**
 * Original airmail pilot (not any licensed character):
 * round face, short dark curls, tan cap, amber goggles, ochre jacket, teal scarf.
 */
export function createPilot() {
  const g = new THREE.Group();
  g.name = "pilot";
  const skin = mat(0xf0c8a0, MAT.PLANE);
  const hair = mat(0x2a1a14, MAT.WOOD);
  const cap = mat(0x5a3218, MAT.WOOD);
  const jacket = mat(0x6a3a22, MAT.WOOD);
  const scarf = mat(0xc45a2a, MAT.ROOF);
  const goggle = mat(0x3a3a3a, MAT.METAL);
  const lens = mat(0xc8a838, MAT.METAL);

  const head = new THREE.Mesh(retagGeometry(new THREE.SphereGeometry(0.28, 8, 6), MAT.PLANE, 1), skin);
  head.position.set(0, 0.42, 0.02);
  const curls = new THREE.Mesh(retagGeometry(new THREE.SphereGeometry(0.3, 8, 6), MAT.WOOD, 1), hair);
  curls.position.set(0, 0.50, -0.02);
  curls.scale.set(1.05, 0.7, 1.05);
  const hat = new THREE.Mesh(retagGeometry(new THREE.SphereGeometry(0.26, 8, 6), MAT.WOOD, 1), cap);
  hat.position.set(0, 0.58, 0);
  hat.scale.set(1.05, 0.42, 1.05);
  const brim = new THREE.Mesh(retagGeometry(new THREE.CylinderGeometry(0.32, 0.32, 0.04, 8), MAT.WOOD, 1), cap);
  brim.position.set(0, 0.50, 0.08);
  brim.rotation.x = -0.3;
  const glassL = new THREE.Mesh(retagGeometry(new THREE.SphereGeometry(0.11, 8, 6), MAT.METAL, 1), lens);
  glassL.position.set(-0.12, 0.44, 0.24);
  glassL.scale.set(1.1, 0.9, 0.45);
  const rimL = new THREE.Mesh(retagGeometry(new THREE.TorusGeometry(0.1, 0.025, 5, 10), MAT.METAL, 1), goggle);
  rimL.position.copy(glassL.position);
  const glassR = glassL.clone();
  glassR.position.x = 0.12;
  const rimR = rimL.clone();
  rimR.position.x = 0.12;
  const strap = new THREE.Mesh(retagGeometry(new THREE.TorusGeometry(0.27, 0.025, 5, 12), MAT.METAL, 1), goggle);
  strap.position.set(0, 0.44, 0.02);
  strap.rotation.x = 0.15;
  strap.scale.set(1, 0.85, 1);
  const body = new THREE.Mesh(retagGeometry(new THREE.SphereGeometry(0.26, 8, 6), MAT.WOOD, 1), jacket);
  body.position.set(0, 0.0, -0.06);
  body.scale.set(0.75, 0.95, 0.6);
  const wrap = new THREE.Mesh(retagGeometry(new THREE.TorusGeometry(0.22, 0.05, 6, 10), MAT.METAL, 1), scarf);
  wrap.position.set(0, 0.22, 0.02);
  wrap.rotation.x = 1.2;
  const tail = new THREE.Mesh(retagGeometry(new THREE.BoxGeometry(0.12, 0.08, 0.7), MAT.ROOF, 1), scarf);
  tail.position.set(0.16, 0.16, -0.42);
  tail.rotation.set(0.2, 0.35, 0.15);
  g.add(head, curls, hat, brim, glassL, glassR, rimL, rimR, strap, body, wrap, tail);
  g.scale.setScalar(1);
  return g;
}

/** Attach a seated pilot into a plane group's cockpit. */
export function seatPilot(plane) {
  const p = createPilot();
  p.position.set(0, 0.55, 0.7);
  p.scale.setScalar(0.62);
  plane.add(p);
  return p;
}

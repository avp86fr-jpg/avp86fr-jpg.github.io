# AEROPOSTALE AIR — Keep cliffs, harbour quay, house detail, field breakup

Date: 27 Nov 2026, 11:32 Europe/Paris (UTC+1).

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **d019489** (27 Nov 2026, 11:32 Europe/Paris). noindex,nofollow kept.

## Review of 9247327

Clouds and limestone ruins were kept as they were. Remaining work: the Keep rock still read as a soft olive-grey mass; the harbour shot was empty grass; village houses were box-like up close; large fields were flat green.

## What changed

- **Keep rock:** faceted limestone planes with clear warm-light / cool-shade tints, flat-shaded painted atlas (no olive wash). Dense, brighter leafy masses on the crown and rims; larger sunlit canopies instead of tiny dark dots. Ruins and clouds untouched.
- **Harbour:** a stone quay on the south bank of the canal — block sea-wall, paved walk, wooden finger piers, moored fishing boats, lamp posts, crates, barrels, bollards, net racks, and a row of colourful facades (windows, shutters, stone bases) facing the water. People and carts spawn on the quay. The official harbour camera is over the water, not on the grassy south hill.
- **Village houses:** limestone plinths, window frames, coloured shutters, flower boxes, balconies on taller houses, dormers on steep roofs, and a wider roof-pitch range.
- **Fields:** longer-range grass mottling and plot/hedge hints in the terrain shader, dirt-track and flower tints on the heightfield, segmented mid-island hedges that follow the slope, extra stone walls, and narrow farm tracks. Meadow flowers reach a little farther.

## Perf

| Quality | Hero tris | Hero draws | Title draws | Free draws | Caps |
|---|---:|---:|---:|---:|---|
| low | 1,175,896 | 142 | 130 | 109 | ≤1.5M / 150 |
| medium | 2,247,860 | 146 | 134 | 113 | ≤2.5M / 150 |
| high | 2,249,102 | 145 | 134 | 113 | ≤2.5M / 150 |

## QA

M1–M5 on PC 1920×1080 and mobile 844×390: 0 failed, 0 errors. English HUD held; chase camera stayed behind the plane.

## Sheets

- Compare: `delivery/shots/compare/game_vs_cover.png`
- Beauty: `delivery/shots/beauty/sheet_2x3.png`
- Keep close-up: `delivery/shots/beauty/sheet_keep_close.png`
- World/life: `delivery/shots/beauty/sheet_world_life.png`
- UI / presentation: `delivery/shots/ui/presentation_sheet.png`

## Honest gaps

- Keep trunks are still simple dark cylinders; the painted rock atlas is crisper than before but not a fully hand-painted cliff.
- Harbour houses sit on the bank above the quay rather than tight against the water; nets and people are small; the walk is relatively narrow.
- Far-town house impostors (pale puffs) are still simpler than the near street houses.
- Mid-island hedges and walls read clearly up close but are easy to miss in wide scenic views; some slopes stay fairly open.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_keep_quay_houses.zip`

---

# AEROPOSTALE AIR — M1–M5 QA playthrough + HUD star total + night fill

Date: 26 Nov 2026, 23:23 Europe/Paris (UTC+1).

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **0bd0a4c** (26 Nov 2026, 23:23 Europe/Paris). noindex,nofollow kept.

## QA

Played one mission from each milestone on PC (1920×1080) and mobile (844×390): rings-b1, mail-b1, storm-b1, night-b1, res-b1. All ten runs started, the chase camera stayed 12–55 m behind the plane, English HUD text held, and each mission completed with 3 stars. Screenshots are in `delivery/shots/qa/`.

Fixes from that pass:
- Desktop star total was still hardcoded as `/ 180` and could print `[object Object]` if `save.stars` (the map) was used. It now shows a numeric `★ n / 192` (`MISSION_COUNT × 3`).
- Night Mail land was almost a black silhouette. Night ambient fill is a little higher so the runway, hangar and plane stay readable.
- Compact rescue touch line says "Mark:" / "Raft:" / "Pylon:" as appropriate.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_qa_m1m5.zip`

---

# AEROPOSTALE AIR — Hero framing, rock arch, rolling hills, bolder HUD

Date: 26 Nov 2026, 23:20 Europe/Paris (UTC+1).

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **c6eeddf** (26 Nov 2026, 23:20 Europe/Paris). noindex,nofollow kept.

## What changed

- Hero camera pulled back and slightly up (dist 40, height 14, look y=26) so the COURRIER C-14 sits in the lower-middle at a nearer-to-35% width. One-piece flat wing panels, scale 0.98, visible struts.
- Sea arch rebuilt as a south-facing rock window (two buttresses, a half-torus cap, irregular cap rocks) instead of a floating brown donut. You can see through the opening from the hero camera.
- Airport flatten tightened to the runway ribbon. Added south-face rolling swells and denser tree clumps so the mid-island is no longer a flat yellow platform.
- Coastal cliff hatching is stronger (ink-like stripes).
- Desktop HUD: 7 px ink borders, larger Itim (banner 32, stats/mission 24, gauges 32), wider cream plates. Touch-ui compact rules unchanged.
- Hero/title cameras no longer raycast the terrain mesh (that had snapped the hero view onto a hillside). Building collision still runs in chase.

## Tests

- `aa-hero-quick.mjs` recaptured title, hero_day, 06_mobile_landscape, hero_storm. Draws: title 60, hero 88.
- `aa-takeoff.mjs` and `aa-menu.mjs` ALL PASS (8 activities, layouts clean).
- Compare: `delivery/shots/compare_day_vs_ligneclaire.png`.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_hero_art.zip`

---

# AEROPOSTALE AIR — Chase camera follow + building collision

Date: 26 Nov 2026, 23:14 Europe/Paris (UTC+1).

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **080c129** (26 Nov 2026, 23:14 Europe/Paris). noindex,nofollow kept.

## Cause

The 07_mobile_arcade_844x390 shot showed a tiny plane far ahead, a hangar wall in the right edge, and a dark slab on the runway. Two things stacked:

1. `startFreeFlight` / `startMission` never snapped the chase camera or reset orbit / `camOverride`. The camera could be left at a leftover title or landing pose. The HUD is a DOM overlay, so speed/alt could update while the WebGL canvas still showed a leftover viewpoint — or, after a long `advance()` burst plus a single 1/60 lerp, the camera only caught a fraction of a hundreds-of-metres error.
2. The chase offset sat north of the plane, toward the hangar and tower. A look-to-camera ray never hit those buildings when they sat *beside* the camera, so the view could sit against (or inside) a wall.

## Fix

- Snap and orbit-reset when free flight or a mission starts; clear `camOverride`.
- If the camera is more than 28 m from its rig (or has no pose yet), snap immediately; if it is 12–28 m off, tighten the lag.
- Camera uses real frame dt, not a fixed 1/60.
- Collision: terrain clearance, raycast against the merged landmarks / cliffs / terrain, and AABB padding around the hangar, tower and church.
- Chase offset is now slightly south (water side), height 9.5 m, so the airport buildings stay in frame instead of swallowing the right edge.

## Verify

`tests/aa-cam-follow.mjs` — real touch takeoff at 844×390, 12 sequential rAF frames. Distance stayed 26–37 m behind and above the tail; the plane took off; the camera never sat in the hangar. Contact sheet: `delivery/shots/cam_follow_strip.png`. New arcade shot: `delivery/shots/07_mobile_arcade_844x390.png`.

Flight feel, English text, and the draw cap are unchanged.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_cam_follow.zip`

---

# AEROPOSTALE AIR — M3 Storm Crossing, M4 Night Mail, M5 Rescue & Cape Race

Date: 26 Nov 2026, 23:03 Europe/Paris (UTC+1).

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **40e599a** (26 Nov 2026, 23:03 Europe/Paris). noindex,nofollow kept.

## M3 Storm Crossing

Six English missions in a gale (`weather: "storm"`). Cyan beacon rings lead along the south coast, the cape beam, and across the island. Pro runs Cape to Ridge and Ace in the Storm finish with a landing on the ridge grass strip after the last beacon. HUD: "STORM CROSSING", current beacon name, counts, time, wind. Touch: "Beacon: …" / "Land: Ridge".

- Beginner: Beacon Path, Cape Beam, Ridge Bound.
- Pro: Gale Circuit, Cape to Ridge, Ace in the Storm.

## M4 Night Mail

Six English night missions (`hour` 21–22.4). Night Pickup and Beam Run are hangar-to-post drops after dark. Flare 09 and Night Arrival light a flare path of amber and red poles along runway 09 / 27. Night Line is a longer town-and-mills drop. Night Photo frames Cinder Cape Light (also fixes a pre-existing crash when colouring the photo viewpoint ring, which is a Group, not a Mesh).

- Beginner: Night Pickup, Beam Run, Flare 09.
- Pro: Night Line, Night Photo, Night Arrival.

## M5 Rescue & Cape Race

Eight English missions. Rescue runs use a mark ring then a gold raft-drop at the shallow wreck, the steamer, a three-ring steamer circuit, and the sea arch. Pro races are orange pylons: Cape Race, Volcano Lap (glider), Viaduct Cut, and Grand Cape (lighthouse → arch → volcano → viaduct → hangar).

- Beginner: The Wreck, Steamer Aid, Circle the Steamer, Arch Watch.
- Pro: Cape Race, Volcano Lap, Viaduct Cut, Grand Cape.

## Map and totals

The Missions map now has 8 activities: Rings, Landings, Balloons, Photos, Mail, Storm, Night Mail, Rescue. 64 missions, 192 stars (`MISSION_COUNT × 3`). Layouts at 800×360, 844×390 and 915×412 still pass with no overflow.

## Tests

- `aa-menu.mjs`: ALL PASS, 8 activity cards (Mail ★ 0/24, Storm ★ 0/18, Night Mail ★ 0/18, Rescue ★ 0/24).
- `aa-mail.mjs`: hangar pickup then Harbor Town drop, 3 stars (M2).
- `aa-m3m5.mjs`: storm-b1 3 stars in storm weather; night-b1 3 stars at 21h; res-b1 3 stars; night-b3 flare path (23 objects) at 21h; night-p2 photo setup at 22h; storm-p2 waits to land after the last beacon.
- `aa-takeoff.mjs`: keyboard, landscape touch and portrait touch still ALL PASS.

Draws stay under 150 (title ~68, hero/storm ~87, flare landing ~71, race ~85, night free flight ~58). Flight feel and English text unchanged.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_m3_m5.zip`

---

# AEROPOSTALE AIR — M2 The Mail Line

Date: 26 Nov 2026, 23:00 Europe/Paris (UTC+1)

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **1bedfdf** (26 Nov 2026, 23:00 Europe/Paris). noindex,nofollow kept.

## What shipped

A new **Mail** activity on the Missions map (English). Pick up a gold ring at the hangar, then drop at the island posts (cream rings with red poles). Eight missions:

- Beginner: First Bag (town), Mill Post, Cape Letter, Castle Post.
- Pro: Town and Mills, Two Coasts, Castle Express, The Mail Line (hangar → town → mills → lighthouse → castle).

Stars are graded on time. The HUD shows the current pickup or drop in English; the compact touch line is "Pick up: Hangar" / "Drop: Harbor Town". The star total in the desktop HUD now tracks `MISSION_COUNT × 3` (44 missions, 132 stars) instead of a hardcoded 180.

Flight feel, English text, and the colour/landmark graphics pass are unchanged. Draws stay at title 60 / day 88.

## Tests

- `aa-menu.mjs`: ALL PASS, 5 activities including "Mail ★ 0 / 24".
- `aa-mail.mjs`: pickup at the hangar and drop at Harbor Town awards 3 stars.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_m2_mail.zip`

---

# AEROPOSTALE AIR — colour, landmarks and HUD pass

Date: 26 Nov 2026, 23:00 Europe/Paris (UTC+1)

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **e84e4e4** (26 Nov 2026, 22:53 Europe/Paris). noindex,nofollow kept. Folder preview/ascii-air/ only.

Master art target: `refs/user_target_master_v2.png`.

## What shipped

Three render-compare-fix loops against the five-point review of the previous compare sheet. Flight feel and English text unchanged.

(a) **Plane size and wings.** Hero camera pulled back (dist 34 m, FOV 50°) so the COURRIER C-14 sits in the lower-middle at about 35% of frame width. Wings are flat, thin and straight (no dihedral curl, no bulbous tips), with dark interplane struts. Camera remains behind the tail; nose points into the island.

(b) **Island layers.** The south face is no longer a yellow rock dome. Mid-island is saturated green rolling hills with tree clusters; coastal rock is grey-ochre and limited to steep shore faces; the volcano peak is a sharp red-orange cone with lava streaks. The village is a dense cluster of small white houses with red roofs.

(c) **Crisp landmarks.** White-and-red banded lighthouse with a lantern gallery and a daylight beam. Stone castle with corner towers, crenellations and a gate. East-west stone viaduct with five arched openings facing the south camera. Ochre sea arch on the right cape.

(d) **Water.** Deep blue offshore, richer turquoise in a tight coastal band, a crisp white foam line at the shoreline. Mid-bay wash reduced.

(e) **HUD.** Desktop cream panels with 6 px ink borders, larger Itim type and a bigger flight bar, in English. Mobile/touch HUD stays compact (existing touch-ui scale rules) so the centre of the screen stays clear.

## Draw calls (must stay under 150)

| View | Calls |
| --- | --- |
| Title | 60 |
| Day hero | 88 |
| Mobile 844×390 | 88 |
| Storm hero | 88 |

## Tests

- `aa-menu.mjs`: ALL PASS, 0 errors (English, 800×360, 844×390, 915×412, desktop).
- `aa-takeoff.mjs`: ALL PASS.
- `aa-arcade.mjs`: ALL PASS (takeoff, alignment, camera behind, 360, ring, keyboard and touch landing, layouts).

## Honest critique vs the master

**Much closer:** the two images now share the same postcard language — a modest rear-quarter biplane over deep blue water, green hills and a red-orange peak, a banded lighthouse, a crenellated castle, an arched viaduct, a white-and-red village, and cream HUD plates with bold ink.

**Still short:** the master's cliffs are more tightly hatched; the sea arch is a readable ochre ring rather than a carved rock window; foam could be richer; mid-island lime could be even punchier; the steamer is still easier to spot with the left harbour traffic than as a right-cape portrait. Not a reason to withhold this pass.

Shots: `delivery/shots/hero_day.png`, `title_cover.png`, `hero_storm.png`, `compare_day_vs_ligneclaire.png`, `compare_title_vs_master.png`.

## M2–M5 (next)

Graphics increment ships first, then M2 The Mail Line, M3 Storm Crossing, M4 Night Mail, M5 Rescue & Cape Race, each deployed when done.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_colour_landmarks.zip`

---

# AEROPOSTALE AIR — vista graphics pass (6-point review)

Date: 26 Nov 2026, 22:37 Europe/Paris (UTC+1)

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **8ce156f** (26 Nov 2026, 22:37 Europe/Paris). noindex,nofollow kept. Folder preview/ascii-air/ only.

Master art target: `refs/user_target_master_v2.png`.

## What shipped

A full iterate-compare-fix pass against the parent's 6-point review of `compare_day_vs_ligneclaire.png`. Flight feel, English UI and the COURRIER C-14 mesh convention are unchanged.

1. **Plane faces into the scene.** The hero and title cameras sit behind the tail (live check: camera south of the plane, prop further than the pilot). The hero look is nearly level and aimed at the island, not down at the near water, so the frame shows the cream tail, the pilot from behind, the envelope insignia on the upper wing, and the nose pointing away at the volcano. The cream tail was enlarged and the prop blur disc was made smaller and softer so a dark disc no longer reads as a nose-on propeller.
2. **Water.** Bright cerulean deep water, turquoise shallows, a white foam line at the shoreline, sparkle highlights. The old navy stroke lines are gone. A south-coast bay keeps open water in the foreground without cutting the runway.
3. **Framing.** The plane flies over the bay just south of the coast; the island fills about 60% of the frame (coast through volcano), with water in the lower third and a bright blue sky above.
4. **Cliffs.** A merged, hatched ochre cliff-wall mesh follows the south shore. The huge airport pad that used to paint a tan strip across the mid-ground is now a thin runway plus an east apron, so the cape and coast can stay as cliff.
5. **Colour.** Saturated grass and forest greens, warm ochre rock, punchier red roofs, a bright blue zenith and a pale cyan horizon, white inked clouds.
6. **Landmarks.** Village, hangar, tower, mills, waterfall, viaduct, castle, lighthouse and an ochre sea arch are scaled up and pulled into the hero FOV. The daylight lighthouse beam stays visible (opacity ~0.48). Static landmarks now merge into a single vertex-coloured mesh so the richer vista stays under the draw cap.

## Draw calls (must stay under 150)

| View | Calls |
| --- | --- |
| Title | 60 |
| Day hero | 88 |
| Mobile 844×390 | 88 |
| Landing | 60 |
| Storm hero | 88 |

## Tests

- `aa-menu.mjs`: ALL PASS, 0 errors (English, layouts at 800×360, 844×390, 915×412, desktop).
- `aa-takeoff.mjs`: ALL PASS (keyboard and touch lever + BOOST).
- `aa-arcade.mjs`: ALL PASS (takeoff, nose alignment, camera behind the tail, visual flip, 360, ring, keyboard and touch landing flare, three compact layouts). The first keyboard landing fail was a bay cut through the runway; the bay now stops south of z = -1160.

## Honest critique vs `user_target_master_v2.png`

**Much closer:** the two images now read as the same postcard at a glance — rear-quarter biplane over bright blue water, island filling the mid-frame, village/hangar/mills left, volcano/fall/rings centre, lighthouse/cape/arch right, blue sky and white clouds. The plane no longer looks like it faces the camera.

**Still short of the plate:** the master's cliffs are tighter, more densely hatched and more continuous; a few waterline spikes remain. The sea arch is a readable ochre ring, not the painted rock arch with a clear sea window. The viaduct is visible but small. Foam and sparkle are present but thinner than the plate. Mid-island hills are still a little more yellow-ochre than the ref's lime terraces. The steamer reads more with the left harbor traffic than as a right-cape portrait. The volcano is a good smoking cone, not a fully cratered peak. These can be nudged in a later tick; this pass was about the six review points and is solid enough to ship.

Shots: `delivery/shots/hero_day.png`, `title_cover.png`, `hero_storm.png`, `hero_landing.png`, `compare_day_vs_ligneclaire.png`, `compare_title_vs_master.png`.

## M2–M5 (designed; next)

- **M2 — The Mail Line.** Mail activity, hangar pickup, timed drops at town / mills / lighthouse / castle. Eight missions.
- **M3 — Storm Crossing.** Gale, beacons, cape beam, ridge-strip finish. Six missions.
- **M4 — Night Mail.** Lamps, beam, runway 09 flare path, night photo and landing. Six missions.
- **M5 — Rescue & Cape Race.** Wreck/steamer rescue and a pylon race around cape, arch, volcano, viaduct. Eight missions.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_vista_graphics.zip`

---

# AEROPOSTALE AIR — M1 flight, English, plane, orbit & graphics pass

Date: 26 Nov 2026, 22:15 Europe/Paris (UTC+1)

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **fd23a73** (26 Nov 2026, 22:15 Europe/Paris). noindex,nofollow kept. Folder preview/ascii-air/ only.

Master art target: `refs/user_target_master_v2.png` (identical to `user_target_ligneclaire.png`).

## What shipped

- **Flight feel:** persistent throttle lever (0–1). Speed comes from throttle plus gravity (dives gain speed, climbs lose it). Strong climb at full power. Gentle mush near min speed, no stall. Coordinated bank-to-turn with slight inertia and light auto-level. Assisted takeoff (unstick only if throttle > 0.95 and speed ≥ ~16) and landing flare kept.
- **Controls:** Arrows pitch/roll (ArrowUp = nose up). A/D also roll. W/S and Shift/Ctrl move the throttle. Space = BOOST (slams the lever to 1, also takeoff). Mobile: vertical throttle on the right, small BOOST above it, stick on the left. Centre 60% of the HUD stays clear.
- **Orbit camera:** drag an empty area on touch (eases back after 1.5 s, double-tap resets). PC: right or middle mouse drag. V looks back. Pause **Camera** cycles chase, side, front. Flight keys are not used for the camera.
- **Plane:** COURRIER C-14 rebuilt — fat nose, thin tail, correct stagger (upper wing ahead), ailerons on the trailing edge, cockpit behind the engine, prop at the front. Visual still flipped with `rotation.y = π` so builder +Z maps to flight −Z. Close-ups confirm a readable biplane from 3/4 rear (envelope insignia, goggled pilot, cream tail).
- **English UI:** all in-game text is English (PLAY, Continue, Free Flight, Credits, Back, Resume, SPEED, ALT, FLAPS, GEAR, MAP, RING COURSE, PHOTO MISSION, Treasures, Lvl.2, tutorial, rotate prompt, options, pause). Title **AEROPOSTALE AIR** is unchanged. Album-cover menus kept.
- **Graphics vs master v2:** hero camera looks north from the south bay. Composition now matches the plate’s left-to-right: mills, village, hangar, tower and windsock on the left; volcano, smoke, lava, rings and a visible fall in the centre; lighthouse, castle and boats on the right. Pale y=0 sea shelf under the plane was diagnosed and sunk, so the water is a continuous teal instead of a cyan patch. Warmer sky. Title flyby sits over the water with the English album menu.
- **Content:** 36 missions (three new ace briefs: Castle & Falls, Cape Light Pad, The Postcard). Routes retargeted to the moved landmarks.

## Controls scheme (also in the in-game tutorial)

| Input | Action |
| --- | --- |
| Arrow keys / stick | Pitch and roll (up = climb) |
| A / D | Roll |
| W / Shift | Throttle up |
| S / Ctrl | Throttle down |
| Space or BOOST | Full power / takeoff |
| V | Look back |
| Right / middle mouse, or drag empty touch area | Orbit the plane |
| Double-tap empty area | Reset orbit |
| Pause → Camera | Chase / side / front |
| Esc | Pause |

## Tests

- `aa-menu.mjs`: ALL PASS, 0 errors (English labels, layouts at 800×360, 844×390, 915×412, desktop).
- `aa-takeoff.mjs`: ALL PASS (keyboard Shift+Space, landscape and portrait lever + BOOST).
- `aa-arcade.mjs`: ALL PASS (takeoff, nose alignment, camera behind, visual flip, 360, ring, keyboard and touch landing flare, three compact layouts, English rotate prompt).

## Draw calls (must stay under 150)

| View | Calls |
| --- | --- |
| Title | 120 |
| Day hero | 139 |
| Mobile 844×390 | 149 |
| Landing | 119 |
| Storm | 140 |

Software-renderer fps is not a phone number.

## Honest critique vs `user_target_master_v2.png`

**Closer:** the postcard layout finally reads (village/hangar/mills left, volcano centre, lighthouse and castle right). The COURRIER C-14 is a proper 3/4-rear biplane with insignia and a visible pilot, nose pointing away. HUD layout matches the plate, in English. The giant pale water patch is gone. The title is a working English album cover. Takeoff, turns and landings feel like a lever-and-gravity arcade model.

**Still short of the plate:** the south coast is still more of a smooth ochre/sand slope than the ref’s tightly hatched sea-cliffs; a few low-poly spikes remain at the waterline; the waterfall reads, but the viaduct and sea arch are easy to miss; the lighthouse beam is shy in daylight; the water is a even deep teal rather than the ref’s layered luminous shallows and foam; the volcano is a good cone with a plume and some lava, not yet a fully cratered peak; mid-island trees are still fairly blobby. These are the next graphics ticks, not a reason to withhold this pass.

Shots: `delivery/shots/hero_day.png`, `title_cover.png`, `plane_closeup_sheet.png`, `orbit_frames.png`, `compare_day_before_after.png`, `compare_day_vs_ligneclaire.png`.

## M2–M5 (designed; not in this deploy)

Built only after this M1 pass is on the hidden preview. Each will be a new mission set in the same ligne claire style, in English, deployed one at a time.

- **M2 — The Mail Line.** New *Mail* activity. Pick up a bag at the hangar, fly a timed drop route (town, mills, lighthouse, castle), land or drop at the next post. Eight missions (beginner + pro).
- **M3 — Storm Crossing.** Cross the island in a full gale, follow beacons and the cape beam, finish on the ridge strip. Wind drift and low visibility. Six missions, including an ace in the storm.
- **M4 — Night Mail.** Night flying with town lamps, the lighthouse beam and a flare path on runway 09. Follow the lights, shoot a lit landmark, land after dark. Six missions.
- **M5 — Rescue & Cape Race.** Sea rescue (spot the wreck or steamer, circle, drop a raft) and a pylon race around the cape, arch, volcano and viaduct. Eight missions.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_m1_flight_english_graphics.zip`

---

# AEROPOSTALE AIR — graphics + album menu pass

Date: 26 Nov 2026, 21:36 Europe/Paris (UTC+1)

Live hidden preview: https://avp86fr-jpg.github.io/preview/ascii-air/

Pages commit: **fd23a73** (26 Nov 2026, 22:15 Europe/Paris). noindex,nofollow kept. Folder preview/ascii-air/ only.
(noindex, nofollow; path unchanged)

Pages commit: **45b96d7** (26 Nov 2026, 21:36 Europe/Paris). Prior arcade deploy was b5abfab.

This pass continues from the arcade / orientation / compact mobile HUD work (commit b5abfab). Flight model and mobile HUD were left alone.

## Menu / front-end UX (t970u)

Rebuilt the title and pause flow as an album-cover front-end over a live south-side flyby of the island.

- Title buttons: **JOUER** (becomes **Continuer** after progress), **Missions**, **Vol libre**, **Options**, **Crédits**.
- Missions open a **carte des missions** with star totals, then class and briefing.
- Options cover commandes (including sensibilité), graphismes (qualité) and son. Hangar and Album sit under Options so the five main buttons stay clear.
- Options opened from Pause return to Pause, not the title.
- Crédits name the original game, the imaginary Courrier C-14, and the OFL fonts. No licensed characters.
- Real `<button>`s, touch / mouse / keyboard (↑↓ / Enter) and gamepad-style stick nav. Enter no longer double-fires the next sheet (that was why the old menu felt broken).
- Layout holds at 800×360, 844×390, 915×412 and desktop: no overflow, no overlapping buttons, no dead controls.

`tests/aa-menu.mjs`: every path above, pointer and touch, those four sizes, **ALL PASS, 0 errors**.

Shots:
- `compare_menu_pc_before_after.png`
- `compare_menu_mobile_before_after.png` (frozen before was 16:9 title; after is 844×390)
- `after_title_pc.png`, `after_title_mobile_844x390.png`, `title_cover.png`, `after_pause_pc.png`

## Graphics (t967u)

- Ink outlines no longer fill the whole south slope with black (the previous metre threshold treated a receding hillside as a silhouette). Silhouettes still ink at distance; grazing terrain does not. The postcard sun now lights the south face.
- South coast: the wide beige beach was cut back to a small cove and ochre coast. Hero camera sits over the water looking in at the island (spawn / runway 09 heading 0 unchanged).
- Teal water with thin highlight strokes; crater lake hidden so the bowl can read as lava.
- Clustered foliage blobs instead of the palm grid. Village of red-roof houses, bigger smoke plume, steamer and sailboats in the south water, shrunk runway “27” digits (the east-end smear).
- Plane visual scaled 1.2 with the existing 3/4 biplane (physics size unchanged).
- Title flyby looks at the same island vista.

Draw calls (software-renderer fps is not a phone number; SwiftShader cap here is ~20–30):

| view | calls | triangles | grid |
| title 1920×1080 | 110 | 306k | 1920×1080 |
| day hero | 142 | 314k | 1920×1080 |
| mobile 844×390 | 145 | 314k | 1266×585 |
| landing | 106 | 312k | 1920×1080 |
| storm | 143 | 314k | 1920×1080 |

All under 150.

Shots:
- `compare_day_before_after.png`, `compare_mobile_before_after.png`, `compare_storm_before_after.png`
- `compare_day_vs_ligneclaire.png`, `compare_mobile_vs_ligneclaire.png`, `compare_storm_vs_ligneclaire.png`
- `hero_day.png`, `06_mobile_landscape.png`, `hero_storm.png`, `hero_landing.png`

## Tests (must-stay-green)

- `tests/aa-takeoff.mjs` — ALL PASS, 0 errors (keyboard + landscape/portrait touch).
- `tests/aa-arcade.mjs` — ALL PASS, 0 errors (takeoff, 360, ring, auto-flare landing, layouts 800×360 / 844×390 / 915×412, portrait prompt).
- `tests/aa-menu.mjs` — ALL PASS, 0 errors.
- `tests/aa-heroes.mjs` — recaptured, 0 page errors.

## Honest critique vs the master refs

Better than the last shipped stills: the plane sits over teal water in 3/4, the beach no longer dominates, the island is green and ochre instead of a black/beige slab, the village, hangar, runway, hoop, plume and sailboats read, the title is a real album cover with working buttons, and the compact mobile HUD is unchanged.

Still short of the refs:
- The south coast is sand-and-slope more than hatched ochre sea-cliffs with cut-outs.
- The volcano is a readable cone with a plume, not a cratered lava peak; lava streaks are easy to miss from the hero angle.
- Lighthouse beam, sea arch, viaduct, waterfall and castle are in the world but still small or easy to miss in this frame.
- Water has a large pale shallow patch under the plane.
- Mid-island trees are dense green blobs, not illustrated groves.
- Title flyby still shows a lot of the airfield in the foreground rather than a pure seaward postcard.

## Backup

`/cursor/stores/store-ea4c3d13-5fbd-40d7-b8ff-04901cf3f07f/ascii_air_backup/aeropostale_air_graphics_menu.zip`

---

# AEROPOSTALE AIR — arcade flight + mobile HUD + framing pass

Date: 26 Nov 2026, Europe/Paris (UTC+1)

## What changed (verified)

1. **Plane orientation.** The Courrier C-14 mesh was built with the nose at +Z while flight/camera forward is −Z, so the model flew tail-first and the chase cam sat in front of the nose. The visual is now rotated 180° on Y. Tests: nose·velocity = 1, camera behind and above the tail, visual yaw = π.

2. **Arcade / Pilotwings-style flight.** Constant cruise, Shift/Space or BOOST to go faster, Ctrl/Z/X or BRAKE to slow. Stick X / AD yaw-turns with auto bank (clamped). Stick Y / WS pitches, clamped to ±35°, auto-level on release. No stalls or tumbling. Soft bounce off terrain/water instead of light-touch crashes. Hold GO/BOOST to take off by itself. Near a runway, releasing boost auto-glides and flares. Chase cam uses world-up (horizon stays level, slight tilt only).

3. **Mobile HUD rebuild.** Landscape: left stick, right BOOST (big) + BRAKE, top-left stars/treasures pill, slim compass, compact mission line + pause, tiny VIT/ALT strip at the bottom edge. TRAIN / PLEIN ÉCRAN / CAM / red throttle slider removed from gameplay (pause menu has train, camera, fullscreen). First tap requests fullscreen. Portrait shows “Tournez l'appareil en paysage” and a playable layout. Centre 60% clear at 800×360, 844×390 and 915×412.

## Tests (real input + advance)

- `tests/aa-takeoff.mjs`: keyboard, landscape touch, portrait touch — all PASS (unstick, climb).
- `tests/aa-arcade.mjs`: keyboard + touch takeoff, 360° turn (heading Δ≈10 rad, bank/pitch clamped, aligned), ring pass, auto-flare landing on runway 09; layouts; portrait prompt — all PASS, 0 console errors.
- Screenshot: `delivery/shots/07_mobile_arcade_844x390.png`

## Draw calls (software renderer)

title 115, day 143, mobile 149, landing 143, storm 144. All under 150. Grid 1920×1080 (mobile 1266×585). fps ~20 is the SwiftShader cap, not a phone number.

## Compare shots

- `delivery/shots/compare_day_vs_ligneclaire.png`
- `delivery/shots/compare_storm_vs_ligneclaire.png`
- `delivery/shots/compare_mobile_vs_ligneclaire.png`
- `delivery/shots/compare_mobile_layout.png` (844×390 layout vs hero mobile)
- Also: hero_day.png, hero_storm.png, hero_landing.png, 06_mobile_landscape.png, title_cover.png, 07_mobile_arcade_844x390.png

## Honest look vs the ligne-claire refs

Much closer than the previous pass: the plane now reads 3/4 rear-above (top wing, envelope insignia, pilot, cream tail, no dark prop disc), it sits in the lower-middle at a sensible size, a receding chain of 3 yellow hoops is visible, the brown pier-beam is gone, and the mobile chrome no longer covers the plane. The volcano, forests, hangar, village, tower and smoke plume are in the hero view.

Still short of the album ref: the south beach and a grid of palms still take a lot of foreground; ochre hatched sea-cliffs, the lighthouse beam, sea arch, viaduct, waterfall, sailboats and steamer are missing or tiny in this frame; the volcano is a smooth cone rather than a cratered, lava-streaked peak with a big outlined plume; the island plateaus are flatter and less terraced than the ref; a dark smear remains at the east end of the runway.

## Deploy / backup

Hidden GitHub Pages only: https://avp86fr-jpg.github.io/preview/ascii-air/ (noindex,nofollow). Path unchanged. Backup zip in the store after this pass.



---

# AEROPOSTALE AIR — M1 playtest + ligne-claire pass

Live preview (hidden, noindex): https://avp86fr-jpg.github.io/preview/ascii-air/

## What was broken (playtest) and how it was verified

1. **Takeoff was impossible.** On the ground, pitch was damped to 0 every frame, lift at 0° AoA was zero, the takeoff hint added vertical speed *after* integration so the next snap cancelled it, and a connected gamepad trigger at 0 could zero the throttle. Title-demo autopilot was also left running after VOL LIBRE, so it fought the player. Fix: one press of Shift/Espace (or GO / GAZ) slams throttle to 1; at ~0.78× stall the plane auto-rotates, unsticks, and holds a short climb window. `resetCraft` now clears leftover `airTime`. Autopilot is cleared on free flight and missions. Resting gamepad triggers are ignored unless >0.06.

   **Verified** with `tests/aa-takeoff.mjs` against a real running game: standstill on runway 09, then (a) real keyboard Shift+Space, (b) emulated pointer events on GO + GAZ in landscape 844×390, (c) the same in portrait 390×844. Physics is advanced from that live input. All three passed: airborne, AGL > 1.5 m, airspeed > 16 m/s (~34 m/s after 10 s).

2. **Mobile controls did not work reliably.** The landscape throttle was a 20px sliver, the layer could hide on large/fine-pointer touch devices, and pointer listeners were not consistently non-passive. Rewrite: always shown for touch / coarse / compact screens, 56px+ GAZ lever, 118px+ MANCHE, GO/CAM/TRAIN, `preventDefault` + `setPointerCapture`, multitouch pointerIds. First-flight hint in French. Verified by the same emulated touch tests (chrome size + actual takeoff).

3. **UI/UX.** Default UI is French cream-paper HUD for **AEROPOSTALE AIR v1.0**: stars / Trésors, **COURRIER C-14  Niv.2** (original name, not Breguet), compass SO O NO N NE, PARCOURS D'ANNEAUX, CARTE 3 km, VIT km/h, ALT m, horizon, V/S m/s, VOLETS, TRAIN, MISSION PHOTO, and in storm **MÉTÉO : ORAGE** (Pluie, Visibilité, Turbulence). Title flow: VOL LIBRE / MISSIONS / … Mobile uses a condensed layout with the centre kept clear.

## Art vs the new master refs

Side-by-side:
- `delivery/shots/compare_day_vs_ligneclaire.png` vs `refs/user_target_ligneclaire.png`
- `delivery/shots/compare_storm_vs_ligneclaire.png` vs `refs/user_target_ligneclaire_storm.png`

Also: `hero_day.png`, `hero_landing.png`, `hero_storm.png`, `06_mobile_landscape.png`, `title_cover.png` (16:9).

**Honest critique:** the plane is now a red 1920s airmail biplane (two wings, struts, wires, cream envelope insignia, radial engine, goggled pilot, cream tail, translucent prop disc). The airport has a stone tower, art-deco curved hangar with an envelope emblem, windsock, crates, crew, a vintage truck, ochre village + church. Sailboats and a pitching steamer exist; rings are yellow outlined hoops; rain slashes and a gloomier storm palette are in. Takeoff, touch, and the French HUD layout work.

It is **not** yet a finished album plate. Compared with the refs: the island is still flatter and less hatched; many landmarks (viaduct, castle, lighthouse beam, sea arch, steamer, windsock) often sit outside or too small in the hero frame; the HUD is the right structure but smaller and less “hand-lettered” than the plates; the prop/engine still reads as a dark disc from the rear chase camera; there is often only one hoop, not a receding chain; storm lightning is a pale bolt, not a large purple-white zigzag; some foam still clumps; draw calls are still **above 150** (day ~215, storm ~216, landing ~206, mobile ~235). Software-renderer fps in these captures is ~20 and is not a phone number.

## Units / naming

In-game title is AEROPOSTALE AIR (folder path `preview/ascii-air/` unchanged). Plane name is **COURRIER C-14**, never a real manufacturer. Speeds in km/h, altitude in metres.

## Art pass — limestone arch, village, HUD (6ef3502, 26 Nov 2026 ~23:36 Europe/Paris)

Hidden deploy: preview/ascii-air/ only, noindex,nofollow. Commit 6ef3502.

Shots: delivery/shots/hero_day.png, compare_day_vs_ligneclaire.png, title_cover.png, 06_mobile_landscape.png, hero_storm.png.

Done this pass:
- Sea arch rebuilt as a pale-ochre limestone headland with a cut-through window, attached to Cinder Cape (no longer a brown donut in the water). Lighthouse stands free beside it.
- Village of merged white/terracotta houses, windmills, barrel-roof hangar, cream control tower, cape fort, viaduct and waterfall present; landmarks pulled into the hero FOV (54°).
- Cream wings with red stripes, visible struts, spinning prop, rear/above hero.
- Terrain N=256 on medium/high, varied greens/ochres, cypress + round pines, no green pyramids in the water, Performance (low) cuts houses/trees/clouds and uses N=192.
- Water: turquoise near shore to deep blue, ink-line wave strokes, steamer and sailboats.
- HUD: clean compass tape `SO O NO N NE E SE`, canvas minimap with island silhouette, ★ n / 192, chunky cream ink-bordered panels.
- Stronger ligne claire, brighter day sky and extra cumulus.

Honest remaining gaps vs master:
- Cape around the arch still reads as a smooth pale loaf; hatch is weak at hero distance; arch silhouette is blockier than the painted cliff.
- Village is visible but thinner than the master's dense hillside town; viaduct and waterfall are easy to miss in the hero; windsock is hard to spot; sailboats are small.
- Mid-island hills are still smoother/more conical than the painting's rolling terraces; volcano is a simple cone.
- Plane is the right idea (cream/red, rear/above) but still smaller and more CGI than the master's 35% painted biplane.
- Sky cumulus are puffy grey blobs; ink on terrain could be stronger without filling slopes.
- Night water remains quite bright (unchanged this pass).

Draws: title 60, day/mobile 88. All in-game text English.

Backup: stores/.../ascii_air_backup/aeropostale_air_art_headland.zip

## Art pass iterate 3 — cape cliff, boats, viaduct (20de2fd, 26 Nov 2026 ~23:45 Europe/Paris)

Hidden deploy, preview/ascii-air/ only, noindex. Commit 20de2fd (follows 6ef3502).

Shots: delivery/shots/hero_day.png, compare_day_vs_ligneclaire.png, title_cover.png, 06_mobile_landscape.png, hero_storm.png.

The west cape no longer reads as a sand loaf: a beach-dome re-raise after the first shear was cut, the south face drops to the water, and hatched cliff walls sit beside the arch window. Viaduct and waterfall are larger and closer; steamer and sailboats are bigger and in frame; plane scale 1.18.

Honest leftovers vs master: arch silhouette still blockier than the painted cliff; village thinner than the dense hillside town; viaduct/falls/tower/windsock still easy to miss; mid-island hills smoother than the painting; cumulus still puffy; night water still bright; plane still more CGI than the painted 35% biplane.

Draws: title 60, day 88. Backup: aeropostale_air_art_cape_cliff.zip

## Art pass iterate 4 — hangar barrel and night water (latest preview commit, 26 Nov 2026 ~23:55 Europe/Paris)

Half-barrel hangar roof (no cat-ears). Night water dimmed with uNight (foam/spec/ripple). Shots: hero_day.png, compare_day_vs_ligneclaire.png, qa_night_water_check.png, 07_hangar_check.png.

M1–M5 QA (rings/mail/storm/night/rescue × PC+mobile): 10/10 pass, English, camera 27–40 m, ★ / 192, 3 stars each. Menu + takeoff (keyboard, touch landscape, portrait) all pass. Draws title 60 / day 88.

Backup: aeropostale_air_art_night_hangar.zip

## Art pass iterate 5 — hero composition (26 Nov 2026 ~00:10 Europe/Paris)

Hidden deploy, preview/ascii-air/ only, noindex. Commit on main (hero/title recomposition).

The hero/title camera is now a south-east vantage looking NNW, so the south coast runs diagonally: village, mills, hangar and tower on the left; viaduct and volcano in the middle; lighthouse and sea-arch on the right. Beige south-coast wall meshes were removed from the airport frontage; west-cape cliffs are layered grey-ochre with vegetation. Plane is larger (cream wings, red stripes). Clouds are white cumulus; volcano smoke is a short pale puff. HUD has mail/star/gem/plane icons and a silhouetted minimap.

Shots: delivery/shots/hero_day.png, compare_day_vs_ligneclaire.png, title_cover.png, compare_title_vs_master.png, 06_mobile_landscape.png.

Honest leftovers: waterfall still reads as a pale slab more than a cascade; mid-island hills and the volcano are still simpler than the painting; water can still look a bit flat/cyan in the foreground; village is visible but thinner than the master's dense hillside; plane sits a little right of centre; cape rock is better but still faceted.

Backup: aeropostale_air_art_hero_compose.zip


## Art pass iterate 6 — ligne-claire textures and mid-frame boxes (27 Nov 2026, ~00:30 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **66815c6** on main (after 8df2741). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed, vs the iterate-5 hero the user reviewed:

1. **Mid khaki slabs (the #1 problem).** Identified as the hangar's blank south wall, the oversized waterfall sheet, the viaduct, the mid-island / cape-fort castles, the cave boxes, and the darkened sea-arch. Hangar south face is now an arched façade with windows and a red door, scale cut 2.25 → 1.55. Viaduct and castles use pale limestone (stone.png, light vertex colours). Arch is pale ochre limestone with a rock atlas, not a beige or black lump. Waterfall sheet is smaller and more transparent; the cave boxes were removed. Soft triplanar multiply keeps vertex colour bright so ink crevices don't crush the mid-ground into a black bar.

2. **Textures.** Original procedural tileable atlases in game/textures/ (rock, grass, plaster, roof, sand, stone, water, plus a 2048×512 backdrop). Applied with triplanar MeshLambert (textured.js) and bucketed mergeStatic (rock / stone / plaster / roof / plain) so draws stay low. Painted backdrop cylinder behind the 3D island, faded at night.

3. **Plane / camera.** Hero camera is a 3/4 rear-above (~25° side, ~15° down), looking ~120 m ahead of the nose so both wings, fuselage, tail and struts read. Pilot is smaller, leather-brown cap, goggles, trailing scarf, raised in the cockpit. Cream wings, red stripes, red fuselage, black ink outlines. Tail is a cream fin plus a pointed cone (not a giant red sphere).

4. **Foreground coast.** Vegetated east-coast shelf (hero left) with groves and a modest rocky lip. No mid-bay fill, no trees in the water.

5. **Rings.** Three smaller course rings spaced in depth, offset off the lighthouse.

6. **Volcano.** Brown/grey-tan rock, greener lower slopes, small smoke wisp, crater glow only at the lip (lava rivers down the flanks removed — they painted the cone orange).

Shots of record:
- delivery/shots/hero_day.png
- delivery/shots/compare_day_vs_ligneclaire.png
- delivery/shots/title_cover.png
- delivery/shots/compare_title_vs_master.png
- delivery/shots/06_mobile_landscape.png
- delivery/shots/01_title.png, 02_island_color.png
- QA: delivery/shots/qa/m1_rings_… through m5_rescue_… (_pc/_mobile, _start/_mid/_end)

Draws (under 150): medium title 65 / day 88–91 (was 64 / 92 at 8df2741). Performance mode, booted at quality=low: title 62 / day 88, triangles ~954k–961k (about half of medium's ~1.90M) because terrainN and flora density actually drop on boot; colour RT long-edge 1440 (resScale 0.75). Swiftshader frameMs/fps is not a phone number — compare draws/triangles/resolution, not that fps.

M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase camera ~28–31 m, 3 stars each. aa-takeoff (keyboard, touch landscape, portrait) and aa-menu all pass.

Honest remaining gaps (not generous):
- The plane's near fuselage end still picks up a heavy black ink ring, so the tail can read a bit like a rounded red cap rather than a slim tail cone. The cream fin is visible but slim from this 3/4.
- The west cape under the lighthouse is still a darker brown mass than the master's pale hatched limestone, and the sea-arch window is harder to read than in the painting.
- The crater's red-orange glow is small and easy to miss from the hero angle.
- Foreground left vegetation is a green lawn + bushes more than a rocky lush Côte, and the grass can still look a little smooth/flat.
- Village is readable (white walls, terracotta roofs, mills) but still thinner and more toy-like than the master's dense hillside.
- Water is a bright cyan with stroke lines; it is not yet as rich and painterly as the master.
- A tall pale keep just left of the viaduct is still a simple stacked shaft.

Backup: aeropostale_air_art_textures.zip (store ascii_air_backup/). Weekly usage was 49.3% at the start of this turn; no live weekly meter on this box.


## Art pass iterate 7 — plane, water, in-mission polish (27 Nov 2026, 00:46 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **c83ebdc** on main (after 66815c6). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-6 hero the user reviewed:

1. **Plane (was the worst element).** Fuselage is now a fat nose, mid cockpit, and a slim tail boom — no rear disc. Cream vertical fin with a red rudder stripe and leading edge, plus cream horizontal stabilisers. Ligne-claire ink is capped on plane/metal/wood so a rounded tail no longer becomes a thick black ring. Hero camera looks just past the nose from a 3/4 rear-above, so the plane sits lower-centre (both wings in frame), slightly banked, nose pointing into the vista. Pilot still reads in the cockpit. Prop disc opacity was raised.

2. **Water.** Depth gradient: turquoise only in a tight shore band, mid blue, deeper navy, and darker in the foreground near the camera. Wave-stroke atlas + ink hatching + white crest dashes, sky reflection and a sun lane, foam around the shore and four boat positions. 3 sailboats and a steamer sit in the postcard bay.

3. **Foreground left.** The lawn blob is now a rocky east-coast headland: thin sand beach, ochre/grey cliff face, pines and cypress on top.

4. **Keep and backdrop.** The pale stacked keep was the oversized control tower; it is now a slim white shaft with a dark window strip and a readable cab. The backdrop's green wall was replaced with faint blue-grey ink-outlined distant silhouettes and a clearer sky. Day fog is a blue haze (near 2000, far 5600) so mid-island silhouettes stay clear.

5. **Sky.** More stacked cumulus, with a thin back-face ink hull so the clouds have ligne-claire outlines.

6. **HUD.** Desktop bottom bar now matches the master's layout in English: SPEED and ALT with rising bar graphs, a larger centred artificial horizon, V/S, FLAPS 0 1 2 3, GEAR. Bars hide on touch-ui to stay compact.

7. **In-mission views.** Chase shots for rings, mail, storm, night and rescue on PC and mobile. Storm rain slashes are dense; the lightning bolt is larger and unfogged (still easy to miss depending on camera aim). Night: stars were invisible because they were in the night fog — they now ignore fog and are larger; town/hangar/runway lamps are stronger; night ambient is slightly lifted so the land isn't a black void. Rescue now has a visible orange life-raft with a yellow flag under the gold ring (plus the cyan mark ring).

Gameplay feel (free-flight probe, not a device fps number): full throttle unsticks and climbs (~+4 m/s at 67 km/h after 7 s including the ground roll); cutting the lever to 0.25 descends (~−4 m/s, speed bleeds); a 5 s flaps-and-gear approach over the runway is a gentle descent (vs −2.6, no crash). Takeoff QA still climbs to ~55 m. No flight-model retune this pass — it already felt usable.

Draws stay under 150 (hero title 67 / day 81 after the cloud-ink draw). M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase ~28–32 m, 3 stars each. aa-takeoff and aa-menu all pass.

Shots of record:
- delivery/shots/hero_day.png
- delivery/shots/compare_day_vs_ligneclaire.png
- delivery/shots/title_cover.png, compare_title_vs_master.png
- delivery/shots/06_mobile_landscape.png, 01_title.png, 02_island_color.png
- delivery/shots/mission/m1_rings_{pc,mobile}.png, m2_mail_*, m3_storm_*, m4_night_*, m5_rescue_*

Honest remaining gaps:
- The hero plane is much better, but from 3/4-rear the slim boom still shows a rounded red tail cap; the prop disc is easy to miss at this distance; the plane sits a little right of true centre.
- Bay sailboats/steamer are present but smaller and less picture-book than the master's.
- The east-coast beach can still look a little faceted/low-poly at the water's edge.
- Storm lightning is easy to miss in a still frame (rain reads clearly; the cyan beacon ring can dominate the foreground).
- Night stars are visible but chunky (square points); the land is still quite dark away from the runway lamps; the moon is easy to miss.
- Open-water views (rescue) still show a regular wave-texture stripe; the wreck itself is small behind the rings.
- Village remains thinner and more toy-like than the master. Water is improved but not as painterly as the painting.

Backup: aeropostale_air_art_hero_mission.zip (store ascii_air_backup/). Weekly usage was 51% at the start of this turn; no live weekly meter on this box.


## Art pass iterate 8 — postcard camera, water stripes, night & storm (27 Nov 2026, 01:15 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **31e5577** on main (after c83ebdc). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-7 hero the user reviewed:

1. **Hero/title camera (the composition regression).** Iterate 7 looked only ~14 m past the nose, so the camera aimed down at the island, the sky vanished, and the volcano/village/viaduct were cropped. The hero camera is pulled back and slightly up and now looks at the far horizon (FOV 56). The frame is a wide postcard again: ~35% sky with stacked cumulus, volcano and castle on the skyline, airport/village left-centre, bay with boats, headland and lighthouse on the right. Title orbit is similarly further back and higher.

2. **Plane heading.** Measured, not guessed: camera-to-plane vs plane-forward is **20.5°** (under the 30° cap), camera is behind the tail, and the prop is farther than the nearest tail/gear mesh (45 m vs 34 m). The Courrier C-14 sits lower-right of centre, slightly banked, nose pointing into the scene. The prop is a visible translucent blurred disc with an ink rim, so the nose reads as the far end.

3. **Beige slab right of the lighthouse.** That was the west-cape coastal wall (a straight terrain shear plus an extra rectangular cliff mesh and boxy arch buttresses). The shear is now a jagged limestone edge, the extra wall is gone, cliff shelves are irregular and greyer, and the sea-arch is a rocky cut rather than a tan rectangle.

4. **Open-water stripes.** The regular bands were mostly world-space "crest dash" strokes painted across the whole sea (a `fract` hatch with a bias that never turned off), plus a strongly striped water atlas and two-tone posterize on the water. Crest dashes are now only on nearby real peaks, the atlas is subtler and warped, distant normals flatten, and water/sky are excluded from two-tone and ink-hatching. Title and hero open water is a smooth depth gradient again (darker in the foreground, turquoise near the shore).

5. **Night stars.** Chunky square `PointsMaterial` sprites are replaced with a soft-disc point shader, 900 small round points of varying size, some twinkle. They ignore fog and sit in front of the sky. Visible in the hero night postcard and in the M4 chase.

6. **Lightning illumination.** A flash now pulses ambient/hemi/sun and the sky/fog colours, and the post-process lifts the whole frame (sky + terrain), not just a thin additive veil. Tuned so a still storm shot brightens the island without blowing out to white. Rain and the bolt still read.

In-mission chase shots (M1 rings, M2 mail, M3 storm, M4 night, M5 rescue) recaptured on PC 1920×1080 and mobile 844×390. Mail over the hangar/tower and night over the lit runway are the strongest; storm rain and a flash pulse read; rescue open water no longer stripes, though the wreck/raft is still easy to miss in that particular pose.

Draws stay under 150 (title ~81–89 / hero ~87–89; medium triangles ~1.96M). Swiftshader frameMs/fps is not a phone number — compare draws/triangles, not that fps.

M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase ~28–36 m, 3 stars each. aa-takeoff (keyboard, touch landscape, portrait) climbs to ~55 m. aa-menu all pass, 0 console errors. Flight model was not retuned this pass.

Shots of record:
- delivery/shots/hero_day.png
- delivery/shots/title.png, 01_title.png, title_cover.png
- delivery/shots/hero_night.png, hero_storm.png (and hero_storm_noflash.png for the base storm look)
- delivery/shots/mission/m1_rings_{pc,mobile}.png, m2_mail_*, m3_storm_*, m4_night_*, m5_rescue_*

Honest remaining gaps:
- From almost dead astern the mid-fuselage still reads as a fairly fat rounded red mass; the slim boom and cream fin are there, and the prop disc marks the nose, but it is not yet a needle-taper like the master.
- The plane sits a little right of true centre (intentional 3/4, 20.5°). A hair more left would match the master's lower-centre even closer.
- The west cape is no longer a beige rectangle, but it is still a bit tan and simpler than the master's hatched limestone headland; the arch window is readable but small.
- Village is still thinner and more toy-like than the master. The hangar south face can read a little pale.
- Boats are in the bay but small. The waterfall is easy to miss.
- Rescue chase can look like "seaplane over empty water" if the wreck/raft is out of frame.
- Night land away from the runway lamps is still quite dark; the moon is easy to miss.
- Storm flash in a still frame is a judgement call (too strong earlier in this pass, now a moderate lift). Live play will pulse; a single screenshot can't show the flicker.

Backup: aeropostale_air_art_iter8_postcard.zip (store ascii_air_backup/). Weekly usage was 52% at the start of this turn; no live weekly meter on this box.


## Art pass iterate 9 — true rear-3/4 Courrier, water, boats, clouds, greens, arch (27 Nov 2026, 01:47 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **3b31be0** on main (after 31e5577). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-8 hero the user reviewed:

1. **Plane (the #1 problem: still read as nose-toward-camera).** Two stacked bugs. First, `mergePlaneStatic` ran *after* the visual was flipped 180° and scaled, so the baked fuselage/engine/wheels were transformed twice and the radial engine sat on the tail — that "big round red cowl-like disc with ink rim, wheels hanging below it" *was* the engine, co-located with the cream tail. Merge now happens while the visual is still identity; flip + 1.32 scale come after, so body and empennage share one transform. Second, the tail itself was rebuilt: closed solid taper (open cylinder ends looked like a dark hole from behind), a long slim boom to a pointed cone (no round cap), a raked cream vertical fin + red rudder that clears the upper wing, and modest cream horizontal tailplanes. Rudder orientation is baked so animation no longer flops the fin into the wrong plane. Hero camera is a rear-3/4, ~20° down and ~24° to the side (combined ~30.6°), with a film-gate `shiftY` so the postcard horizon stays high. Numerically: camera behind the tail, prop farther than the cone (52 m vs 42 m).

   Closeup sheet (rear-3/4, side, front) confirms: from behind-above you see the narrowing boom, upright cream fin/rudder, horizontal stabs, the pilot's head and back, and the prop disc far away at the front. The side elevation is a proper biplane profile (tail left, engine and spinner right). The front is the cowling, wheels and prop disc.

2. **Water.** The big white curved foreground bands were a mid-bay foam isoline plus near-camera crest dashes. Those are gone. Foam is only a tight shoreline strip and small boat wakes. Open water is a smooth depth gradient again.

3. **Boats.** Sailboats are a pointed white/wood hull, mast, triangular sail and ink outline — not a grey slab on a blue box. The steamer has a pointed hull, cream superstructure and a funnel with a red band; it sits in the mid-bay toward the lighthouse, clear of the hero plane.

4. **Clouds.** Fewer, bigger, white with a light-blue base: banks along the horizon and a few large ones up top, thinner ink. The grey-shaded clutter is gone.

5. **Greens.** Saturated lime is replaced with olive, sage, deep pine and muted meadow, plus ochre field patches and dark terrace lines. Beaches are sand-coloured. Foreground trees use the same muted greens.

6. **Arch.** The thin brown frame is now a chunky pale limestone mass (thicker extrusion, smaller hole, toes and a spine into the cape), attached to the right-hand cliff.

Hero/title composition from iterate 8 is kept (postcard sky, volcano and castle on the skyline, airport/village, bay, headland). In-mission chase shots for M1–M5 were recaptured on PC and mobile; the Courrier now also reads rear-3/4 in chase (cream fin nearest, nose into the scene). Night stars still read as small soft points; the lighthouse beam is on. Storm flash is a moderate pulse (0.62).

Draws stay under 150 (title 86 / hero 92; title/hero calls 94; medium triangles ~1.81M). Swiftshader frameMs/fps is not a phone number — compare draws/triangles, not that fps.

M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase ~28–36 m, 3 stars each, 0 errors. aa-takeoff (keyboard, touch landscape, portrait) unsticks and climbs to ~55 m. aa-menu all pass, 0 console errors. Flight-feel probe (unguarded flyCam was fixed in the test only): full throttle climbs (~+4 m/s at 67 km/h); lever at 0.2 descends (~−4 m/s); a short approach does not crash. Flight model was not retuned this pass.

Shots of record:
- delivery/shots/hero_day.png
- delivery/shots/title.png, 01_title.png, title_cover.png
- delivery/shots/plane_closeup_sheet.png (and plane_rear34.png, plane_side.png, plane_front.png)
- delivery/shots/hero_night.png, hero_storm.png, hero_storm_noflash.png
- delivery/shots/mission/m1_rings_{pc,mobile}.png, m2_mail_*, m3_storm_*, m4_night_*, m5_rescue_*

Honest remaining gaps:
- The hero plane finally reads as a rear-3/4, but it still sits a little right of true centre and is a hair small versus the master's lower-centre postcard. The slim boom is visible; it is not yet a needle-taper oil painting.
- The west cape / chunky arch is much closer to limestone, but still simpler than the master's hatched cliff.
- Village is still thinner and more toy-like than the master. The hangar south face can read a little pale.
- Boats are proper now, but smaller than the master's picture-book craft. The waterfall is easy to miss.
- Rescue chase can still look like "plane over empty water" if the wreck/raft is out of frame.
- Night land away from the lamps is still quite dark; the moon is easy to miss. A couple of unlit ring outlines can show as black circles in the night postcard.
- Storm flash in a still frame is a judgement call. Live play will pulse.
- userData.wheels world positions are stale after the static merge (visual wheels are fine; only the debug distances are wrong).

Backup: aeropostale_air_art_iter9_rear34.zip (store ascii_air_backup/). Weekly usage was 53% at the start of this turn; no live weekly meter on this box.


## Art pass iterate 10 — hero postcard polish, night moonlight, rescue framing (27 Nov 2026, 02:09 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **ffdff74** on main (after 3b31be0 / 353dd10). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-9 hero the user reviewed:

1. **Plane (scale and placement).** Hero visual scale is now `1.32 × 1.45` (~1.4× the iterate-9 on-screen size), with `HERO_VIEW.shiftX` 0.13 and the world x nudged from 55 to 40 so the Courrier sits lower-centre at about 32–35% of frame width. The pilot was raised and slightly enlarged (`y=1.28`, scale 1.08); the dark leather-capped head is visible in the cockpit from the rear-3/4. Merge-order (merge while identity, then flip + scale) is unchanged — the tail still reads as a slim cream boom, upright fin/rudder, and far prop disc.

2. **Right arch.** Rebuilt as an irregular 15-point jagged limestone mass with a tall narrow window (`absellipse` 3.15 × 15.5), rock vertex colours with hatching and darker crevices, irregular toes/spine attaching it to the cape, and instanced bushes plus three cone pines on the crown. It is no longer a flat beige box with a hole.

3. **Foreground left cliff "caves".** Those were a regular dark hatch in `makeCoastalCliffs` (vert stops down to 0.28 on a near-black base). Hatch stops are now 0.72/0.82/0.92/1 with paler bases, so the row of black holes is gone. Remaining mid-face shading is just rock recess, not a hole.

4. **Steamer.** Rebuilt: dark hull (0x2a2e36), red waterline, large cream/white superstructure, funnel with a wide red stripe and a black cap. Placed at (−150, 0.25, −1338), yaw −0.7, scale 2.7, mid-bay toward the lighthouse and clear of the plane. Each boat/steamer is merged *inside its own group* (baked into the group's local space, not world — the world bake put the steamer at 2× its position) so they can still bob without blowing the draw-call cap.

5. **Viaduct.** The solid pier boxes that filled the openings are gone. The facade is an extrusion with five real arch cutouts, pale stone vertex colours (0.90, 0.86, 0.76) plus a mild emissive so land and sky show through. Pale parapet posts.

6. **Dark spots / ink blobs on terrain.** Terrace darkening, forest floor and rock crevices were lifted (terrace 0.88/0.86/0.84, forest [0.22, 0.36, 0.18], crevices ×0.78 instead of ×0.55) so village-adjacent and cliff-top blotches no longer read as stray ink or z-fighting.

7. **Compass tape.** The bracket text strip `( SO O NO N NE E SE ) 356° N` is gone. `#hud-compass` is a cream panel with a downward black caret, a gold centre mark, and a canvas scrolling tape (major ticks every 45°, minor every 15°, labels N/NE/E/SE/S/SO/O/NO, span 200°). In the hero it reads as a tape `O NO N NE E` with the gold box on N.

8. **Village.** Six terrace bands step up the hill with a denser house grid (up to ~420 houses). A church with a square bell tower, belfry openings, gold bell, red pyramidal cap and a cross sits higher on the hill, clearly readable left of the viaduct.

Mission-view polish:

- **Night land readability.** A moonlight directional (0xc4d0ea, intensity 0.62 at night) plus lifted hemi/ambient (hemi toward 0x9aacc8, +0.42 / +0.32) and farther night fog (1200/4400 instead of 700/3200). Village, viaduct, lighthouse, arch and trees stay readable; the moon is a white disc.
- **Ring outlines at night.** Default rim is a mid brown (0x4a3218). `applyRingNight` switches rims to gold-brown (0xc4a04a) and cores to bright gold (0xffe07a) when night > 0.4, so rings no longer read as black circles. Hooked from the frame loop, heroShot, and setTime.
- **Rescue wreck in frame at start.** res-b1 start moved from (−400, 40, −1400, heading −0.6) — which flew ESE away from the wreck — to (−640, 38, −1480, heading −2.30, speed 40). The wreck at (−820, −1680) is ~269 m ahead; the start chase shows wreck, gold rings and the raft/flag.

Draws stay under 150 (title/hero calls 94; titleN 105, heroN 111; medium triangles ~1.82M). An intermediate un-merged steamer/boat skip briefly went to 155 calls; per-group local-space merge brought it back under the cap without losing the cream superstructure. Swiftshader frameMs/fps is not a phone number — compare draws/triangles, not that fps.

M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase ~28–36 m, 3 stars each, 0 errors. aa-takeoff (keyboard, touch landscape, portrait) unsticks and climbs to ~55 m. aa-menu all pass, 0 console errors. Flight-feel probe unchanged (climb ~+4 m/s at 67 km/h; idle ~−4 m/s; short approach does not crash). Flight model was not retuned this pass.

Shots of record:
- delivery/shots/hero_day.png
- delivery/shots/title.png, 01_title.png, title_cover.png
- delivery/shots/plane_closeup_sheet.png (and plane_rear34.png, plane_side.png, plane_front.png) — mesh shape unchanged from iterate 9; only hero visual scale changed
- delivery/shots/hero_night.png, hero_storm.png, hero_storm_noflash.png
- delivery/shots/mission/m1_rings_{pc,mobile}.png, m2_mail_*, m3_storm_*, m4_night_*, m5_rescue_*

Honest remaining gaps:
- The Courrier is close to the master's ~35% frame width and lower-centre, but still a hair right of exact centre. The slim boom is visible; it is not yet a needle-taper oil painting.
- The steamer reads correctly (cream decks, dark hull, red waterline, striped funnel) but is still a bit blocky / toy-like versus the master's picture-book liner.
- Arch vegetation is present but modest; the limestone mass is irregular now, not a painted cliff.
- Village is denser and has a bell tower, but houses are still toy-like versus the master. The hangar south face can read a little pale.
- The waterfall is still easy to miss.
- Night land now reads, but the unlit runway away from the lamps is still quite dark.
- Storm flash in a still frame is a judgement call. Live play will pulse.
- userData.wheels world positions are still stale after the static plane merge (visual wheels are fine; only the debug distances are wrong).

Backup: aeropostale_air_art_iter10_postcard.zip (store ascii_air_backup/). Weekly usage was 54.1% at the start of this turn; no live weekly meter on this box.


## Art pass iterate 11 — steamer, coast holes, storm look, in-mission feel (27 Nov 2026, 02:30 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **f0bdfe0** on main (after ffdff74 / 92fa99c). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-10 hero and the m3_storm_mobile the user reviewed:

Hero leftovers:

1. **Steamer.** Rebuilt as a long low liner (hull ~32, funnel top ~8, length about 4× height): dark hull, red waterline, cream superstructure along midships, modest striped funnel. Moved farther back into mid-bay at (18, −1268) and yawed 1.05 so the hero sees a broadside profile, not a tall black/white tower standing in the water.

2. **Dark oval holes on the coast.** Two causes. South-coast terrain inlets were lerping height down to −1.2, punching real holes in the mesh; those cuts are gone (a slight scallop at most). West-cape cliff code was also skipping regular “coves” every 47 m — that skip is gone (the arch window gap stays). Rock crevices were lifted another step. Left and mid-island coasts no longer read as a row of black caves.

3. **Waterfall.** A proper cascade: rock lip and plunge pool, three staggered sheets, foam at top and bottom, scaled up. Still easy to miss in the dense village cluster, and it can wash a little pale at night — better than the old faint slab, not yet a postcard landmark.

4. **Hangar face.** Warmer cream plaster, ochre plinth, terracotta-tinted barrel roof, terracotta arch trim, and a dark interior so the south door opening reads as a hall, not a hole or a washed-out slab. Visible in the M2 mail chase.

In-mission look:

- **Storm.** The bright blue sky was the painted day backdrop, still drawn in storm, plus a mild storm palette. The backdrop now hides in storm. Sky is dark slate (zenith 0x151c28, tighter fog). Clouds drop to a low dark ceiling. Sea shifts to grey-green chop with small noisy whitecaps (an earlier, larger cap mask looked like ice floes — that was pulled back). Rain is heavier, denser toward the top of the frame, and darkens the scene. Lightning bolts spawn ahead of the plane; a flash still pulses lights and sky. Wind gusts gently push the craft in the wind direction (fair), with lighter turbulence than before. Island fill is lifted just enough that the land stays readable without a flash.

- **Night.** Moon and stars remain. Village gets instanced warm window lights after dark. The lighthouse beam is stronger at night and still sweeps. Runway lamps were already in place.

- **Dawn/dusk.** rings-b2 is now 6.8 (dawn). Several existing missions already sit at 16.5–17 (golden/dusk).

- **Rings near the camera.** Core and rim fade with camera distance so a close torus no longer clips into a broken yellow arc. The current ring in the storm chase is a soft faded curve, not a hard banana across the lens.

- **Mobile HUD.** The compact Beacon chip is kept; briefing/minimap stay hidden on touch. Boost stays on the right and no longer fights a huge unfaded ring.

Gameplay sensations (kept cheap: two instanced meshes + a handful of skid planes):

- Speed lines were already in the post-process (`uSpeed`); they still scale with airspeed. Wind loop gain/pitch now climbs more clearly with speed.
- Subtle camera shake on boost, and a light gust bump in turbulence (the existing `bump` path).
- Ring pass: sparkle burst + the existing chime.
- Mail drop: cream sparkle + `success`; pickup is a smaller burst + `ui_ok`.
- Landing touchdown: dust puff and a fading skid mark on land, a splash puff on water; existing touchdown/splash sounds and a bump on a rough arrival.

Draws stay under 150 (title/hero calls 117; titleN 108, heroN 114; medium triangles ~1.82M). New draws are winlights, extra fall sheets, hangar trim, and feel-fx. Swiftshader frameMs/fps is not a phone number — compare draws/triangles, not that fps.

M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase ~28–36 m, 3 stars each, 0 errors. aa-takeoff (keyboard, touch landscape, portrait) unsticks and climbs to ~55 m. aa-menu all pass, 0 console errors. Flight-feel probe unchanged (climb ~+4 m/s at 67 km/h; idle ~−4 m/s; short approach does not crash). Flight model was not retuned this pass; storm gusts are a gentle added push only.

Shots of record:
- delivery/shots/hero_day.png
- delivery/shots/title.png, 01_title.png, title_cover.png
- delivery/shots/hero_night.png, hero_storm.png, hero_storm_noflash.png
- delivery/shots/mission/m1_rings_{pc,mobile}.png, m2_mail_*, m3_storm_*, m4_night_*, m5_rescue_*

Honest remaining gaps:
- The steamer finally reads as a long low ship, but it is still a bit blocky versus a picture-book liner, and a sailboat can sit in front of it in the hero.
- The waterfall is more of a cascade now, but it can still wash out as a pale sheet in the village cluster, especially at night, and is easy to miss in the day postcard.
- Storm chase can show a somewhat flat mid-sky cloud; the hero storm ceiling is the stronger read. Lightning is clearer in the hero storm than in a given chase angle (the bolt can sit off-frame).
- Whitecaps are subtle on purpose (the first storm sea had ice-floe-sized white blobs). Not yet a painted heavy seascape.
- Village night windows are modest; mill and outlying houses stay dark. The unlit night runway between the lamps is still quite dark.
- A close ring is a faint arc rather than a hard clip — better, not invisible.
- Mail sparkle, landing skids and boost shake are felt in play more than in stills.
- The Courrier in the hero is still a hair right of exact centre.

Backup: aeropostale_air_art_iter11_stormfeel.zip (store ascii_air_backup/). Weekly usage was ~56% at the start of this turn; no live weekly meter on this box.


## Art pass iterate 12 — readable storm and night (27 Nov 2026, 02:50 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **9fdb7db** on main (after f0bdfe0). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-11 m3_storm_mobile the user reviewed (nearly black, dense diagonal hatch over the whole frame, plane/island/ring barely readable):

Storm readability (the overcorrection fix):

- **Exposure ~60% of day, moody slate-blue/grey, not black.** Storm zenith/horizon 0x3a5068 / 0x5e7588. Hemisphere 0.80, sun 0.42, ambient 0.50, fog 0x5a7284 at 1400/4200. `uNight` is no longer applied on top of the storm look (that double-crush is what turned the scene black). The painted day backdrop still hides in storm, so it does not snap back to a clear afternoon.
- **Rain is sparse long streaks, not a full-screen hatch.** Post-process rain uses ~52 px spacing, thin slightly translucent streaks (mix 0.48 into a pale slate), long dashes, only about 58% of lanes kept. Rain is skipped on the plane and rings and softened in the screen centre. The global `col *= 1.0 - 0.16*uRain` hatch crush is gone.
- **Plane ink stays strong** on dark backgrounds (outline cap 0.62, ink mix 0.86) so the Courrier still reads as a ligne-claire drawing.
- **Island colours are desaturated but visible** (mild 0.16 land desat in the rain pass). Terrain, village and coast stay flat-colour readable, like a stormy BD panel.
- **Rings are bright gold with a glow.** Core 0xfff25a, ink rim, additive gold glow torus. Night/storm keep the core bright (0xfff6a0 / 0xfff25a). Near-cam fade only starts when the torus is about to clip, with a high floor, so the current ring in the storm chase is a bright gold curve, not a black hoop or a broken hatch.
- **Lightning flashes briefly light everything** (ambient / hemi / sun and zenith/horizon lerp). Storm clouds stay mid-slate (0x6a7a8a), not black pancakes. Sea is a readable slate (0x1e4458 / 0x3a6274) with sparse whitecaps.
- A mid-pass sky was a hair too close to a clear day; it was nudged greyer toward “moody slate” while staying well above the black floor.

Night readability:

- Sky palettes are a moonlit blue (zenith 0x1a305c, horizon 0x3a5a88), not 0x050818. Stars and the moon stay; village window lights and the lighthouse beam still read.
- **Night sea is a moonlit navy with a soft horizon sheen and a moon path, not a black sheet and not leftover day turquoise.** A real bug was that `island.setStorm(false)` ran every frame *after* `water.update` and snapped uDeep/uShallow back to day cyan (0x3ec8c0). Leaving a storm no longer overwrites the time-of-day palette; `update()` applies it. Open water uses a lifted navy (0x1c4a78 / 0x2a6a8e) with a readable floor so the far sea does not fall to ink.
- **heroShot / landingShot / stormShot / setTime now call `island.update`**, so a paused postcard (and the QA captures) get the matching water, backdrop and night fill. Before, a still hero night could render with day-cyan water even when live play was correct.

Chase camera (normal flight, PC + mobile): FOV 56 (plus +3 on very wide mobile), chaseDist 28, chaseHeight 10.8, look-ahead 28 m + y 1.4. M1–M2 chases over the island keep the plane, the gold target and the horizon in frame; the compact mobile Beacon chip does not hide the target.

Mobile mission readability check (plane, target, horizon):

- M1 rings: clear — gold glowing ring against land/sky, plane and runway/horizon readable.
- M2 mail: clear — hangar and gold ring in frame, plane and coast readable. BOOST sits near the right-hand ring but the ring still reads.
- M3 storm: the fix — moody slate sky, slate sea, sparse rain, bright gold ring, readable plane and island.
- M4 night: moonlit blue sky, navy sea and lagoon, land silhouettes, plane and runway lamps readable. Not black.
- M5 rescue: gold-glow rings mark the wreck ahead; plane and horizon readable. The wreck itself is still small at ~269 m.

Draws stay under 150 (title/hero calls 117; titleN 108, heroN 117; medium triangles ~1.82M). The extra ring glow is one mesh per active ring. Swiftshader frameMs/fps is not a phone number — compare draws/triangles, not that fps.

M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase ~26–42 m, 3 stars each, 0 errors. aa-takeoff (keyboard, touch landscape, portrait) unsticks and climbs to ~55 m. aa-menu all pass, 0 console errors. Flight-feel probe unchanged (climb ~+4 m/s at 67 km/h; idle ~−4 m/s). Flight model was not retuned this pass.

Shots of record:
- delivery/shots/hero_day.png (unchanged from iterate 11; steamer/holes already good)
- delivery/shots/hero_night.png, hero_storm.png, hero_storm_noflash.png
- delivery/shots/mission/m1_rings_{pc,mobile}.png, m2_mail_*, m3_storm_*, m4_night_*, m5_rescue_*

Honest remaining gaps:
- Storm sky in the hero postcard is still a little brighter and bluer than the in-mission m3 chase (the lighthouse beam and open vista lift it). It is no longer black, and no longer a clear-blue afternoon with rain on top.
- Night open water is a fairly even mid-navy; the moon path is easier to see in motion than in a still, and the hero sea is slightly flatter than a painted BD night panel.
- The unlit night runway between the lamps is still quite dark (lamps and the plane read; the tarmac strip does not).
- The rescue wreck is still small at start distance; the gold rings carry the target read.
- A close ring can still be a gold arc rather than a full torus once it is almost at the lens.
- Lightning is clearer in the hero storm (and in the m3 mobile shot with flash 0.45) than in a given chase angle — the bolt can sit off-frame.
- The steamer is still a bit blocky; the waterfall is still easy to miss in the village cluster.
- Mail sparkle, landing skids and boost shake are felt in play more than in stills.
- The Courrier in the hero is still a hair right of exact centre.
- A thin dark stroke sometimes reads across the mid-ground in chase views (runway/edge ink at a glancing angle).

Backup: aeropostale_air_art_iter12_readable_storm.zip (store ascii_air_backup/). Weekly usage was 56.3% at the start of this turn; no live weekly meter on this box.

## Art pass iterate 13 — chase readability (27 Nov 2026, 03:31 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **41a7f6f** on main (Pages tip was 8b7dbee, other previews, after ascii-air 9fdb7db). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-12 m3_storm_mobile + m4_night_mobile the user reviewed:

1. **White pill under the compass.** Empty `#hud-msg.banner.hud-line` still had cream fill, padding and an ink border when the text was blank. Hidden with `#hud-msg:empty { display: none }` and a `hidden` class when the banner has no text. Gone in every recapture.

2. **Flat cloud ellipses.** The instanced puff was a few spheres then scaled Y to ~0.45, collapsing to pancakes (dark ovals in storm, a grey UFO disc at night). Rebuilt as an 11-sphere stacked cumulus with Y scale ~0.86–0.88; storm scales stay volumetric, so chase clouds are layered dark banks and fluffy white stacks, matching the hero.

3. **Huge gold arc across the lower half.** `fadeNearCam` had a 0.7 floor, and mail/storm rings lacked `userData.base` so the radius defaulted to 16. The ring now hides when the camera is inside its radius, close (gap < 48 m), edge-on and close, or a large beacon (rad ≥ 20 and gap < 86). Only the next/current ring stays highlighted. The m3 storm beacon at the review distance is hidden (the "Beacon: South Bay" chip carries the target); the m1 ring ahead stays at vis 0.8.

4. **Storm water disc.** Day sun specular still ran in storm (`uSunCol` was 0xfff0c8). Specular is now damped by `uChop`, and storm `uSunCol` is 0x7a8ea0. The m3 sea is an even dark slate, with no large white radial glow under the plane.

5. **Dark holes along the coast.** The ringing-coast cut is capped at 0.16, the cliff toe is lifted to y=0.25 (was −0.6), and a shoreline floor of 1.2 m kills under-shelf cavities. A chase-height pass around the island was captured in `delivery/shots/coast/`. The m3 right shoreline is cleaner. Residual dark tree-shadow / waterline patches can still read as spots.

6. **Night black ink line (runway edge).** Isolated to the merged low runway/road mesh: a long thin dark box seen end-on rasterised as a black stroke (and as a dashed stroke once roads were split into 16 m segments). Roads, the hangar apron and centerline dashes are now horizontal slabs (no vertical faces). The merged runway material is unlit MeshBasic with depthWrite false and polygonOffset; the ink shader skips ROAD and RUNWAY; a glance-angle discard drops fragments seen almost edge-on. The line is gone in m1, m2 and m4; the white centerline dashes still read on the tarmac.

7. **BOOST overlapping THROTTLE.** The THROTTLE label sits to the left of the lever, and the BOOST gap above the lever is 26 px (was 8). Recaptures show them clearly separated on landscape mobile.

Mission-view polish this pass is the seven items above. Feel FX from iterate 11 (boost shake, ring sparkle, mail burst, landing skid) still stand and show more in play than in stills.

Draws stay under 150 (aa-draws titleN 110, heroN 119; live heroShot calls 130; medium triangles ~1.89M). `runwayHi` is one extra merged mesh so the ridge strip cannot form a mid-air sliver with the airport paint. Swiftshader frameMs/fps is not a phone number — compare draws/triangles, not that fps.

M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase ~26–42 m, 3 stars each, 0 errors. aa-takeoff (keyboard, touch landscape, portrait) unsticks and climbs to ~55 m. aa-menu all pass, 0 console errors. Flight model was not retuned this pass. The final slab + glance-discard change is visual-only and was signed off on the recaptured m1/m2/m3/m4 stills after that QA.

Shots of record:
- delivery/shots/hero_day.png, hero_landing.png, hero_storm.png (recaptured; stacked cumulus)
- delivery/shots/hero_night.png (recaptured with `heroShot({ hour: 21 })`)
- delivery/shots/mission/m1_rings_{pc,mobile}.png, m2_mail_*, m3_storm_*, m4_night_*, m5_rescue_*
- delivery/shots/coast/coast_00.png–coast_11.png

Honest remaining gaps:
- Some dark tree-shadow / waterline patches along the coast in chase are improved, not fully gone.
- The m3 current beacon is hidden at the review camera distance, so the HUD chip carries the target until the next ring is farther or more face-on.
- The unlit night runway between the lamps is still fairly dark (lamps, dashes and the plane read; the tarmac strip does not).
- The rescue wreck is still small at start distance; the gold rings carry the target read.
- Lightning is clearer in the hero storm than in a given chase angle — the bolt can sit off-frame.
- The steamer is still a bit blocky; the waterfall is still easy to miss in the village cluster.
- Mail sparkle, landing skids and boost shake are felt in play more than in stills.
- The Courrier in the hero is still a hair right of exact centre.

Backup: aeropostale_air_art_iter13_chase_readability.zip (store ascii_air_backup/). Weekly usage was 57% at the start of this turn; no live weekly meter on this box.

## Art pass iterate 14 — close-range flight (27 Nov 2026, 04:01 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **e973c26** on main (after ascii-air 41a7f6f). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-13 m1_rings_mobile the user reviewed (grey/white ring, chaotic 420-house pile, untextured hangar blob, flat ink-edged fields, orange runway confetti):

1. **Ring-ahead highlight.** The current ring was faded to opacity 0.8 (and transparent) at the review distance, so ACES plus the sky washed gold into grey/white and the glow died. The ring ahead is now a solid saturated gold (0xffc20a) with a visible glow; later rings stay gold, just dimmer (0xe0a410), never a grey hoop. Fade only kicks in when the current ring is about to clip the lens.

2. **Village layout and LOD.** The old 420 overlapping cone-roof houses (random yaw, overlapping terraces, all merged) read as a pile of red shards at close range. Houses now sit on non-overlapping street/terrace bands facing south, with consistent gable roofs, spacing, plaster walls, doors, windows on three faces, and chimneys. Near the runway / hangar flight path: real detailed houses plus low stone terrace walls. Further up the hill: instanced impostors (wall + gable) so the postcard still reads as a town, without interpenetration.

3. **Hangar roof.** The barrel was tagged MAT.ROOF and merged into the terracotta tile atlas, so close-up it was a smooth brown/curved blob. It is now its own unmerged mesh: tileable corrugated metal, hoop ribs, a ridge cap, and inkable metal edges.

4. **Fields.** Ochre patches were flat vertex colours with hard ink edges. Field vertices are tagged for the terrain shader, which draws crop rows and soft plot breaks; grass/field colours lerp at the boundary. A few small farms (house, barn, stone yard wall, hedge) and long field hedges sit on the mid-island slopes.

5. **Runway lights.** The orange 1.6 m cubes (MAT.LIGHT, on all day) are gone. Edges are small dark lamp posts with a fixture head; the warm glow is instanced and visible only at night (same night toggle as village windows).

6. **Low-flight survey** across airport, hangar, village, fields, lighthouse/cape, castle, volcano, sunny beach, lagoon, and church/mills: `delivery/shots/low/` and contact sheet `delivery/shots/low_flight_survey.png`. Closest remaining eyesores are noted below.

Gameplay feel was not retuned this pass; the gold ring-ahead read is the feel change players will notice most. Iterate-11 FX (boost shake, ring sparkle, mail burst, landing skid) still stand.

Draws stay under 150 (aa-draws titleN 127, heroN 136; live heroShot 136, mobile hero 147; medium triangles ~1.88M). Extra calls are the hangar roof, far-house instances, and runway lamp instances. Swiftshader frameMs/fps is not a phone number — compare draws/triangles, not that fps.

M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase ~26–42 m, 3 stars each, 0 errors. aa-takeoff (keyboard, touch landscape, portrait) unsticks and climbs. aa-menu all pass, 0 console errors. Flight model was not retuned this pass.

Shots of record:
- delivery/shots/hero_day.png, hero_night.png, hero_storm.png, hero_landing.png
- delivery/shots/mission/m1_rings_{pc,mobile}.png, m2_mail_*, m3_storm_*, m4_night_*, m5_rescue_*
- delivery/shots/low_flight_survey.png and delivery/shots/low/low_01–10_*.png

Honest remaining gaps:
- The hero postcard village is a bit thinner than the old dense cluster (fewer, better houses was the point; the hillside is no longer a packed red mass from the south).
- Some close-range dark spikes / sliver shadows still appear near the hangar lagoon and on the cape cliffs (holes in the lighthouse close-up). Not fully gone.
- Crop rows read clearly on the mid-island slopes; from a high chase they are still fairly subtle, and some ochre patches remain flatter than a painted BD field.
- Night runway glows are small on purpose (so they are not confetti); they are easy to miss at the m4 review distance.
- The m3 current beacon is still hidden at the review camera distance; the HUD chip carries the target.
- Rescue wreck is still small at start; gold rings carry the target.
- The steamer is still a bit blocky; the waterfall is still easy to miss in the village cluster.
- A couple of low-survey camera poses (castle, volcano) did not frame the landmark as tightly as the hangar/village/fields/lighthouse plates.
- Mail sparkle, landing skids and boost shake are felt in play more than in stills.
- The Courrier in the hero is still a hair right of exact centre.

Backup: aeropostale_air_art_iter14_close_range.zip (store ascii_air_backup/). Weekly usage was 58.9% at the start of this turn; no live weekly meter on this box. Ceiling is now ~78%.

## Art pass iterate 15 — low-flight eyesores (27 Nov 2026, 04:51 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **8873fd6** on main (after ascii-air e973c26; other previews landed in between). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-14 low-flight survey the user reviewed (floating green canopies over water, camera inside the volcano, black slabs/spikes on the airport/hangar/beach/church, floating black rocks, lighthouse cliff holes, bare green fields):

1. **Black slabs and spikes (01 / 02 / 08 / 10).** These were not shadow maps. `makeRoad` set Euler XYZ with x = −90°, which gimbal-locked; a yawed road stood up as a near-vertical, almost-black MeshBasic slab. The hangar apron (38×26, scaled 1.55, colour 0x3a3a3a) was a 59×40 m unlit dark plane at y ≈ 8.15 that cut through the lagoon slope. Roads now use Euler YXZ so slabs stay horizontal, snap to `heightAt + 0.08`, and skip water (h < 2.4). The apron is a smaller, lighter concrete pad offset inland. ROAD is its own lit Lambert bucket (no longer crushed to black in the unlit RUNWAY MeshBasic merge). Recaptured 02 hangar and 10 church have no black wedges; 01 and 08 are clean of the same family.

2. **Floating vegetation, island-wide.** Flora instance origins were already on the terrain (0 floaters / 0 over water in a full dump). A placement helper now snaps every tree/blob, culls water, runway, and slopes steeper than ~42°, and sets a bounding sphere that actually encloses the instances. Foliage emissive dropped from 0.58 to 0.16 so distant canopies fade with the land instead of hanging as a bright green cloud over washed-out slopes (the 06 “specks over water” look). Cliff-lip bushes that punched circular ink holes in the lighthouse plateau were removed on the west cape and flattened/brightened elsewhere. Post-fix dump: flora 19,225 + 459 + 218 and cliff tufts, 0 over water, 0 floaters.

3. **Volcano camera inside the mesh (07) and floating dark rocks.** The old survey camera (160, 100, 40) sat 141 m *below* the cone surface (heightAt 241 m; Mount Glyph base radius ~520 m). The brown untextured slab was the interior of the heightfield. `lookFrom` and the chase camera now lift to `max(nearby heightAt) + 8 m` (neighbour samples so a steep face cannot swallow the lens). The 07 plate is taken from (620, 170, −80), outside the cone, looking at the peak; trees on the lower slopes sit on the ground. No interior slab.

4. **08 beach floating black rocks.** The nearly vertical harbour road (same gimbal-lock bug, ny ≈ −0.09, y from −5 to 10) was standing in the cove as dark “boulders.” With YXZ + terrain snap + water cull, those slabs are gone. Recaptured 08 has no mid-air black rocks.

5. **05 lighthouse black holes.** The circular holes in the cape were dark instanced bush spheres intersecting the plateau; ink filled each one into a black cave. West-cape bushes are no longer planted. Cape shear toes are floored at 1.2 m (no below-water notches). The recaptured 05 plateau and cliff face are continuous limestone, with the arch window as the only intentional opening.

6. **04 fields.** Closer-scale grass triplanar, higher-frequency colour mottling, faint terrace lines, and ochre/sage patches so the remaining meadows are not a single flat green. Crop rows from iterate 14 still show on the mid-island slopes.

Automated check: 2000 random land positions at 30–80 m AGL, low-res (320×180) capture of the centre crop, flag if the camera is inside the mesh after clearance or if >12% of the crop is pure black / average luminance < 18. Result: **2000 / 2000 clean, 0 inside, 0 blackish.** Each of the 10 survey tiles was re-captured at 1920×1080 with the plane parked far away and the camera logged in the same evaluate as the render, then inspected individually (not only the contact sheet).

Draws stay under 150 (aa-draws titleN 128, heroN 137; +1 for the new `landmarks-merged-road` bucket; medium triangles ~1.87M). Swiftshader frameMs/fps is not a phone number — compare draws/triangles, not that fps.

M1–M5 QA (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390): 10/10 pass, English HUD, chase ~26–42 m, 3 stars each, 0 errors. aa-takeoff (keyboard, touch landscape, portrait) unsticks and climbs to ~55 m. aa-menu all pass, 0 console errors. Flight model was not retuned this pass; the camera clearance change is the only feel-facing behaviour change.

Shots of record:
- delivery/shots/hero_day.png, hero_night.png, hero_storm.png, hero_landing.png (unchanged this pass)
- delivery/shots/mission/m1_rings_{pc,mobile}.png, m2_mail_*, m3_storm_*, m4_night_*, m5_rescue_*
- delivery/shots/low_flight_survey.png and delivery/shots/low/low_01–10_*.png (new)

Honest remaining gaps:
- The 06 castle is a relatively simple stone keep; a large cumulus sits right behind it in that plate.
- The 07 volcano crater is often hidden by a large cloud on the approach; the cone itself now reads as rock, not an interior slab.
- One village house in 10 still sits tight on the water’s edge (on the bank, not floating).
- The waterfall is still pixelated / easy to miss (08, 10).
- The steamer is still a bit blocky.
- Night runway glows remain small on purpose and are easy to miss at the m4 review distance.
- The hero postcard village is still a bit thinner than the old dense cluster (intentional from iterate 14).
- The m3 current beacon is still hidden at the review camera distance; the HUD chip carries the target.
- Rescue wreck is still small at start; gold rings carry the target.
- A pale concrete road/apron ribbon is now visible near the hangar and town — correct, not a black slab, but it is a new read.
- Distant trees are a little less punchy after the emissive cut (so they no longer float as a green cloud).
- Mail sparkle, landing skids and boost shake are felt in play more than in stills.
- The Courrier in the hero is still a hair right of exact centre.

Backup: aeropostale_air_art_iter15_lowflight_eyesores.zip (store ascii_air_backup/). Weekly usage was 60% at the start of this turn; no live weekly meter on this box. Ceiling is ~78%.


## Art pass iterate 16 — landmarks, life, standout missions, cameras (27 Nov 2026, 05:20 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **4f49e1b** on main (after ascii-air 8873fd6). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-15 “clean but empty” low-flight island:

1. **Landmark close range.** The castle is a courtyard fortress: thinner curtain walls, crenellations, three round towers with conical terracotta roofs (and flag poles). The waterfall sheets use a scrolling band shader, a pulsing white foam pool, and falling mist; the top lip is pale stone instead of a black slab. The steamer is a long liner with deck rails, davit lifeboats, a striped funnel and an instanced smoke trail, and it now slowly cruises the bay (wakes driven into the water shader). The lighthouse has a gallery rail ring and an additive lantern glow; the beam still sweeps. Mill sails are wider, red/black striped, and still turn with the wind (merged so they stay cheap). The church has a door and rose window.

2. **Life (instanced, QUALITY.life 0.35 / 0.8 / 1).** Coastal seagulls replace the old high black V-flock (closer, cream, one mesh). Village and farm chimneys emit looping smoke. Cars run the airport–town–harbour road; four train cars share that same instanced mesh on the viaduct deck. People dots sit on beach, quay and pier (culled off water). Flags flutter on the castle and harbour. Boats translate on ovals and write `uBoat0–3` so the water shows wakes. Performance / low quality cuts counts or hides rows.

3. **Ground richness.** Instanced rock scatter, flower patches, field stone walls, vineyard rows on a mid-island shelf, and beach umbrellas (cloth + poles). Farms and hedges from iterate 14 remain.

4. **Gameplay (64 → 69 missions).** Beginner QA missions (rings-b1, mail-b1, storm-b1, night-b1, res-b1) are unchanged. New standouts, each with a clear objective HUD and ★3/★2/★1 times:
   - rings-p5 **Viaduct Crawl** — rings actually thread the stone arches (rings-p2 / rings-a2 / res-p3 were also retuned so they go under the viaduct).
   - rings-p6 **Rival Run** — a navy Courrier ghost runs the course; HUD “RIVAL −/+ time”; 3 stars means beat the rival and the ★3 time.
   - mail-p5 **Ship Drop** — pick up at the hangar, drop onto the *moving* steamer.
   - storm-p4 **Gale Rescue** — storm weather, flare ring around the wreck, mark then raft.
   - night-p4 **Night Flare Rescue** — the same aid pattern at night with flares.
   Star totals update automatically. A short cinematic intro (side-rear ease into chase, still ~26–42 m behind) plays at mission start; a 2.4 s orbit plays on a successful finish before the result sheet (the sheet is skipped if a new mission has already started).

5. **Draw budget.** Mill blade stripes and steamer/waterfall foam were merged or instanced so the new life layer fits the cap. aa-draws: titleN **130**, heroN **139**, calls 136, triangles ~1.88M (medium). Under 150, with headroom for mobile.

QA: M1–M5 (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390) 10/10 pass, English HUD, chase ~26–42 m, 3 stars each. New missions (rings-p5, rings-p6, mail-p5, storm-p4, night-p4 × PC + mobile) 10/10 start + complete, 0 errors. aa-takeoff (keyboard, touch landscape, portrait) unsticks and climbs to ~55 m. aa-menu all pass, 0 console errors. Flight model was not retuned this pass.

Shots of record:
- delivery/shots/landmarks/01_castle.png, 02_waterfall.png, 03_steamer.png, 04_lighthouse.png, 05_mills.png, 06_church.png
- delivery/shots/life/01_beach.png, 02_village.png, 03_viaduct_train.png, 04_fields.png
- delivery/shots/mission/m1–m5_{pc,mobile}.png (re-QA starts)
- delivery/shots/mission/m_viaduct_*, m_rival_*, m_shipdrop_*, m_shipdrop_mid_pc.png, m_galerescue_*, m_nightflare_*

Honest remaining gaps:
- Castle flags flutter in play but are easy to miss in the close-up (and a first-flight hint can sit over a free-flight still).
- Waterfall scrolling is readable but still a bit blocky / “sheet + square mist,” not silky water; the foam pool is modest.
- The rival plane is navy and larger, but in the start still it can hide just ahead of the player against the runway; the HUD delta carries the race.
- Seagulls, people dots and umbrellas are small in stills; cars, the viaduct train, steamer rails and chimney-adjacent village life read more clearly.
- Vineyard rows exist on the mid-island shelf; some field close-ups are still dominated by trees rather than walls/flowers.
- Night / storm flare poles are small by design; the gold ring carries the target at start.
- The Courrier in the hero is still a hair right of exact centre.
- Intro / complete cameras are short on purpose so they do not break the chase-follow QA band.

Backup: aeropostale_air_art_iter16_landmarks_life.zip (store ascii_air_backup/). Weekly usage **61.8%** at report time (was 60.9% at the start of this brief); resets Thursday 3 Dec 2026, 10:18 Europe/Paris CET. Ceiling remains ~78%. Shared with other apps on the Super plan; no extra usage credits left once the weekly cap is hit.


## Art pass iterate 17 — waterfall, exposure, hills, rival, beauty plates (27 Nov 2026, 05:48 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **ea861c4** on main (after ascii-air 4f49e1b). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-16 landmarks/life review:

1. **Waterfall (Mistfall) rebuilt as a cliff-face fall.** The square-particle mist is gone. A grey limestone ledge and irregular cliff sit on the hill; a smooth vertical blue–white gradient ribbon scrolls with soft streaks (no barcode bands, no square particles). Soft round instanced foam puffs sit at the plunge, with a pool and a stream ribbon following the river carve toward the sea. Greenery (bushes and flank pines) sits on the lip and base. The mound itself is now grass, not a bare brown cone. The limestone mesh is still a little blocky compared with a carved cliff, but it no longer reads as a white confetti glitch.

2. **Exposure / bloom / haze.** Live bloom dropped (0.48 → 0.26, off when quality bloom is disabled). Bloom extract threshold 0.62 → 0.80, compose strength 0.72 → 0.36. A soft-knee highlight compress in ligneClaire stops luma ≳ 0.78 from blowing out. Exposure is 1.08, and dips further when the lens looks into the sun. Day fog is cooler and thinner (near 2800, far 6400). Lighthouse and hero skies now read as blue, not a hazy cream blow-out.

3. **Castle.** Darker grey limestone (not flat beige), with a recessed dark arched gate on the south wall. Ink already caught the stone. Tutorial `#hud-hint` plates moved lower-left (above the gauges) so they no longer sit over a landmark; they are hidden in beauty stills. Close and beauty plates are taken from the south-east mid-slope, below the volcano cloud deck (earlier close-ups had the camera inside a cumulus).

4. **Hills.** Mid-volcano and inland moderate slopes are grass/scrub with ochre patches and scattered rock outcrops. Only the steep upper cone, coastal cliffs, and outcrops stay rock. Inland rock tint is greyer limestone, not khaki mud. The waterfall hill is forced to grass so the limestone is the mesh, not a mud cone.

5. **Ink.** Foliage gets a lower colour-edge threshold so trees pick up comic silhouettes. Terrain colour edges only fire on material breaks / modest depth jumps (no receding-slope black fill, no open-water stripes). Buildings already had ink.

6. **Rival.** Léo's Courrier is chrome-yellow with navy wings and a “LÉO” name tag. It starts 16 m beside the player at t=0 (over the runway), then joins the ring path. HUD “RIVAL −/+” is unchanged.

7. **Hero Courrier.** HERO_VIEW shiftX 0.13 → 0.19, side 18 → 15.2, plane.x 40 → 24, so the machine sits closer to lower-centre.

8. **Beauty plates.** Six chase-cam stills with the plane in frame, over the castle, waterfall, steamer, lighthouse, mills and village, plus a labelled 2×3 contact sheet for morning review. HUD, hint and title are hidden; demo rings are now cleared on `startFreeFlight` (they previously leaked from the hero showcase).

Draws stay under 150: titleN **128**, heroN **137**, titleCalls 134, heroCalls 143, triangles ~1.98M (medium). Stream/pool merge recovered the earlier overrun.

QA: M1–M5 (rings-b1, mail-b1, storm-b1, night-b1, res-b1 × PC 1920×1080 + mobile 844×390) 10/10 pass, English HUD, chase ~26–42 m, 3 stars each, 0 errors. New missions (rings-p5, rings-p6, mail-p5, storm-p4, night-p4 × PC + mobile) 10/10 start + complete, 0 errors. aa-takeoff (keyboard, touch landscape, portrait) unsticks and climbs to ~55 m. aa-menu all pass, 0 console errors. Flight model was not retuned this pass. The steamer cruise ellipse was tightened so the liner stays in the bay; Rival Run's start moved from the west cape to over the runway so the formation is visible.

Shots of record:
- delivery/shots/beauty/01_castle.png, 02_waterfall.png, 03_steamer.png, 04_lighthouse.png, 05_mills.png, 06_village.png
- delivery/shots/beauty/sheet_2x3.png (morning review sheet)
- delivery/shots/landmarks/01_castle.png, 02_waterfall.png, 03_steamer.png, 04_lighthouse.png, 05_mills.png, 06_church.png
- delivery/shots/heroes/hero_day.png
- delivery/shots/mission/m_rival_start_pc.png (formation: red Courrier and Léo side-by-side)

Honest remaining gaps:
- The waterfall limestone is still a somewhat rectangular cliff slot rather than a fully carved rock face; foam is modest; the stream is a faceted ribbon, not a continuous carved river surface.
- The castle gate is on the south wall and is easy to miss from the south-east beauty/close plates; flags are still small.
- Coastal headland and cape slopes remain khaki rock on purpose (coastal cliffs); some inland outcrops still read brown where the rock atlas tints the vertex colour.
- Tree ink is improved but not as consistent as building ink; far canopies are still simple spheres/cones.
- The lighthouse beauty/close still includes the pale sun beam wedge (clamped, not a white blow-out). The sea-arch block beside it is still a simplified limestone mass.
- The steamer can still look slabby in some angles; the cruise was tightened but can graze shallows if the ellipse is pushed.
- The hero Courrier is much closer to centre but may still sit a hair right depending on the crop.
- Clouds around the volcano can still swallow a close camera at ridge height; beauty plates were framed below that deck.
- Village beauty is dominated a little by the control tower in the foreground.
- Rival name tag is a sprite (always camera-facing); it can sit large at close range.

Backup: aeropostale_air_art_iter17_waterfall_beauty.zip (store ascii_air_backup/). Weekly usage **62.4%** at report time (was 61.8% at the start of this brief); resets Thursday 3 Dec 2026, 10:18 Europe/Paris CET. Ceiling remains ~78%. Shared with other apps on the Super plan; no extra usage credits left once the weekly cap is hit.


## Art pass iterate 18 — scale, sky stripe, waterfall, flight feel (27 Nov 2026, 06:04 Europe/Paris CET)

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **ce7fec8** on main (after ascii-air ea861c4). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

What changed vs the iterate-17 beauty sheet:

1. **Pale sky stripe.** The lighthouse “god-ray” was a 220 m cone, scaled to ~500 m, drawn at 0.42 opacity in daylight. It is hidden unless night > 0.28; the night beam still sweeps. The sky already has a subtle sun disc (slightly larger, no shaft).

2. **Scale rebalance** (plane wingspan remains ~10 m; village houses ~8 m):
   - Church spire 2.05× (~92 m) → 0.78× (~35 m, near the ~30 m target).
   - Control tower 1.65× (~50 m) → 0.85× (~26 m).
   - Lighthouse 2.2× (~110 m) → 1.10× (~54 m).
   - Mills 1.95× → 1.22× (~23 m).
   - Hangar 1.55× → 0.95×.
   - Viaduct 3.4/2.8/2.6 → 2.15/1.90/2.05, with end pylons and pilasters so a side-on view is not a flat beige slab. Viaduct Crawl rings still thread the arches (deck ~52 m, arch top ~44 m).
   - Castle 2.05× → 3.35×, gate rotated to face the airport (south). It now reads as a fortress on the volcano hillside from the runway / hero / beauty plates.

3. **Waterfall slot.** The rectangular door-in-a-wall is a jagged limestone extrusion with an irregular chute, broken lip stones and side buttresses. Ribbon, foam, pool and stream remain.

4. **Steamer.** Tapered bow and stern, portholes along the hull, so it reads less as a black box. Still a stylised liner.

5. **Rival tag.** Default scale cut roughly in half; the sprite now shrinks with camera distance and hides inside ~14 m, so it no longer fills the frame up close.

6. **Flight feel.**
   - Throttle lever (W/S, Shift/Ctrl, and the touch slider) now moves at 2.4/s (0→1 in ~0.4 s) — still a lever, not a switch. Takeoff QA still unsticks cleanly.
   - Banking has more inertia (turn damp 2.8, roll damp 3.5, max bank 52°) so a roll-in feels weighty rather than twitchy.
   - Speed lines start around 34 m/s and are a bit more visible at boost; wind audio already scales with speed.
   - Boost holds a gentle camera shake (0.28, slower decay) for the whole press, not a one-frame bump.
   - Landing: larger dust burst, a more readable bounce on a firm touchdown (0.32 of vDown), and a short camera bump with the existing touchdown sound.

Draws stay under 150: titleN **127**, heroN **136**, titleCalls 132, heroCalls 141, triangles ~1.99M (medium).

QA: M1–M5 10/10 PC+mobile, new missions (Viaduct Crawl, Rival Run, Ship Drop, Gale Rescue, Night Flare Rescue) 10/10 PC+mobile, aa-takeoff and aa-menu all pass, 0 errors.

Shots of record:
- delivery/shots/beauty/01_castle.png … 06_village.png
- delivery/shots/beauty/sheet_2x3.png (morning review)
- delivery/shots/feel/01_speed_lines.png, 02_boost.png, 03_landing.png
- delivery/shots/feel/sheet_feel.png
- delivery/shots/landmarks/01_castle.png … 06_church.png
- delivery/shots/heroes/hero_day.png

Honest remaining gaps:
- The waterfall chute is still a stylised slot in carved stone, not a fully eroded cliff; foam and the stream remain modest.
- The steamer hull is improved but can still look boxy from abeam; portholes are small in long shots.
- Boost shake is felt more than it shows in a still; the feel sheet’s boost plate is a high-speed flyby with faint lines.
- Landing dust is a short puff and is easy to miss in a wide still (clearer in play).
- The viaduct end-on can still read a little blocky, though it now has piers and is no longer a screen-filling slab.
- The sea arch remains a simplified limestone mass. Coastal cape rock is still khaki by design.
- Tree canopies are still simple spheres/cones. Castle flags are small at range.
- The hero Courrier may still sit a hair right of exact centre.

Backup: aeropostale_air_art_iter18_scale_feel.zip (store ascii_air_backup/). Weekly usage **62.8%** at report time (was 62.4% at the start of this brief); resets Thursday 3 Dec 2026, 10:18 Europe/Paris CET. Ceiling remains ~78%. Shared with other apps on the Super plan; no extra usage credits left once the weekly cap is hit.


---

## Iterate 19 — mid-distance cumulus, coastal sea, liner steamer, clustered trees (27 Nov 2026, 06:30 Europe/Paris CET)

Scale from iterate 18 held. This pass filled the empty skies, lightened the steamer, and tightened the ligne-claire read of sea, trees, HUD and the sea arch.

What changed:
1. **Sky.** Mid-distance cumulus banks sit in the upper half of downward chase/hero frames (offset from the castle, volcano and waterfall). The sky shader now has a softer pale horizon haze before it climbs into the zenith blue. Clouds no longer have to be hidden for the castle plate; one bank can still graze the castle's right wall in the close beauty angle.
2. **Sea.** An island-ellipse depth model gives turquoise shallows (and lagoons) and deeper navy offshore, plus irregular ink strokes, sparkle glints, and a tighter white foam line at the shore. The previous foreground crush that flattened the bay into a single navy sheet is gone.
3. **Steamer.** Navy lower hull, white topsides, red waterline, white superstructure, two buff funnels with red bands. Black is only a thin cap ring and ink — it no longer reads as a black slab from the chase cam.
4. **Speed lines.** Thin white streaks with a faint ink edge, confined to the screen edges, stronger on boost (`uBoost`). Visible in stills without filling the mid-frame or costing extra draws.
5. **Trees.** Broadleaf canopies are 3–4 clustered, slightly flattened blobs with colour variation and brown trunks; conifers are stacked cones (skinny cypress scale on some). Pine lower-cones are no longer painted as wood. Mid-distance canopies still read a little round/faceted.
6. **HUD.** The top-left title panel is compact (no “v1.0” banner) and auto-hides after 4.5 s of free flight. Missions keep the smaller panel.
7. **Sea arch.** Jagged limestone silhouette, an irregular opening (not a clean ellipse in a beige slab), grey stone, rocky toes, vegetation on the crown. From abeam it is still a faceted extruded mass.

Draws stay under 150: titleN **127**, heroN **136**, titleCalls 132, heroCalls 141, triangles ~4.61M (medium; tree prototypes are heavier, call count unchanged).

QA: M1–M5 10/10 PC+mobile, new missions (Viaduct Crawl, Rival Run, Ship Drop, Gale Rescue, Night Flare Rescue) 10/10 PC+mobile, aa-takeoff keyboard + touch landscape/portrait all pass, 0 errors.

Shots of record:
- delivery/shots/beauty/01_castle.png … 06_village.png
- delivery/shots/beauty/sheet_2x3.png (morning review)
- delivery/shots/feel/01_speed_lines.png, 02_boost.png, 03_landing.png
- delivery/shots/feel/sheet_feel.png
- delivery/shots/compare/master_vs_hero.png (side-by-side vs refs/user_target_master_v2.png)
- delivery/shots/landmarks/01_castle.png … 08_trees.png (incl. 07_arch, 03_steamer)
- delivery/shots/heroes/hero_day.png

Honest remaining gaps:
- The white shore foam line is still modest in wide shots; the master’s painted sparkle/foam is richer.
- Open-water depth banding is clearer in the bay than as a dramatic turquoise-to-navy sheet from every camera.
- The close castle beauty can still catch a cloud against the right-hand wall.
- Mid-distance broadleafs remain fairly round; a few grove bushes overlap tree trunks.
- The sea arch opening reads in south/hero views, but the side elevation is still blocky.
- Landing dust is a short puff and is easy to miss in the wide still (the plane is on the runway; clearer in play).
- Cape rock is still khaki; the hero postcard keeps a barren right-hand cape and a yellow sandbar the master does not have.
- The hero Courrier may still sit a hair right of exact centre.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **8160082** on main (after ascii-air ce7fec8). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

Backup: aeropostale_air_art_iter19_sky_sea_trees.zip (store ascii_air_backup/). Weekly usage **63.3%** at report time (was 62.8% at the start of this brief); resets Thursday 3 Dec 2026, 10:18 Europe/Paris CET. Ceiling remains ~78%. Shared with other apps on the Super plan; no extra usage credits left once the weekly cap is hit.

---

## Iterate 20 — tree LOD, postcard camera, white clouds, cream cape, volcano plume (27 Nov 2026, 06:54 Europe/Paris CET)

Harsh review of `compare/master_vs_hero.png` plus the beauty sheet: medium had jumped to ~4.6M triangles; the hero was a low camera over a beige sandbar; clouds had gone grey and low; cape rock was still khaki.

What changed:
1. **Perf / tree LOD (hard requirement).** Clustered tree prototypes now have a near mesh and a far impostor (low-poly spheres/cones, bush is one squat sphere). `tickLod` buckets instances by camera distance (near radius 70 / 100 / 130 m on low / medium / high; bushes 0.75×) and refreshes on hero snap. First-visit mobile auto quality is **low** (Performance), not medium. Medium fell from ~4.61M to **~1.06M** triangles.

   Per-tier, Swiftshader, after flora.refresh (fps/frameMs are not a phone number — compare triangles and draws):

   | Tier | Title tris | Hero tris | Title calls | Hero calls | Cap |
   |---|---:|---:|---:|---:|---|
   | low (Performance / mobile) | 565,736 | 571,676 | 120 | 136 | ≤1.5M |
   | medium | 1,052,432 | 1,058,372 | 124 | 140 | ≤2.5M |
   | high | 1,214,012 | 1,219,952 | 124 | 140 | (no cap asked) |

   All under the caps and under 150 draw calls.

2. **Hero / title postcard.** Raised 3/4 camera (`HERO_VIEW.cam` at (18, 176, −1548) looking at (20, 46, −780)); the Courrier is large in the lower centre, banked toward the rings, over the bay rather than a right-hand sandbar. The volcano sits centre-back with a readable cream smoke plume (opaque puffs — the id-alpha pass was wiping transparent smoke). The steamer is parked in the visible bay. Title uses the same elevated rig with a slight orbit.

3. **Clouds.** Fewer, higher banks (y 340–460). Bright white with a soft cream emissive and a light blue-grey ink shell; more blue sky at the top of the frame.

4. **Cape / headland.** Coastal rock shifted to warm limestone cream; grass/scrub on the flatter tops. The east headland footprint is tighter. Close lighthouse plates can still show a tan seaward slope.

QA: M1–M5 10/10 PC+mobile, new missions (Viaduct Crawl, Rival Run, Ship Drop, Gale Rescue, Night Flare Rescue) 10/10 PC+mobile, 0 page errors.

Shots of record:
- delivery/shots/heroes/hero_day.png
- delivery/shots/title/title_day.png
- delivery/shots/beauty/01_castle.png … 06_village.png
- delivery/shots/beauty/sheet_2x3.png
- delivery/shots/compare/master_vs_hero.png (side-by-side vs refs/user_target_master_v2.png)

Honest remaining gaps:
- The postcard is an elevated 3/4 over the island, but the master’s bay still fills more of the lower frame; we still show more mid-island yellow-green field and a leftover tan apron / sandbar in the lower mid.
- The Courrier is large and lower-centre, but smaller than the master’s painted biplane and a hair right of exact centre. The title orbit shrinks it further than the hero still.
- Gold rings still bunch over the viaduct rather than reading as a big hoop in the open bay.
- The sea arch is still a faceted stacked mass, not the master’s ochre windowed cape.
- Cape rock is warmer and greener on top, but some seaward faces (and the lighthouse beauty plate) still read sandy-tan rather than hatched limestone cliffs.
- Far trees are intentionally low-poly impostors; mid-distance canopies remain fairly round.
- Village / airport on the left shore are readable but thinner and more spread than the master’s tight painted town.
- The plume reads as a short white column on the near face of the cone; it is not yet a long painted trail drifting off the peak.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **82bf614** on main (after ascii-air 8160082). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

Backup: aeropostale_air_art_iter20_lod_postcard_plume.zip (store ascii_air_backup/). Weekly usage **64.0%** at report time (was 63.3% at the start of this brief); resets Thursday 3 Dec 2026, 10:18 Europe/Paris CET. Ceiling remains ~78%. Shared with other apps on the Super plan; no extra usage credits left once the weekly cap is hit.

---

## Iterate 21 — near-horizon bay postcard, ochre volcano, cobalt water (27 Nov 2026, 07:10 Europe/Paris CET)

Iterate 20's elevated map-like aerial was a step back from the master. This pass treats the master as a literal layout guide: camera just behind the Courrier, looking across the bay at near-horizon eye level. Tree LOD tiers from iterate 20 are unchanged.

What changed:
1. **Hero / title composition.** Camera is ~26 m behind and 7 m above the Courrier (in the 25–40 m brief), locked with dist/height/side rather than a world-space `cam`. Wingspan reads **~36%** of frame width (target 35–40%). The plane sits large in the lower centre, slightly banked, over open water. The far shore is a band in the upper-middle; the sky takes the top ~30%. Layout left-to-right: airport / village / mills, volcano centre-back, waterfall and castle, lighthouse cape on the right, steamer and sailboats in the bay. A long sand apron south of the west cape was sunk so the foreground is water, not a beige shelf. Title uses the same rig with a tight orbit (±3 m).
2. **Volcano.** The cone is brown / red-ochre rock with a dark crater rim; only the lower slopes stay green (the snow cap is gone). A long opaque puff column drifts west (image-right) with the wind.
3. **Water.** Mid-bay is saturated cobalt; turquoise is limited to a tight ~80 m shore band. Grazing fresnel no longer mixes in a pale sky wash (that was why the previous postcard bay looked grey).
4. **Rings.** Three gold rings step across the bay toward the castle — a large hoop, then two smaller receding ones — instead of a nested bunch over the viaduct.
5. **Village.** The runway exclusion was too wide and was eating the first street bands. Houses now start closer to the airport, with tighter plots and more hillside impostors.

Per-tier, Swiftshader, after flora.refresh (fps/frameMs are not a phone number — compare triangles and draws):

| Tier | Title tris | Hero tris | Title calls | Hero calls | Cap |
|---|---:|---:|---:|---:|---|
| low (Performance / mobile) | 563,394 | 569,164 | 123 | 136 | ≤1.5M |
| medium | 1,042,042 | 1,047,812 | 127 | 140 | ≤2.5M |
| high | 1,200,902 | 1,206,672 | 127 | 140 | (no cap asked) |

All under the caps and under 150 draw calls. LOD tiers from iterate 20 held.

QA: M1–M5 10/10 PC+mobile, new missions (Viaduct Crawl, Rival Run, Ship Drop, Gale Rescue, Night Flare Rescue) 10/10 PC+mobile, 0 page errors.

Shots of record:
- delivery/shots/heroes/hero_day.png
- delivery/shots/title/title_day.png
- delivery/shots/beauty/01_castle.png … 06_village.png
- delivery/shots/beauty/sheet_2x3.png
- delivery/shots/compare/master_vs_hero.png (side-by-side vs refs/user_target_master_v2.png)

Honest remaining gaps:
- The Courrier is the right scale and placement, but it is still a 3D mesh rather than the master's painted 35% biplane, and it sits a hair right of exact centre.
- Mid-bay water is richer cobalt-turquoise than iterate 20, but it is still a slightly more cyan, flatter sheet than the master's painterly deep blue, with less foam and sparkle.
- The sea arch is only a sliver on the far right of the postcard; it is not the master's ochre windowed cape.
- The hangar, tower and mills are readable on the left but smaller and less "town-like" than the painted shore. Village density is improved, still more regular and toy-like than the plate.
- The gold rings now recede, but they are smaller and further than the master's big central hoop.
- The plume is a long stacked column that drifts right; it is not yet a soft painted trail. The dark crater rim is hard to read at postcard distance.
- The right headland is still a simpler tan/cream mass than the master's hatched limestone cliffs.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **d06c9eb** on main (after 82bf614). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

Backup: aeropostale_air_art_iter21_bay_postcard.zip (store ascii_air_backup/). Weekly usage **64.3%** at report time (was 64.0% at the start of this brief); resets Thursday 3 Dec 2026, 10:18 Europe/Paris CET. Ceiling remains ~78%. Shared with other apps on the Super plan; no extra usage credits left once the weekly cap is hit.


---

## Painted-sky presentation pass (27 Nov 2026, Europe/Paris CET)

Full graphics / UI / world pass inspired by 1980s hand-painted animation landscapes (internal style guide only: `refs/ghibli/STYLE_GUIDE.md`). No studio names, characters, logos, or copied assets in the shipped game. Showpiece landmark is named **The Hanging Keep**.

### What landed
- Art: richer blue zenith with a thin warm-gold horizon, towering cumulus with sunlit tops and soft blue undersides, lusher greens, warmer daylight, closer blue depth haze, thinner optional outlines (0.42, 0.85 in high-contrast).
- Open world: instanced near-camera grass/flowers with LOD, lived-in yards (laundry, gardens), two more farms, extra roads to the mills, farm, and cape, and The Hanging Keep (terraced stone mesa, ruined keep, rim trees, falling water) east of Mount Glyph.
- Free ride: mid-runway spawn (x=8, z=−1100), heading south over the bay (−π/2), snapped clear of terrain, gentle airborne start (~21 m AGL, 34 units airspeed). No clipping.
- Pause: Resume / Restart / Settings / Quit. Works with click, tap, and keyboard (↑↓ / Enter / Esc via the existing pause pulse). No overlap on PC (1920×1080) or mobile landscape (844×390). Touch controls hide while the menu is open.
- UI: airy cream glass HUD and title plaque, softer shadows, safe-area padding, balloon hidden on short landscape so it no longer clips.

### Perf (headless SwiftShader; fps here is not a phone number)

| Tier | Title tris | Hero tris | Free tris | Title calls | Hero calls | Caps |
|---|---:|---:|---:|---:|---:|---|
| low (Performance / mobile) | 588,332 | 594,092 | 532,864 | 130 | 142 | ≤1.5M tris, ≤150 draws |
| medium | 1,061,470 | 1,067,230 | 1,049,126 | 134 | 146 | ≤2.5M tris, ≤150 draws |
| high | 1,219,786 | 1,225,546 | 1,211,286 | 134 | 146 | ≤150 draws |

All tiers under caps. Draw budget is tight on the hero (146 / 150).

### Shots
- delivery/shots/compare/before_after.png
- delivery/shots/compare/master_vs_hero.png
- delivery/shots/heroes/hero_day.png
- delivery/shots/title/title_day.png, title_mobile.png
- delivery/shots/pause/pause_pc.png, pause_mobile.png
- delivery/shots/freeride/start_pc.png
- delivery/shots/beauty/01_keep.png … 06_waterfall.png
- delivery/shots/beauty/sheet_2x3.png
- delivery/shots/ui/presentation_sheet.png

### Honest gaps
- The Hanging Keep reads as a floating mesa with trees and a ruin, but the waterfalls are thin from most angles and the underside is still a faceted stone bowl, not a painterly crag.
- Mid-bay water is still a slightly cyan, flatter sheet than a painted deep blue.
- Heavy comic ink is softened, not gone; some props (plane, steamer, trees) still carry a BD edge.
- Cumulus are improved (stacked, lit tops) but remain instanced sphere clusters, not soft wet-into-wet volumes. Plume is still stacked puffs.
- Village yards (laundry, gardens) are there but small at postcard distance; streets are still quite regular.
- Free-ride start faces open sky over the bay, but large faceted west-cape / cliff volumes sit in the lower-left of the first view.
- Grass/flowers are dense only near the camera (by design, for the cap). Mobile smoothness is reserved by the low tier; this box cannot quote a real-phone fps.
- Mission playthrough QA from the superseded iterate-22 brief was not re-run as a full player pass this round; boot, title, free-ride, pause (PC + 844×390), and hero/beauty captures had 0 page errors.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **abe602f** on main (after d06c9eb / Relic cf951a0). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

---

## 27 Nov 2026, ~08:15 Europe/Paris CET — LOD, bug sweep, life, feel

Continued from the harsh-review working tree (not yet on Pages; live was still `abe602f`). Did not stop at that wrap.

### Popping / LOD
- Tree `tickLod` now uses hysteresis (medium: enter near at 118 m, leave at 177 m) and slightly larger near radii (low 88 / medium 118 / high 155).
- Meadow grass uses stable 3.4 m cells with fade-in/out instead of a full resample every ~8 m.
- Near canopies and grass lean in the wind.
- Note + plates: `delivery/LOD_POPPING.md`, `delivery/shots/lod/lod_before_after.png`.

### Textures / facets
- Merged landmark rock/stone/plaster/roof use smooth Lambert and a slightly larger triplanar scale (less tiling / tint chatter).
- The Hanging Keep is no longer folded into the tiled stone atlas. It is a vertex-color merge with a 28×20 sphere bowl (the old stretched icosahedron was a handful of huge facets).
- Falls were invisible or chalk-white because `mergeGeos` dropped UVs; UVs are preserved and falls are crossed cards hung off the rim, with aqua flow (not a white stick).
- Roads sit 16 cm up with stronger polygon offset. Long vineyard/wall slabs are broken into short height-snapped segments.

### Open-world life
- Sheep and cows wander farm shelves (one instanced mesh). People use capsules. Chimney smoke is opaque (the transparent + mat-id path made puffs vanish). Night lanterns at town, quay, and pier. More gulls share one instanced flock over beach, town, harbor, fields, and the light.
- Dropped life-rocks and life-flowers to stay inside the 150-draw cap.

### Feel
- Silkier stick and bank damping; slightly smoother chase follow (`chaseLag` 3.35). Juicier ring sparks.

### Perf (hero / title / free, SwiftShader — fps is not a phone number)
| Quality | Hero tris | Hero draws | Title draws | Free draws | Caps |
|---|---:|---:|---:|---:|---|
| low | 934,914 | 147 | 135 | 137 | ≤1.5M / 150 |
| medium | 1,767,192 | 150 | 138 | 140 | ≤2.5M / 150 |
| high | 2,078,190 | 150 | 138 | 140 | ≤2.5M / 150 |

Medium hero was ~2.16M / 150 before this pass.

### QA
- M1–M5 PC already passed earlier this morning (start, chase, stars, English HUD).
- Mobile 844×390 M1–M5 was not re-run in this slice (title mobile was recaptured: plaque left, plane on the right, no balloon clip).

### Honest gaps
- Keep body still reads pale in full daylight; falls are readable aqua veils but still card-like.
- Clouds remain stacked, slightly grey volumes.
- Livestock are simple boxes — readable from a low pass, easy to miss in a wide plate.
- Hero is at the 150-draw cap on medium and high.
- Still not a one-to-one “Castle in the Sky” poster, but the keep is a floating island with a smooth bowl, terrace, ruins, tree, pool, falls, and mist, and the free-ride start shows the plane over the south bay.

### Deliverables
- Before/after (vs the reviewed painted-sky `prev_*`): `delivery/shots/compare/before_after.png`
- Beauty: `delivery/shots/beauty/sheet_2x3.png`
- LOD: `delivery/shots/lod/lod_before_after.png`
- Title PC + mobile, free-ride start, hero, farm/mills plate on `delivery/shots/ui/presentation_sheet.png`

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **1fec8f2** on main. Live at wrap start: https://avp86fr-jpg.github.io/preview/ascii-air/

---

## 27 Nov 2026, ~08:35 Europe/Paris CET — official cover key art + 08:10 review wrap

Continued from the reviewed **1fec8f2** working tree (live was still that commit). This is the wrap of the 08:10 harsh priorities plus the 08:12 official-cover addendum. No new iterate after this deploy.

Official source covers (not shipped; stay in `refs/covers/`): `cover_16x9.png` (1672×941), `cover_1x1.png` (1254×1254), `cover_3x4.png` (1086×1448). Compressed derivatives ship in `game/media/`.

### 1. Title layout + official cover as key art
- Loading and title use the official painting as an opaque CSS backdrop (`#title-screen.cover-art`, `#loading.cover-art`) via `image-set` (WebP with JPEG fallback).
- Landscape: `cover-16x9` at 1920 / 1280 / 854. Portrait: `cover-3x4` at 1080 / 720. `og:image` is 1200×630 (`./media/og-image.jpg` + `.webp`). `robots` remains `noindex, nofollow`.
- The in-game wordmark plaque is hidden on the title: typography is already on the painting, and a left plaque would cover the cover’s plane. Buttons sit in a full-width bottom bar with ≥24 px safe insets (short-landscape overrides the old `min(42vw)` left plaque).
- The 1fec8f2 844×390 bug (`'ROPOSTALE AIR'`, clipped buttons) had two causes: a flush-left plaque (~6 CSS px from the left) and the presentation sheet’s center-crop of a 2.16-aspect shot into a 1.78 cell. Presentation compose now uses **contain**, not cover-crop.

Verified unclipped at the four requested sizes (buttons fully on-canvas, wordmark complete):

| Viewport | Shot | Nav / layout |
|---|---|---|
| 1920×1080 | `delivery/shots/title/title_day.png` | Buttons centered, 22 px bottom pad |
| 1280×720 | `delivery/shots/title/title_1280.png` | Buttons centered, 22 px bottom pad |
| 844×390 @2x | `delivery/shots/title/title_mobile.png` | Nav left/right ~136 px, bottom 16 px, `clipped: false` |
| 390×844 @2x | `delivery/shots/title/title_portrait.png` | 24 px sides, 22 px bottom, 3×4 cover |

### 2. Clouds
- Post outline now multiplies silhouettes / color edges by `(1.0 - isSky)` so CLOUD / SKY pixels are not inked.
- Soft real alpha is incompatible with mat-id packed in color-alpha, so clouds use an opaque `ShaderMaterial` (declares `attribute vec3 color`) with warm-lit crowns, lavender-blue undersides, gentle rim dither, and packed `a = 7/255`.
- Fewer mid-layer clouds, larger hero banks (including postcard-visible spots around `z ≈ -620…-800`) and bigger horizon towers.
- Honest gap: the in-game hero sky is still relatively empty compared with the cover’s huge sunlit cumulus. Banks can sit off-frame or get lost in fog/exposure. Soft-edged, but still procedural volumes, not wet-into-wet paint.

### 3. The Hanging Keep
- Rewritten as an earthy mesa: wide crown, keel only in the lower third, limestone-brown + moss, irregular displacement, hanging roots, green terrace, tall ruin arches, dominant tree canopy, aqua crossed-card falls off the rim, mist only at plunges. No wreath / orbiting companion rocks.
- Merged with `mergeVertexColors` (not the triplanar rock atlas). Falls use `makeFallsMat` and keep their UVs.
- Honest gap: close-ups now read as a floating earthy island rather than a pale disc, but the body is still a smooth olive-brown volume; arches are a bit blocky; mist puffs can still look like white balls. Not yet the cover’s stacked arched ruins in a leafy crag.

### 4. Cape / lighthouse / arch
- Sea arch is cream vertex-color Lambert (`flatShading: false`), cream toes, `mergeVertexColors(arch)`, and skipped in the root `"rock"` merge (the triplanar `rock.png` atlas had been turning it brown). Opening and a cypress on top are visible.
- Coastal addon cliffs use cream vertex colors. West-cape `computeMaterial` forces green scrub on gentle tops near the light/arch; coastal ROCK was brightened.
- Honest gap: `04_lighthouse.png` still shows a substantially tan, faceted plateau with only patches of green. Heightfield resolution + lighting; not yet the cover’s cream limestone headland.

### 5. Cover as primary art direction (palette)
- Plane was already cream wings + red fuselage (`PLANES.trainer.color #c01418`, `accent #f4ead0`) — left as-is, matches the cover.
- Roof palette slightly warmer terracotta. Village cream stone + cypresses already present.
- Water: `_deepDay = 0x1578a0`, `_shalDay = 0x3ec8c4` (turquoise, still a flatter sheet than the painted sea).
- Day sky slightly richer (`0x4a96d0` / `0x3e8ece`) and warmer fog.

### Game vs official cover
Sheet: `delivery/shots/compare/game_vs_cover.png` (official 16×9 vs in-game hero; cover floating-island crop vs The Hanging Keep).

**Already in the same family:** cream-wing / red-fuselage biplane; terracotta roofs and cream-stone cliff village with cypresses; turquoise bay; a floating island with trees, ruin arches, and waterfalls; a red-and-white lighthouse on a headland.

**Still short of the painting:** the cover is a warm painterly sky packed with huge sunlit cumulus; the hero plate is a clearer, flatter blue with almost no near-camera towers. The cover island is a leafy crag of stacked arched ruins and braided falls; the in-game keep is a smoother mesa with a single canopy and thinner card falls. The cover headland is cream limestone with a tight terracotta village; the in-game cape is still tan and faceted. The game remains a ligne-claire 3D world, not a still painting — the title screen now carries the painting, the world does not yet match it.

### 6. Draw budget
Target was ~135 draws. Title and free-ride are there; the hero is still tight.

| Quality | Hero tris | Hero draws | Title draws | Free draws | Caps |
|---|---:|---:|---:|---:|---|
| low | 929,256 | 143 | 131 | 133 | ≤1.5M / 150 |
| medium | 1,758,748 | 146 | 134 | 136 | ≤2.5M / 150 |
| high | 2,069,296 | 146 | 134 | 136 | ≤2.5M / 150 |

All tiers under caps (SwiftShader fps ~20 is not a phone number). Headroom work this wrap: laundry lines+beds (−2), keep wreath/rocks (−2), then +2 when falls reverted to three meshes. Did not reach ~135 on the hero (146).

### QA
- M1–M5 on PC 1920×1080 and mobile 844×390: all five missions started, chase followed at start and mid, completed with stars, English HUD. **failed: 0, errors: 0.**
- Title/loading boot at 1280×720 had no page errors; title class `cover-art`.

### Deliverables
- Beauty: `delivery/shots/beauty/sheet_2x3.png`
- Presentation (contain, not cropped): `delivery/shots/ui/presentation_sheet.png`
- Game vs cover: `delivery/shots/compare/game_vs_cover.png`
- Titles at all four sizes under `delivery/shots/title/`
- Hero: `delivery/shots/heroes/hero_day.png`

### Usage
Last user figure at the 08:10 brief: weekly **68.4%** (all three games running). This wrap was allowed up to ~73%, then stop. No further iterate after this deploy.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **1c8a663** on main (after 1fec8f2). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

---

## 27 Nov 2026, ~09:15 Europe/Paris CET — cover-target décor wrap

Continued from **1c8a663**. Official covers remain the primary art-direction target. This is the wrap of the 08:38 brief (weekly 69.8%, ceiling ~74%). No further iterate after this deploy.

### 1. The Hanging Keep
Rebuilt as a two-tier floating crag, not a smooth olive mesa: jagged grey-brown rock undersides with hanging roots and vines, lush green crowns, a tall ruined colonnade/aqueduct (arches now read in close-up), waterfalls from the upper rim onto the lower terrace and from the lower rim into flattened mist. Falls are one merged mesh. Visible in `beauty/01_keep.png` and `_above`.

Honest gap: the colonnade still has a boxy cream back wall; the two tiers are slightly gapped rather than a single leafy crag; falls remain card veils; mist puffs are still simple ellipsoids. Not yet the cover’s stacked arched ruins in a painterly cliff.

### 2. Cliffs / lighthouse cape
- Heightfield crown flattened and forced greener; south face drop tightened; visual normals use a wider, averaged stencil; medium/high terrainN 256→288.
- New west-cape cream-grey limestone cliff mesh (arch window left open), merged with the east coastal cliffs.
- Terraced cream-stone / terracotta village and cypresses on the west headland, folded into `mergeStatic` (no extra draws). Small single stone arch on the lower cape (not the inland viaduct).
- Painterly grass/rock atlases (seamless, no ink outlines) and two-scale triplanar; coastal rock tints toward cream.

Honest gap: the SE approach in `04_lighthouse.png` is still a tan, faceted slope in front of the greener crown and village. The heightfield cannot make a truly vertical limestone wall at 11–10 m cell size; the addon cliff helps the seaward lip only.

### 3. Sky
- Custom cloud ShaderMaterial ignored `instanceMatrix`, so every hero bank was invisible. Clouds now use instancing-safe Lambert (vertex colors, warm emissive). Outline skip for CLOUD is unchanged.
- Framing cumulus sit over the south bay (the only sky still in the downward-pitched hero frame) plus far flank banks. Horizon ranges are elongated blue ridges (plus a repainted backdrop panorama without cartoon bubbles).

Honest gap: banks read as stacked white globes, not wet-into-wet paint; a couple still sit close in the hero corners. Mid-sky is fuller than 1c8a663 but not the cover’s huge painterly towers.

### 4. Textures
New painterly `grass.png` / `rock.png` (256, seamless, no hard outlines). Two-scale triplanar reduces tiling/stretch. Terrain normals smoothed (wider stencil + 3×3 average). Low quality stays at terrainN 192 for mobile memory.

### 5. Draws / caps
Hero draws **134** (target ~135), down from 146. Cuts: hangar-roof ribs merged (−9), keep falls 3→1 (−2), laundry/garden instanced draws dropped (−2); adds: horizon ranges (+1). Cape village/cliffs/arch folded into existing merges.

| Quality | Hero tris | Hero draws | Title draws | Free draws | Caps |
|---|---:|---:|---:|---:|---|
| low | 941,746 | 131 | 119 | 121 | ≤1.5M / 150 |
| medium | 1,811,514 | 134 | 122 | 124 | ≤2.5M / 150 |
| high | 2,124,202 | 134 | 122 | 124 | ≤2.5M / 150 |

All under caps (SwiftShader fps ~20 is not a phone number). Tris rose slightly with terrainN 288 and the new keep/cliffs/ranges; still inside the cap. No LOD popping changes this wrap (hysteresis from 1fec8f2 stands). Mobile memory: low tier unchanged at 192² terrain; new atlases are 256px; no additional render targets.

### Game vs official cover
Sheet: `delivery/shots/compare/game_vs_cover.png`.

**Closer:** two-tier floating island with green tops, rock undersides, ruin arches and stacked falls; cream-stone / terracotta village on the west cape with cypresses; cream sea arch; turquoise bay; cream/red biplane; white cumulus actually in the postcard; blue mountain silhouettes on the horizon.

**Still short:** cover clouds are huge soft painted towers; in-game banks are hard-edged sphere clusters. Cover cape is vertical cream limestone fully terraced to the water; the game still shows a tan faceted apron on the approach. Cover keep is a leafy crag of stacked arches; the game keep’s colonnade is simpler and boxier. The title screen still carries the painting; the world is a ligne-claire 3D read of it.

### QA
M1–M5 on PC 1920×1080 and mobile 844×390: all five started, chase followed, completed with stars, English HUD. **failed: 0, errors: 0.**

### Deliverables
- Beauty: `delivery/shots/beauty/sheet_2x3.png`
- Presentation: `delivery/shots/ui/presentation_sheet.png`
- Game vs cover: `delivery/shots/compare/game_vs_cover.png`
- Hero: `delivery/shots/heroes/hero_day.png`
- Titles unchanged (official cover key art from 1c8a663)

### Usage
Last user figure at the 08:38 brief: weekly **69.8%** (Relic + Long Shot also running). This wrap was allowed up to ~74%, then stop. No further iterate after this deploy.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **5542918** on main (after 1c8a663 / 4d6825a). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

---

## 27 Nov 2026, ~09:50 Europe/Paris CET — painterly-look wrap

Continued from **5542918**. Official cover (`refs/covers/cover_16x9.png`) remains the primary art-direction target. This is the wrap of the 09:24 brief (weekly 72.2% at start, ceiling ~78%). No further iterate after this deploy.

The harsh note on 5542918 was that the world still read as clean low-poly, not painted. This pass leaned on lighting, color, and impostor clouds rather than adding geometry.

### 1. Global painterly look
- **Toon / ramp lighting:** warm key (sun 0xffe6b8) plus a cool bounce fill (hemi ground 0x5a7a98, fill light 0x8aa8c8). Day palettes no longer use a green ground bounce, which had been tinting the island neon.
- **Post:** softer 6-band painterly posterize, mid-green pull toward olive/sage, 3-stop warm/cool ramp, aerial-perspective blue haze with distance, umber outlines at ~0.42 opacity (uOutline 0.26, uSat 1.32→1.08).
- **Fog** tightened (day near 800 / far 3200) and slightly bluer.
- **Textures:** new 512px seamless brush-stroke `grass.png` / `rock.png` (directional dabs, olive/sage/emerald and cream-limestone palettes). Vertex grass colors desaturated (cape, meadow, sage, olive, pine, forest, foliage prototypes).

Honest gap: still a 3D ligne-claire read of a painting, not wet-into-wet oil. Ramp is gentle so water and sky stay smooth; close grass still shows the terrain grid. Paper-grain / brush overlay was not added (would fight mobile fill-rate).

### 2. The Hanging Keep
Moved closer and scaled 2.15× (`(440, 280, −280)`) so it dominates the left of the postcard. Colonnade crowns are jagged ruined silhouettes (no flat boxy back wall); a third broken arcade was added. Waterfall shader is a flowing noise veil with vertex sway and soft edges (still one merged mesh + mist). Two-tier crag, hanging roots, and lower island remain.

Honest gap: the upper crown is still a fairly flat green pad on a smooth grey bowl — not the cover’s leafy stacked cliff. Falls are improved cards, not a volumetric ribbon. Roots/vines read weakly at hero distance. Close-up: `beauty/01_keep.png`.

### 3. Clouds
Stacked-sphere instanced puffs and separate thunderhead meshes were replaced by **one** instanced painted billboard (canvas atlas, four tiles: wide bank, tall tower, mid puff, anvil). Cylindrical camera-facing shader, dithered soft edges, matId packed in alpha so outlines stay off. Sunlit cream tops, lavender undersides. Horizon ranges unchanged.

Honest gap: cards, not volumes. A few mid-distance tiles still read as simple mounds. They are much closer to the cover than the old white globes, but not yet the cover’s huge wet cumulus walls.

### 4. Town and cape
Near houses vary in height, footprint, cream/ochre walls, terracotta roofs, and style (arched door, two-storey band, loggia, second chimney). Far impostors vary height and per-instance wall/roof color. Cape village uses the same palettes. SE cape apron is forced to green scrub and slightly flattened; east-headland grass threshold loosened.

Honest gap: from the postcard and `04_lighthouse.png` the far town still packs into a red-roof field, and the lighthouse cape’s south face is still a cream-tan faceted ramp in front of the greener crown. The heightfield cannot make a truly vertical limestone wall at this cell size.

### 5. Plane
Unchanged this pass — already cream wings and a red fuselage, confirmed in the hero shot.

### Draws / caps
Hero draws **135** (cap 150). Billboard clouds absorbed the old tower draw (net ~0). Medium tris fell slightly (sphere cloud stacks → cards).

| Quality | Hero tris | Hero draws | Title draws | Free draws | Caps |
|---|---:|---:|---:|---:|---|
| low | 927,590 | 130 | 118 | 120 | ≤1.5M / 150 |
| medium | 1,794,694 | 135 | 123 | 125 | ≤2.5M / 150 |
| high | 2,106,114 | 135 | 123 | 125 | ≤2.5M / 150 |

All under caps (SwiftShader fps ~20 is not a phone number). No LOD popping changes this wrap (hysteresis from 1fec8f2 stands). Mobile memory: low tier still 192² terrain; new atlases are 512px (was 256) but only two of them; clouds are a canvas texture, no extra render targets.

### Game vs official cover
Sheet: `delivery/shots/compare/game_vs_cover.png`.

**Closer:** olive/sage land instead of neon green; soft painted cumulus with sunlit tops (no globe stacks or ink outlines); keep is larger, two-tier, with a ruined jagged colonnade and flowing falls; cream/ochre house variation; cream-wing / red-fuselage Courrier; blue aerial haze.

**Still short:** the cover is a painting; the game is still clearly real-time 3D. Cover keep is a leafy crag of stacked arches and a tall waterfall; the game keep’s crown is a green pad. Cover cape is vertical cream stone terraced to the water; the game still shows a tan faceted apron. Cover clouds are huge wet towers filling the sky; in-game cards frame the postcard but do not match that density or softness.

### QA
M1–M5 on PC 1920×1080 and mobile 844×390: all five missions started, chase followed at start and mid, completed with stars, English HUD. **failed: 0, errors: 0.**

### Deliverables
- Beauty: `delivery/shots/beauty/sheet_2x3.png`
- Presentation: `delivery/shots/ui/presentation_sheet.png`
- Game vs cover: `delivery/shots/compare/game_vs_cover.png`
- Hero: `delivery/shots/heroes/hero_day.png`
- Titles unchanged (official cover key art)

### Usage
Weekly usage at the start of this pass: **72.2%** (limit shared with other apps on the plan; Relic + Long Shot also running). Allowed up to ~78%, then stop. No further iterate after this deploy.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **be78950** on main (after 5542918). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

---

## 27 Nov 2026, ~10:15 Europe/Paris CET — keep-remodel wrap

Continued from **be78950**. Official cover remains the art-direction target. This is the wrap of the 09:44 brief (weekly 73% at start, ceiling ~77%). No further iterate after this deploy.

The harsh note on be78950 was that The Hanging Keep still read as two smooth grey bowls with flat green lawn pads (a layered cake), not the cover’s leafy stacked cliffs.

### 1. The Hanging Keep
Rebuilt the crag as a noise-displaced, multi-lobe rock mass: irregular plan, horizontal strata, overhangs and undercuts, broken bites, faceted shading. Removed the flat lawn boxes. The crown is lumpy sage/olive foliage and bushes spilling over the rims, with hanging roots and vines under the overhangs. The ruin is now **three stacked arcade tiers** facing the postcard, plus a two-storey side arcade, broken towers at the ends, and a great tree in the ruins. Falls pour off the south rim past a **smaller lower island** into mist.

Honest gap: the body still starts from a displaced cylinder, so some shelf-like terraces remain (not a fully hand-sculpted cliff). Towers are simple stacked boxes. Foliage is sphere/cone clumps, not a painted canopy. Falls are still shader cards. Close-up: `beauty/01_keep.png`.

### 2. Sky
Painted billboard impostors (still one draw): many more and much larger. Medium now places ~14 drifting banks plus 19 framing/keep-side cards and 9 horizon thunderheads (42 cards in the hero). A wall of sunlit cumulus sits around the keep and on the horizon.

Honest gap: still cards, not volumes. Dithered edges can sparkle against the sky. Density is closer to the cover but not a continuous painted cloud wall.

### 3. Town, far view
Far impostors use a white-base Lambert so per-instance cream/ochre walls and varied terracotta actually show. ~38% of far plots (and ~16% of near plots) are now cypress + garden bushes instead of houses. A second, shallower “hip” roof mesh breaks the identical gable silhouette.

Honest gap: from the runway (`03_village.png`) the hillside still reads as a packed terracotta cluster. Trees help, but the town is denser and redder than the cover’s terraced cream village.

### 4. Lighthouse cape, south face
Extended the limestone cliff mesh east to x=80. Pulled the heightfield lip north as we move east of the sea arch, so the village sits on a steeper cream-stone drop rather than a long tan ramp. Green lips and olive scrub on the crown.

Honest gap: `04_lighthouse.png` still shows faceted cream slopes under the village — a steeper cliff than be78950, not a fully vertical painted limestone wall. The heightfield cell size cannot hide every terrace.

### 5. Extra life
Five more cruising sailboats in the postcard bay (varied scale). Steamer smoke: 10 larger, more opaque puffs in a taller plume. Bird flock 36→64, with new roosts over the bay and the keep.

Honest gap: smoke is still simple spheres and can wash out against a bright sky in a still. Birds are small V-kites; easy to miss in the hero.

### Draws / caps
Hero draws **138** (cap 150). Adds vs be78950: hip roofs, town trees, town bushes, five sailboats; clouds stayed one draw. Tris rose slightly with the denser keep and extra boats; still inside the cap.

| Quality | Hero tris | Hero draws | Title draws | Free draws | Caps |
|---|---:|---:|---:|---:|---|
| low | 935,294 | 135 | 123 | 124 | ≤1.5M / 150 |
| medium | 1,803,476 | 138 | 126 | 127 | ≤2.5M / 150 |
| high | 2,114,706 | 138 | 126 | 127 | ≤2.5M / 150 |

All under caps (SwiftShader fps ~20 is not a phone number). No LOD popping changes this wrap (hysteresis from 1fec8f2 stands).

### Game vs official cover
Sheet: `delivery/shots/compare/game_vs_cover.png`.

**Closer:** the keep is a rocky, foliage-topped crag with stacked arches, broken towers and a falling veil, not two lawn pads; the sky has a real wall of painted cumulus around the keep; the town has trees in the mass; the cape face is steeper limestone; the bay has more sail and a thicker steamer plume.

**Still short:** the cover keep is a leafy cliff of many arched tiers and a tall waterfall; the game keep is still a stylised 3D crag with card falls. Cover clouds are wet-into-wet paint filling the sky; ours are large soft cards. Cover cape is terraced cream stone to the water; the game still shows faceted slopes. Cover town is a loose cream/terracotta hill town; ours is still tight and red from the runway.

### QA
M1–M5 on PC 1920×1080 and mobile 844×390: all five missions started, chase followed at start and mid, completed with stars, English HUD. **failed: 0, errors: 0.**

### Deliverables
- Beauty: `delivery/shots/beauty/sheet_2x3.png`
- Presentation: `delivery/shots/ui/presentation_sheet.png`
- Game vs cover: `delivery/shots/compare/game_vs_cover.png`
- Hero: `delivery/shots/heroes/hero_day.png`

### Usage
Weekly usage at the start of this pass: **73%** (limit shared with other apps on the plan). Allowed up to ~77%, then stop. No further iterate after this deploy.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **cba1f10** on main (after be78950). Live: https://avp86fr-jpg.github.io/preview/ascii-air/


## 27 Nov 2026, ~10:31 Europe/Paris CET — keep-paint, 3D ruins, soft clouds, world/UI wrap

Review of **cba1f10**: the Keep read as stacked slabs with a blurry camo texture; ruins were flat cut-outs; a stray dark brown pillar sat on the right; cloud edges had a grainy dither halo that could flicker in motion.

### What changed
1. **Keep rock.** New crisp painted atlas `textures/keep_rock.png` (horizontal strata, warm/cool light, brush dabs, no blur) applied with triplanar Lambert on a dedicated `keep-rock` mesh. Vertex tints are gentle so the atlas reads. The crag profile no longer uses stepped “cake” shelves. A merge bug that dropped vertex colors (and turned the whole Keep black) was fixed.
2. **3D ruins.** Cardboard extruded colonnades and the tall dark `brokenTower` pillars are gone. In their place: piers with base/shaft/capital, thick bevelled arches, cornices, broken masonry, a cream-stone turret with a window arch and crenels, and a short broken drum on the right. Ivy and leafy masses drape the rims.
3. **Foliage.** Sphere canopies replaced with merged irregular flattened `leafMass` blobs on the Keep; turf and bushes use the same idea.
4. **Falls.** Richer foam, spray and splash in the waterfall shader (still one crossed-card mesh plus mist).
5. **Clouds.** Screen-space dither discard removed. Billboard cards now use premultiplied soft alpha and CustomBlending that leaves destination matId intact so outlines stay off the clouds. No grainy halo in stills.
6. **World life.** Wayside chapels, footbridges, dock crates/barrels/bollards, extra market stalls, orchards, vineyard rows, town garden walls, more fishing boats (east cove, lagoon), expanded stone walls, more people zones (market, chapel, mills, farms), and cart silhouettes. Cape south face gets leafy tufts on the limestone wall (not dark disks on the plateau).
7. **UI.** Warm poster cream / ink / terracotta double-rule frames on HUD, menus and buttons, matching the cover. Title buttons remain unclipped at 1920×1080, 1280×720, 844×390 and 390×844.

### Perf (hero / title / free, after the final change)

| Quality | Hero tris | Hero draws | Title draws | Free draws | Caps |
|---|---:|---:|---:|---:|---|
| low | 971,900 | 137 | 125 | 126 | ≤1.5M / 150 |
| medium | 1,841,966 | 141 | 129 | 130 | ≤2.5M / 150 |
| high | 2,153,700 | 141 | 129 | 130 | ≤2.5M / 150 |

All under caps. Headroom ~9 draws on medium/high. SwiftShader fps ~20 is not a phone number. No LOD popping changes this wrap (hysteresis from 1fec8f2 stands). English HUD. No Ghibli/Miyazaki names.

### QA
M1–M5 on PC 1920×1080 and mobile 844×390: all five missions started, chase followed at start and mid, completed with stars, English HUD. **failed: 0, errors: 0.** Title layout: all four sizes unclipped (`TITLE_ALL_CLEAR`).

### Sheets
- Compare: `delivery/shots/compare/game_vs_cover.png`
- Beauty: `delivery/shots/beauty/sheet_2x3.png`
- Keep close-up: `delivery/shots/beauty/sheet_keep_close.png`
- World/life: `delivery/shots/beauty/sheet_world_life.png`
- UI / presentation: `delivery/shots/ui/presentation_sheet.png`
- Hero: `delivery/shots/heroes/hero_day.png`

### Honest gaps
- The Keep rock is painted and no longer camouflaged, but the silhouette is still a stylised displaced mass with some layered overhangs — not a fully hand-sculpted cliff of many irregular shelves.
- Ruin stone shares the keep-rock atlas; close-up columns can read a little like warm sandstone / wood grain rather than cut limestone blocks with mortar.
- Foliage masses are irregular flattened blobs, still smoother and rounder than real leafy canopies. Orchard trees are simple instanced spheres.
- Falls are still crossed cards with a richer shader, not true volumetric water.
- Clouds are soft-edged painted cards (no dither halo in stills). They can stack as overlapping billboards and are not wet-into-wet paint filling the sky. Motion sparkle was not frame-by-frame validated on a phone (shader no longer uses screen-space dither).
- Harbor close-up cameras kept clipping a pine belt; docks, crates and boats are in the world but the world/life sheet’s harbor frame is more of an approach than a dock still. People/carts are small silhouettes.
- Cape south face has greenery on the limestone wall, but the village still sits on faceted cream slopes.
- Far town is richer up close (stalls, walls, trees) but still reads as a tight terracotta cluster from the runway.
- Cover remains ahead on leafy ruin density, wet clouds, and the terraced limestone cape.

### Usage
Weekly usage at the start of this pass: **74%** (limit shared with Relic and Long Shot). Allowed up to ~82% of the 85% ceiling (Aero ~6 points). Meter after this wrap: **75.4%** (can lag). Resets Thursday, 3 Dec 2026, 10:18 Europe/Paris CET.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **9a341b1** on main (after cba1f10). Live: https://avp86fr-jpg.github.io/preview/ascii-air/



## 27 Nov 2026, ~10:54 Europe/Paris CET — bright clouds, limestone ruins, stylised trees wrap

Review of **9a341b1**: clouds had regressed to grey, smudgy, dirty-smoke masses; ruins read as brown wood/sandstone grain; trees were plain cones and balls; the Keep needed a leafier silhouette; the cape village still sat on faceted cream slopes; the far town needed terrace/greenery breakup; the harbour close-up camera kept hitting a pine belt.

### What changed
1. **Clouds.** The dirty-grey look was a double-premultiply plus dark lavender bases and a post highlight-knee that crushed bright cores. Soft alpha blending is kept (no dither halo). Atlas cores are sunlit cream/white with pale blue-lavender shade only; the shader lifts mid-alpha so it cannot fall to smoke-grey; post no longer greys out sky/cloud pixels. Edges stay soft and painted.
2. **Ruins / Keep rock.** New pale weathered-limestone atlas (cream/grey strata, no brown wood grain) and cream-stone vertex tints. Ivy and moss stay on the piers and rims.
3. **Trees.** New painted `leaf.png` (brush dabs, light-side highlights) on flora via triplanar + vertex tint. Prototypes: multi-lobe clumps, cypress tapers (stacked, not one cone), flat umbrella pines, silvery olives. Far-town gaps and orchards use the same language. Harbour/pier approaches no longer get a pine grove.
4. **Keep greenery.** Denser turf and rim trees, more ivy, hanging masses on the south and side faces for a leafier silhouette.
5. **Cape village.** Stepped limestone terraces with grass on the treads and rock on the risers; more greenery on the south face.
6. **Far town.** Half the far plots are now garden gaps; mixed cypress / umbrella / olive instancers break up the roof field.
7. **Harbour camera.** Locked to a quay view of the canal (boats, people, cart silhouettes) that no longer sits inside the pine belt: lookFrom (160, 8, −1255) → (185, 2, −1220).

High-quality tree/house/life counts were eased slightly (trees 0.85, same as medium) so high stays under the 2.5M tri cap after the heavier canopies.

### Perf (hero / title / free, after the final change)

| Quality | Hero tris | Hero draws | Title draws | Free draws | Caps |
|---|---:|---:|---:|---:|---|
| low | 1,145,020 | 140 | 129 | 130 | ≤1.5M / 150 |
| medium | 2,216,190 | 144 | 133 | 134 | ≤2.5M / 150 |
| high | 2,217,442 | 144 | 133 | 134 | ≤2.5M / 150 |

All under caps. Headroom ~6 draws. SwiftShader fps ~20 is not a phone number. No LOD popping changes this wrap. English HUD. No Ghibli/Miyazaki names.

### QA
M1–M5 on PC 1920×1080 and mobile 844×390: all five missions started, chase followed at start and mid, completed with stars, English HUD. **failed: 0, errors: 0.**

### Sheets
- Compare: `delivery/shots/compare/game_vs_cover.png`
- Beauty: `delivery/shots/beauty/sheet_2x3.png`
- Keep close-up: `delivery/shots/beauty/sheet_keep_close.png`
- World/life: `delivery/shots/beauty/sheet_world_life.png`
- UI / presentation: `delivery/shots/ui/presentation_sheet.png`
- Hero: `delivery/shots/heroes/hero_day.png`

### Honest gaps
- Clouds are bright white/cream with soft edges, but still billboard cards. Shade lavender is subtle; big stacked cards can still look a little blown-out or featureless next to the cover’s wet-into-wet paint. Motion sparkle was not frame-by-frame validated on a phone (dither remains off).
- Ruin limestone is pale and reads as stone, not timber, but it is still a triplanar strata atlas, not cut blocks with mortar.
- Keep foliage is denser, yet mid-faces are still rocky; the silhouette is not as leafy as the cover keep. Keep trees are irregular masses, but darker and simpler than the flora prototypes (they sit in the untextured keep merge).
- Flora canopies are stylised and textured, not unique hero trees; far LODs stay simple.
- Cape terraces and greenery help, but some faceted cream triangles remain on the lower south slope and beach apron.
- Far town is broken up by gardens and mixed trees, but from the runway it can still read as a tight terracotta cluster.
- The harbour sheet shows the canal quay, boats and people — not a close-up of crate piles on a sea dock.
- High quality now uses the same tree density as medium so it stays under 2.5M tris.

### Usage
Weekly usage at the start of this pass: **75.4%** (limit shared with Relic and Long Shot). Stop Aero by ~81%. Meter after this wrap: **76.1%** (can lag). Resets Thursday, 3 Dec 2026, 10:18 Europe/Paris CET.

Hidden deploy, preview/ascii-air/ only, noindex,nofollow. Commit **9247327** on main (after 9a341b1). Live: https://avp86fr-jpg.github.io/preview/ascii-air/

